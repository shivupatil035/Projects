﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;


namespace BPADataLayer
{
    public class SqlWrapper
    {
        SqlConnection con;
            public SqlWrapper()
            {
                con = new SqlConnection("Data source=localhost;Initial Catalog=AIMSBPA;integrated security=true");
            }
            public SqlWrapper(string conStr)
            {
                con = new SqlConnection(conStr);
            }

            public DataTable ExecuteDataTable(SqlCommand cmd)
            {
                cmd.Connection = con;
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                return dt;
            }
            public DataTable GetRole(string rol)
            {
                SqlCommand objCmd = new SqlCommand();
                objCmd.CommandText = rol;
                objCmd.CommandType = CommandType.StoredProcedure;
                objCmd.Connection = con;
                SqlDataAdapter da = new SqlDataAdapter(objCmd);
                DataTable dt = new DataTable();

                da.Fill(dt);
                return dt;
            }

            public DataTable GetDBId(string dbid)
            {
                SqlCommand objCmd1 = new SqlCommand();
                objCmd1.CommandText = dbid;
                objCmd1.CommandType = CommandType.StoredProcedure;
                objCmd1.Connection = con;
                SqlDataAdapter da1 = new SqlDataAdapter(objCmd1);
                DataTable dt1 = new DataTable();

                da1.Fill(dt1);
                return dt1;
            }


            public DataTable GeCourseId(string cid)
            {
                SqlCommand objCmd2 = new SqlCommand();
                objCmd2.CommandText = cid;
                objCmd2.CommandType = CommandType.StoredProcedure;
                objCmd2.Connection = con;
                SqlDataAdapter da2 = new SqlDataAdapter(objCmd2);
                DataTable dt2 = new DataTable();

                da2.Fill(dt2);
                return dt2;
            }


            public DataTable GetTeamLeadId(string tlid)
            {
                SqlCommand objCmd3 = new SqlCommand();
                objCmd3.CommandText = tlid;
                objCmd3.CommandType = CommandType.StoredProcedure;
                objCmd3.Connection = con;
                SqlDataAdapter da3 = new SqlDataAdapter(objCmd3);
                DataTable dt3 = new DataTable();

                da3.Fill(dt3);
                return dt3;
            }

            public DataTable GePromotionalId(string pid)
            {
                SqlCommand objCmd2 = new SqlCommand();
                objCmd2.CommandText = pid;
                objCmd2.CommandType = CommandType.StoredProcedure;
                objCmd2.Connection = con;
                SqlDataAdapter da2 = new SqlDataAdapter(objCmd2);
                DataTable dt2 = new DataTable();

                da2.Fill(dt2);
                return dt2;
            }


            public DataTable ExecuteDataTable(string pro)
            {
                SqlCommand ObjCommand = new SqlCommand();
                ObjCommand.CommandText = pro;
                ObjCommand.CommandType = CommandType.StoredProcedure;
                ObjCommand.Connection = con;

                SqlDataAdapter Objda = new SqlDataAdapter(ObjCommand);
                DataTable Objdt = new DataTable();
                Objda.Fill(Objdt);
                return Objdt;
            }
   


            public int ExecuteNonQuery(SqlCommand cmd)
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                cmd.Connection = con;
                return cmd.ExecuteNonQuery();
            }
        }
    }

