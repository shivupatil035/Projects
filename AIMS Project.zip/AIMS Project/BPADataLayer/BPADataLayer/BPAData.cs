﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace BPADataLayer
{
     public class BPAData
    {
        SqlWrapper wrap = new SqlWrapper();
        public DataTable ListLogin(string email)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "ProLoginList";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@EmailId", email);
            return wrap.ExecuteDataTable(cmd);
        }

        public DataTable ForgotPssword(String email)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "ProForgotPassword";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@email", email);
            return wrap.ExecuteDataTable(cmd);

        }

        public DataTable ForgotRole()
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "ProSelectroleForgot";
            cmd.CommandType = CommandType.StoredProcedure;

            return wrap.ExecuteDataTable(cmd);

        }
        public DataTable SelectPass()
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "ProSelectPass";
            cmd.CommandType = CommandType.StoredProcedure;
            return wrap.ExecuteDataTable(cmd);
        }
        public DataTable ChangePssword(String newpassword, String oldpassword)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "ProChangepass";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@newpassword", newpassword);
            cmd.Parameters.AddWithValue("@oldpassword", oldpassword);
            return wrap.ExecuteDataTable(cmd);
        }
        public DataTable ReportTo()
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "ProReportingTo";
            cmd.CommandType = CommandType.StoredProcedure;
            return wrap.ExecuteDataTable(cmd);
        }
        public DataTable UserList()
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "ProUserList";
            cmd.CommandType = CommandType.StoredProcedure;
            return wrap.ExecuteDataTable(cmd);
        }

        public DataTable GetRoleInfo()
        {
            DataTable dts = wrap.GetRole("GetRoles");
            return dts;
        }
        public int UserDeactive(int userid)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "ProUserDelete";
            cmd.Parameters.AddWithValue("@UserId", userid);
            cmd.CommandType = CommandType.StoredProcedure;
            return wrap.ExecuteNonQuery(cmd);
        }

         //Team Lead
        public int AddTeamLead(string FName, String LName, string Email, Int64 MobileNo, Int64 OfficialNo, string Address, string City, Int64 Pin, string Qualification, string Gender, DateTime DOB, string Photo, int ReportTo, string pass, int RoleId)
        {
            SqlCommand cmdAddTLDetails = new SqlCommand();

            cmdAddTLDetails.CommandText = "ProAddTeamlead";
            cmdAddTLDetails.CommandType = CommandType.StoredProcedure;
            cmdAddTLDetails.Parameters.AddWithValue("@fname", FName);
            cmdAddTLDetails.Parameters.AddWithValue("@lname", LName);
            cmdAddTLDetails.Parameters.AddWithValue("@email", Email);
            cmdAddTLDetails.Parameters.AddWithValue("@Mobile", MobileNo);
            cmdAddTLDetails.Parameters.AddWithValue("@official", OfficialNo);
            cmdAddTLDetails.Parameters.AddWithValue("@address", Address);
            cmdAddTLDetails.Parameters.AddWithValue("@city", City);
            cmdAddTLDetails.Parameters.AddWithValue("@pin", Pin);
            cmdAddTLDetails.Parameters.AddWithValue("@qualification", Qualification);
            cmdAddTLDetails.Parameters.AddWithValue("@gender", Gender);
            cmdAddTLDetails.Parameters.AddWithValue("@dob", DOB);
            cmdAddTLDetails.Parameters.AddWithValue("@photo", Photo);
            cmdAddTLDetails.Parameters.AddWithValue("@ReporTo", ReportTo);
            cmdAddTLDetails.Parameters.AddWithValue("@pass", pass);
            cmdAddTLDetails.Parameters.AddWithValue("@roleid", RoleId);

            return wrap.ExecuteNonQuery(cmdAddTLDetails);
        }

        public DataTable SelectUser(int userid)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "ProSelectUser";
            cmd.Parameters.AddWithValue("@UserId", userid);
            cmd.CommandType = CommandType.StoredProcedure;
            return wrap.ExecuteDataTable(cmd);
        }
                        
        public int UpdateTeamLead(int Userid, string FName, String LName, string Email, Int64 MobileNo, Int64 OfficialNo, string Address, string City, Int64 Pin, string Qualification, string Gender, DateTime DOB, string Photo, int ReportTo, string pass, int RoleId)
        {
            SqlCommand cmdupdateTLDetails = new SqlCommand();

            cmdupdateTLDetails.CommandText = "ProUpdateTeamLead";
            cmdupdateTLDetails.CommandType = CommandType.StoredProcedure;
            cmdupdateTLDetails.Parameters.AddWithValue("@userid", Userid);
            cmdupdateTLDetails.Parameters.AddWithValue("@fname", FName);
            cmdupdateTLDetails.Parameters.AddWithValue("@lname", LName);
            cmdupdateTLDetails.Parameters.AddWithValue("@email", Email);
            cmdupdateTLDetails.Parameters.AddWithValue("@Mobile", MobileNo);
            cmdupdateTLDetails.Parameters.AddWithValue("@official", OfficialNo);
            cmdupdateTLDetails.Parameters.AddWithValue("@address", Address);
            cmdupdateTLDetails.Parameters.AddWithValue("@city", City);
            cmdupdateTLDetails.Parameters.AddWithValue("@pin", Pin);
            cmdupdateTLDetails.Parameters.AddWithValue("@qualification", Qualification);
            cmdupdateTLDetails.Parameters.AddWithValue("@gender", Gender);
            cmdupdateTLDetails.Parameters.AddWithValue("@dob", DOB);
            cmdupdateTLDetails.Parameters.AddWithValue("@photo", Photo);
            cmdupdateTLDetails.Parameters.AddWithValue("@ReporTo", ReportTo);
            cmdupdateTLDetails.Parameters.AddWithValue("@pass", pass);
            cmdupdateTLDetails.Parameters.AddWithValue("@roleid", RoleId);
            return wrap.ExecuteNonQuery(cmdupdateTLDetails);
        }

        public DataTable SearchTeamLead(int id)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "ProSearchTeamlead";
            cmd.Parameters.AddWithValue("@id", id);
            cmd.CommandType = CommandType.StoredProcedure;
            return wrap.ExecuteDataTable(cmd);
        }
       


         //CourseMaster

        public int AddCourse(string Course, int CourseDurationYear, int CourseDurationMonth, int CourseFees, string Remarks)
        {
            SqlCommand cmdaddcourse = new SqlCommand();
            cmdaddcourse.CommandText = "ProAddCourse";
            cmdaddcourse.CommandType = CommandType.StoredProcedure;
            cmdaddcourse.Parameters.AddWithValue("@Course", Course);
            cmdaddcourse.Parameters.AddWithValue("@CourseDurationYear", CourseDurationYear);
            cmdaddcourse.Parameters.AddWithValue("@CourseDurationMonth", CourseDurationMonth);
            cmdaddcourse.Parameters.AddWithValue("@CourseFees", CourseFees);
            cmdaddcourse.Parameters.AddWithValue("@Remarks", Remarks);
            return wrap.ExecuteNonQuery(cmdaddcourse);
        }


         public DataTable EditCourse()
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "ProSelectCourses";
            cmd.CommandType = CommandType.StoredProcedure;
            return wrap.ExecuteDataTable(cmd);
        }


        public int DeleteCourse(int CourseId)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "ProDeleteCourse";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@CourseId", CourseId);
            return wrap.ExecuteNonQuery(cmd);
        }


        public DataTable FetchCourse(int CourseId)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "ProFetchCourses";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@CourseId", CourseId);
            return wrap.ExecuteDataTable(cmd);
        }


        public int UpdateCourse(int CourseId, string Course, int CourseDurationYear, int CourseDurationMonth, Double CourseFees, string Remarks)
        {
            SqlCommand cmdupdate = new SqlCommand();
            cmdupdate.CommandText = "ProUpdateCourse";
            cmdupdate.CommandType = CommandType.StoredProcedure;
            cmdupdate.Parameters.AddWithValue("@CourseId", CourseId);
            cmdupdate.Parameters.AddWithValue("@Course", Course);
            cmdupdate.Parameters.AddWithValue("@CourseDurationYear", CourseDurationYear);
            cmdupdate.Parameters.AddWithValue("@CourseDurationMonth", CourseDurationMonth);
            cmdupdate.Parameters.AddWithValue("@CourseFees", CourseFees);
            cmdupdate.Parameters.AddWithValue("@Remarks", Remarks);
            return wrap.ExecuteNonQuery(cmdupdate);
        }

        public int AssignCourse(int CourseAssignId, int CourseAssgnTo, string Remarks)
        {
            SqlCommand cmdadddb = new SqlCommand();
            cmdadddb.CommandText = "ProAssignCourse";
            cmdadddb.CommandType = CommandType.StoredProcedure;
            cmdadddb.Parameters.AddWithValue("@CourseAssignId", CourseAssignId);
            cmdadddb.Parameters.AddWithValue("@CourseAssgnTo", CourseAssgnTo);
            cmdadddb.Parameters.AddWithValue("@Remarks", Remarks);
            return wrap.ExecuteNonQuery(cmdadddb);
        }

        public DataTable Courselist()
        {
            DataTable dts = wrap.GeCourseId("ProCourseList");
            return dts;
        }

        public DataTable CourseTeamLeadList()
        {
            DataTable dts = wrap.GetTeamLeadId("ProCouseUserList");
            return dts;
        }

        public DataTable SearchCourse(string name)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "ProSearchCourse";
            cmd.Parameters.AddWithValue("@Course", name);
            cmd.CommandType = CommandType.StoredProcedure;
            return wrap.ExecuteDataTable(cmd);
        }
       
         // Meetings
        public DataTable DisplayMeetings()
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "ProSelectMeeting";
            cmd.CommandType = CommandType.StoredProcedure;
            return wrap.ExecuteDataTable(cmd);
        }

        public int MeetingDeactive(int MeetingId)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "ProMeetingDelete";
            cmd.Parameters.AddWithValue("@MeetingId", MeetingId);
            cmd.CommandType = CommandType.StoredProcedure;
            return wrap.ExecuteNonQuery(cmd);
        }

        public DataTable MeetingSearch(string name, string id)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "ProSearchMeetingDetails";
            cmd.Parameters.AddWithValue("@MeetingName", name);
            cmd.Parameters.AddWithValue("@MeetingId", id);
            cmd.CommandType = CommandType.StoredProcedure;
            return wrap.ExecuteDataTable(cmd);
        }

        public int Addmeeting(string MName, string Description, DateTime date, string Stime, string ETime, string Location)
        {
            SqlCommand cmdAddMDetails = new SqlCommand();

            cmdAddMDetails.CommandText = "ProAddMeeting";
            cmdAddMDetails.CommandType = CommandType.StoredProcedure;
            cmdAddMDetails.Parameters.AddWithValue("@MeetingName", MName);
            cmdAddMDetails.Parameters.AddWithValue("@Description", Description);
            cmdAddMDetails.Parameters.AddWithValue("@Date", date);
            cmdAddMDetails.Parameters.AddWithValue("@StartTime", Stime);
            cmdAddMDetails.Parameters.AddWithValue("@EndTime", ETime);
            cmdAddMDetails.Parameters.AddWithValue("@Location", Location);

            return wrap.ExecuteNonQuery(cmdAddMDetails);
        }
        public int Updatemeeting(int meetingid, string MName, string Description, DateTime date, string Stime, string ETime, string Location)
        {
            SqlCommand cmdupMDetails = new SqlCommand();

            cmdupMDetails.CommandText = "ProUpdateMeeting";
            cmdupMDetails.CommandType = CommandType.StoredProcedure;
            cmdupMDetails.Parameters.AddWithValue("@meetingid", meetingid);
            cmdupMDetails.Parameters.AddWithValue("@MeetingName", MName);
            cmdupMDetails.Parameters.AddWithValue("@description", Description);
            cmdupMDetails.Parameters.AddWithValue("@date", date);
            cmdupMDetails.Parameters.AddWithValue("@starttime", Stime);
            cmdupMDetails.Parameters.AddWithValue("@endtime", ETime);
            cmdupMDetails.Parameters.AddWithValue("@location", Location);

            return wrap.ExecuteNonQuery(cmdupMDetails);
        }

        public DataTable SelectMeetingId(int meetingid)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "ProMeetingId";
            cmd.Parameters.AddWithValue("@Meetingid", meetingid);
            cmd.CommandType = CommandType.StoredProcedure;
            return wrap.ExecuteDataTable(cmd);
        }


         //Database

        public DataTable GetDBId()
        {
            DataTable dts = wrap.GetDBId("GetDatabaseId");
            return dts;
        }

        public int AddDatabase(int @DatabaseRoleId, string DatabaseName, string DatabaseBrower, string CreateDescription)
        {
            SqlCommand cmdadddb = new SqlCommand();
            cmdadddb.CommandText = "ProAddDatabase";
            cmdadddb.CommandType = CommandType.StoredProcedure;
            cmdadddb.Parameters.AddWithValue("@DatabaseRoleId", @DatabaseRoleId);
            cmdadddb.Parameters.AddWithValue("@DatabaseName", DatabaseName);
            cmdadddb.Parameters.AddWithValue("@DatabaseBrower", DatabaseBrower);
            cmdadddb.Parameters.AddWithValue("@CreateDescription", CreateDescription);
           
            return wrap.ExecuteNonQuery(cmdadddb);
        }


        public int AssignDatabase(int DatabseAssignId,int TeamLeadId, string AssignDescription)
        {
            SqlCommand cmdadddb = new SqlCommand();
            cmdadddb.CommandText = "ProAssignDatabase";
            cmdadddb.CommandType = CommandType.StoredProcedure;
            cmdadddb.Parameters.AddWithValue("@DatabseAssignId", DatabseAssignId);
            cmdadddb.Parameters.AddWithValue("@TeamLeadId", TeamLeadId);
            cmdadddb.Parameters.AddWithValue("@AssignDescription", AssignDescription);

            return wrap.ExecuteNonQuery(cmdadddb);
        }

        public int UpdateDatabase(int DatabseAssignId, int TeamLeadId, string AssignDescription)
        {
            SqlCommand cmdadddb = new SqlCommand();

            cmdadddb.CommandText = "ProAssignDatabase";
            cmdadddb.CommandType = CommandType.StoredProcedure;
            cmdadddb.Parameters.AddWithValue("@DatabseAssignId", DatabseAssignId);
            cmdadddb.Parameters.AddWithValue("@TeamLeadId", TeamLeadId);
            cmdadddb.Parameters.AddWithValue("@AssignDescription", AssignDescription);


            return wrap.ExecuteNonQuery(cmdadddb);
        }

        public DataTable DeleteDB(int DatabseId)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "ProDeleteDB";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@DatabseId", DatabseId);
            return wrap.ExecuteDataTable(cmd);
        }


        public DataTable DatabaseView()
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "BPADatabaseView1";
            cmd.CommandType = CommandType.StoredProcedure;
            return wrap.ExecuteDataTable(cmd);
        }

        public DataTable FetchDB(int DatabseId)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "ProFetchDB";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@DatabseId", DatabseId);
            return wrap.ExecuteDataTable(cmd);
        }

        public DataTable SearchDB(string name)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "BPASearchDB";
            cmd.Parameters.AddWithValue("@name", name);
            cmd.CommandType = CommandType.StoredProcedure;
            return wrap.ExecuteDataTable(cmd);
        }

         //Promotional Activity


        public int AddPromotionalActivity(string PromotionalType,string Subject,int Amount,string DurationStart,string DurationEnd, string Attachment,string Remark)
        {
            SqlCommand cmdadddb = new SqlCommand();
            cmdadddb.CommandText = "ProAddPromotionalActivity";
            cmdadddb.CommandType = CommandType.StoredProcedure;
            cmdadddb.Parameters.AddWithValue("@PromotionalType", PromotionalType);
            cmdadddb.Parameters.AddWithValue("@Subject", Subject);
            cmdadddb.Parameters.AddWithValue("@Amount", Amount);
            cmdadddb.Parameters.AddWithValue("@DurationStart",DurationStart);
            cmdadddb.Parameters.AddWithValue("@DurationEnd",DurationEnd);
            cmdadddb.Parameters.AddWithValue("@Attachment", Attachment);
            cmdadddb.Parameters.AddWithValue("@Remark", Remark);
            return wrap.ExecuteNonQuery(cmdadddb);
        }
        public DataTable Promotionallist()
        {
            DataTable dts = wrap.GePromotionalId("ProPromotionalList");
            return dts;
        }



        public int AssignPromotionalActivity(int PromotionalActivityId,int TeamLeadId,string Remark)
        {
            SqlCommand cmdadddb = new SqlCommand();
            cmdadddb.CommandText = "ProAssignPromotionalActivity";
            cmdadddb.CommandType = CommandType.StoredProcedure;
            cmdadddb.Parameters.AddWithValue("@PromotionalActivityId", PromotionalActivityId);
            cmdadddb.Parameters.AddWithValue("@TeamLeadId", TeamLeadId);
            cmdadddb.Parameters.AddWithValue("@Remark", Remark);

            return wrap.ExecuteNonQuery(cmdadddb);
        }

        public int UpdatePromotionalActivity(int PromotionalActivityId, string PromotionalType, string Subject, int Amount, DateTime DurationStart, DateTime DurationEnd, string Attachment, string Remark)
        {
            SqlCommand cmdadddb = new SqlCommand();

            cmdadddb.CommandText = "ProUpdatePromotionalActivity";
            cmdadddb.CommandType = CommandType.StoredProcedure;
            cmdadddb.Parameters.AddWithValue("@PromotionalActivityId", PromotionalActivityId);
            cmdadddb.Parameters.AddWithValue("@PromotionalType",PromotionalType);
            cmdadddb.Parameters.AddWithValue("@Subject",Subject);
            cmdadddb.Parameters.AddWithValue("@Amount",Amount);
            cmdadddb.Parameters.AddWithValue("@DurationStart",DurationStart);
            cmdadddb.Parameters.AddWithValue("@DurationEnd",DurationEnd);
            cmdadddb.Parameters.AddWithValue("@Attachment",Attachment);
            cmdadddb.Parameters.AddWithValue("@Remark",Remark);


            return wrap.ExecuteNonQuery(cmdadddb);
        }

        public DataTable DeletePromotionalActivity(int PromotionalActivityId)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "ProDeletPromotionalActivity";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@PromotionalActivityId", PromotionalActivityId);
            return wrap.ExecuteDataTable(cmd);
        }


        public DataTable PromotionalActivityView()
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "ProFetchPromotionalActivity";
            cmd.CommandType = CommandType.StoredProcedure;
            return wrap.ExecuteDataTable(cmd);
        }

        public DataTable FetchPromotionalActivity(int PromotionalActivityId)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "ProSelectPromotionalActivity";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@PromotionalActivityId", PromotionalActivityId);
            return wrap.ExecuteDataTable(cmd);
        }

        public DataTable SearchPromotionalActivity(int id)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "ProSearchPromotionalActivity";
            cmd.Parameters.AddWithValue("@id", id);
            cmd.CommandType = CommandType.StoredProcedure;
            return wrap.ExecuteDataTable(cmd);
        }

         //Mail


        public DataTable ListBoxBound()
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "ProBoundListBox";
            cmd.CommandType = CommandType.StoredProcedure;
            return wrap.ExecuteDataTable(cmd);
        }
        public DataTable BindOutbox()
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "ProBindOutbox";
            cmd.CommandType = CommandType.StoredProcedure;
            return wrap.ExecuteDataTable(cmd);
        }
        public DataTable BindInbox()
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "ProBindInbox";
            cmd.CommandType = CommandType.StoredProcedure;
            return wrap.ExecuteDataTable(cmd);
        }

        public int AddMails(string Subject, string Message, int SenderId, string Attachment)
        {
            SqlCommand cmdAddMails = new SqlCommand();

            cmdAddMails.CommandText = "ProInsertToMails";
            cmdAddMails.CommandType = CommandType.StoredProcedure;
            cmdAddMails.Parameters.AddWithValue("@Subject", Subject);
            cmdAddMails.Parameters.AddWithValue("@Message", Message);
            cmdAddMails.Parameters.AddWithValue("@SenderId", SenderId);
            cmdAddMails.Parameters.AddWithValue("@Attachment", Attachment);
            //cmdAddMails.Parameters.AddWithValue("@MailId", Mailid);
            // cmdAddMails.Parameters.AddWithValue("@senderId1", Senderid1);
            //cmdAddMails.Parameters.AddWithValue("@receiverId", ReceiverId);
            return wrap.ExecuteNonQuery(cmdAddMails);
        }
        public int AddMailRecepient(int SenderId, int ReceiverId)
        {
            SqlCommand cmdAddMailRecepient = new SqlCommand();
            cmdAddMailRecepient.CommandText = "ProInsertToMailRecepients";
            cmdAddMailRecepient.CommandType = CommandType.StoredProcedure;
            cmdAddMailRecepient.Parameters.AddWithValue("@SenderId", SenderId);
            cmdAddMailRecepient.Parameters.AddWithValue("@ReceiverId", ReceiverId);
            return wrap.ExecuteNonQuery(cmdAddMailRecepient);
        }

         //Message

        public DataTable MessageUserDisplay()
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "ProMessageSelectUsers";
            cmd.CommandType = CommandType.StoredProcedure;
            return wrap.ExecuteDataTable(cmd);
        }

        public int AddMEssages(string Message, int SenderId)
        {
            SqlCommand cmdAddMailRecepient = new SqlCommand();
            cmdAddMailRecepient.CommandText = "ProInsertToMessage";
            cmdAddMailRecepient.CommandType = CommandType.StoredProcedure;
            cmdAddMailRecepient.Parameters.AddWithValue("@Message", Message);
            cmdAddMailRecepient.Parameters.AddWithValue("@SenderId", SenderId);
            return wrap.ExecuteNonQuery(cmdAddMailRecepient);
        }
        public int AddMessageRecepient(int SenderId, int ReceiverId)
        {
            SqlCommand cmdAddMailRecepient = new SqlCommand();
            cmdAddMailRecepient.CommandText = "ProInsertToMessageRecepients";
            cmdAddMailRecepient.CommandType = CommandType.StoredProcedure;
            cmdAddMailRecepient.Parameters.AddWithValue("@SenderId", SenderId);
            cmdAddMailRecepient.Parameters.AddWithValue("@ReceiverId", ReceiverId);
            return wrap.ExecuteNonQuery(cmdAddMailRecepient);
        }
        public DataTable BindMessageInbox(int RecevierId)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "ProMessageInbox";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@RecevierId", RecevierId);
            return wrap.ExecuteDataTable(cmd);
        }
    




         //Report
        public DataTable UserListReport()
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "ProSelectUserReport";
            cmd.CommandType = CommandType.StoredProcedure;
            return wrap.ExecuteDataTable(cmd);
        }

        public DataTable PerformaceReport()
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "ProPerformanceReport";
            cmd.CommandType = CommandType.StoredProcedure;
            return wrap.ExecuteDataTable(cmd);
        }

        public DataTable EnquiryList(int UserId)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "ProEnquiryList";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@UserId",UserId);
            return wrap.ExecuteDataTable(cmd);
        }

        public DataTable FollowUPList(int UserId)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "ProFollowUp";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@UserId", UserId);
            return wrap.ExecuteDataTable(cmd);
        }

        public DataTable AdmissionList(int UserId)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "ProAdmissions";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@UserId", UserId);
            return wrap.ExecuteDataTable(cmd);
        }
         //Events

        public int AddEvent(int Createrid, string eventname, String EventDescription, DateTime EventDate)
        {
            SqlCommand cmdAddEventDetails = new SqlCommand();

            cmdAddEventDetails.CommandText = "ProCreateEvent";
            cmdAddEventDetails.CommandType = CommandType.StoredProcedure;
            cmdAddEventDetails.Parameters.AddWithValue("@CreaterId", Createrid);
            cmdAddEventDetails.Parameters.AddWithValue("@eventname", eventname);
            cmdAddEventDetails.Parameters.AddWithValue("@EventDescription", EventDescription);
            cmdAddEventDetails.Parameters.AddWithValue("@EventDate", EventDate);
            return wrap.ExecuteNonQuery(cmdAddEventDetails);
        }

        public DataTable SelectEventId()
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "ProSelectEventId";
            cmd.CommandType = CommandType.StoredProcedure;
            return wrap.ExecuteDataTable(cmd);
        }
        public int EventApplicableIns(int EventId, int UserId, string Remarks)
        {
            SqlCommand cmdAppliEventDetails = new SqlCommand();

            cmdAppliEventDetails.CommandText = "ProEventApplicableTo";
            cmdAppliEventDetails.CommandType = CommandType.StoredProcedure;
            cmdAppliEventDetails.Parameters.AddWithValue("@EventId", EventId);
            cmdAppliEventDetails.Parameters.AddWithValue("@UserId", UserId);
            cmdAppliEventDetails.Parameters.AddWithValue("@Remarks", Remarks);
            return wrap.ExecuteNonQuery(cmdAppliEventDetails);
        }
        public int UpdateEvent(int EventId, int Createrid, String EventDescription, DateTime dateOfcreation, int EventId1, int UserId, string Remarks)
        {
            SqlCommand cmdUpdateEventDetails = new SqlCommand();

            cmdUpdateEventDetails.CommandText = "ProUpdateEvent";
            cmdUpdateEventDetails.CommandType = CommandType.StoredProcedure;
            cmdUpdateEventDetails.Parameters.AddWithValue("@EventId", EventId);

            cmdUpdateEventDetails.Parameters.AddWithValue("@EventCreator", Createrid);
            cmdUpdateEventDetails.Parameters.AddWithValue("@EventDetails", EventDescription);
            cmdUpdateEventDetails.Parameters.AddWithValue("@DateOfCreation", dateOfcreation);

            cmdUpdateEventDetails.Parameters.AddWithValue("@EventId1", EventId1);
            cmdUpdateEventDetails.Parameters.AddWithValue("@UserId", UserId);
            cmdUpdateEventDetails.Parameters.AddWithValue("@Remarks", Remarks);
            return wrap.ExecuteNonQuery(cmdUpdateEventDetails);
        }

        public DataTable DisplayEvents()
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "BPAEventView";
            cmd.CommandType = CommandType.StoredProcedure;
            return wrap.ExecuteDataTable(cmd);
        }

        public DataTable EventSearch(int Eventid, int Userid)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "ProSearchEventDetails";
            cmd.Parameters.AddWithValue("@EventId", Eventid);
            cmd.Parameters.AddWithValue("@UserId", Userid);
            cmd.CommandType = CommandType.StoredProcedure;
            return wrap.ExecuteDataTable(cmd);
        }

        public DataTable SearchEvent(string name)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "ProSearchEvent";
            cmd.Parameters.AddWithValue("@eventname", name);
            cmd.CommandType = CommandType.StoredProcedure;
            return wrap.ExecuteDataTable(cmd);
        }

        public DataTable FetchEvent(int EventId)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "ProFetchEvents";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@EventId", EventId);
            return wrap.ExecuteDataTable(cmd);
        }

        public DataTable CallEventDetails(DateTime EventDate)
        {
            SqlCommand cmdEvnt = new SqlCommand();
            cmdEvnt.CommandText = "EventDetailsCallPro";
            cmdEvnt.CommandType = CommandType.StoredProcedure;
            cmdEvnt.Parameters.AddWithValue("@EventDate", EventDate);
            return wrap.ExecuteDataTable(cmdEvnt);
        }
        public DataTable GetEventDate()
        {
            return wrap.ExecuteDataTable("EventDatePro");
        }
        public int EventDeactive(int EventId)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "ProDeleteEvent";
            cmd.Parameters.AddWithValue("@EventId", EventId);
            cmd.CommandType = CommandType.StoredProcedure;
            return wrap.ExecuteNonQuery(cmd);
        }

        public DataTable ViewEventDetails()
        {
            return wrap.ExecuteDataTable("ViewEventDetails");
        }

         
        public DataTable SelectEventsToEdit(int EventId)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "ProSelectEventId1";
            cmd.Parameters.AddWithValue("@EventId", EventId);
            cmd.CommandType = CommandType.StoredProcedure;
            return wrap.ExecuteDataTable(cmd);
        }






         //teamlead report
          public DataTable SelectTeamleadInReport()
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "ProTeamleadSelect1";
            cmd.CommandType = CommandType.StoredProcedure;
            return wrap.ExecuteDataTable(cmd);
        }
        public DataTable TeamleadReport(int Reporting)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "ProTLreportSRlist";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@ReportingTo",Reporting);
            return wrap.ExecuteDataTable(cmd);
        }
        public DataTable TeamleadReportDuration(string From,string to)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "TeamleadReportDuration";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@From", From);
            cmd.Parameters.AddWithValue("@to", to);
            return wrap.ExecuteDataTable(cmd);
        }
       

         //Dashboard

        public DataTable EventDashboard()
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "ProEventDashboard";
            cmd.CommandType = CommandType.StoredProcedure;
            return wrap.ExecuteDataTable(cmd);
        }
        public DataTable MeetingDashboard()
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "ProMeetingDashboard";
            cmd.CommandType = CommandType.StoredProcedure;
            return wrap.ExecuteDataTable(cmd);
        }
        public DataTable MeetingDashboardDisplay(int MeetingId)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "ProMeetingDashboardDetailsDisplay";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@MeetingId", MeetingId);
            return wrap.ExecuteDataTable(cmd);
        }
        public DataTable MailDashboard(int UserId)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "ProMailDashBoard";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@UserId", UserId);
            return wrap.ExecuteDataTable(cmd);
        }
        public DataTable MailDashboardDisplay(int MailId)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "ProMailDashBoardDisplay";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@MailId", MailId);
            return wrap.ExecuteDataTable(cmd);
        }
        public DataTable TeamleadDashboard()
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "ProTeamleadDashboard";
            cmd.CommandType = CommandType.StoredProcedure;
            return wrap.ExecuteDataTable(cmd);
        }
        public DataTable TeamleadDashboardDisplay(int ReportingTo)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "ProTeamleadDisplay";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@ReportingTo", ReportingTo);
            return wrap.ExecuteDataTable(cmd);
        }

        public DataTable EventDashboardDisplay(int id)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "ProEventDashboardDetails";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Eventid", id);
            return wrap.ExecuteDataTable(cmd);
        }





    }
}
