﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using BPABusinessLayer;

public partial class Homepage : System.Web.UI.Page
{
    BPABLData obj = new BPABLData();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnclass_Click(object sender, EventArgs e)
    {
   int i = 0;
        DataTable dt = new DataTable();
        dt = obj.ListUser(txtUserName.Text, txtPassword.Text);
        if (dt.Rows.Count > 0)
        {
            while (i < dt.Rows.Count)
            {
                DataRow dr = dt.Rows[0];
                if (txtUserName.Text == dr[3].ToString() && txtPassword.Text == dr[14].ToString())
                {
                    if (Convert.ToInt32(dr[15]) == 111)
                    {
                        Session["user"] = dr[0].ToString();
                        string st = Session["user"].ToString();
                        
                        Response.Redirect("BPAAdminhome.aspx");
                    }
                     }
                else
                {
                    lblValid.Text = "Login Failed Try Again";
                }
                i++;
            }
        }
        else
        {
            lblValid.Text = "Login Failed Try Again";
        }

    }
    
}