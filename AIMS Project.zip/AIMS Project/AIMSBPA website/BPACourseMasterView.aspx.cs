﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BPABusinessLayer;

public partial class BPACourseMasterView : System.Web.UI.Page
{
    BPABLData obj = new BPABLData();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {

            GridCourse.DataSource = obj.SelectCourse();
            GridCourse.DataBind();

        }
    }


    public void grddiaplay()
    {

        GridCourse.DataSource = obj.SelectCourse();
        GridCourse.DataBind();

    }
    protected void GridCourse_SelectedIndexChanged(object sender, EventArgs e)
    {

    }


    protected void GridCourse_RowCreated(object sender, GridViewRowEventArgs e)
    {
       
    }




    protected void GridCourse_RowCreated1(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.Header)
        {
            e.Row.Cells[0].Text = "Course ID";
            e.Row.Cells[1].Text = "Course Name";
            e.Row.Cells[2].Text = "Course Year";
            e.Row.Cells[3].Text = "Course Month";
            e.Row.Cells[4].Text = "Course Fees";
            e.Row.Cells[5].Text = "Date of Creation";
            e.Row.Cells[6].Text = "Remark";
           e.Row.Cells[7].Visible = false;

            
            e.Row.Cells[0].CssClass = "columnID";
            e.Row.Cells[1].CssClass = "columncourse";
            e.Row.Cells[2].CssClass = "columnyear";
            e.Row.Cells[3].CssClass = "columnmonth";
            e.Row.Cells[4].CssClass = "columnfees";
            e.Row.Cells[5].CssClass = "columndate";
            e.Row.Cells[6].CssClass = "columnremark";

        }

        else if (e.Row.RowType == DataControlRowType.DataRow)
        {
            e.Row.Cells[0].CssClass = "columnID";
            e.Row.Cells[1].CssClass = "columncourse";
            e.Row.Cells[2].CssClass = "columnyear";
            e.Row.Cells[3].CssClass = "columnmonth";
            e.Row.Cells[4].CssClass = "columnfees";
            e.Row.Cells[5].CssClass = "columndate";
            e.Row.Cells[6].CssClass = "columnremark";
            e.Row.Cells[7].Visible = false;


        }
    }
    protected void GridCourse_PageIndexChanged(object sender, EventArgs e)
    {
        
    }
    protected void GridCourse_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grddiaplay();
       
    }
}




