﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Linq;
using System.Net;
using System.Net.Cache;
using BPABusinessLayer;
using BPAMailLayer;
using System.Data;


 
    public partial class BPAMessaging : System.Web.UI.Page
    {
        BPABLData obj = new BPABLData();
        Mail message = new Mail();
       
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {
                DataTable dt = new DataTable();
                int id;
                dt = obj.MessageUserDisplay();
                GridView1.DataSource = dt;
                GridView1.DataBind();
             //   GridInbox.DataSource = obj.BindMessageInbox(Convert.ToInt32(Session["UserId"]));
               // GridInbox.DataBind();
                // GridView2.DataSource = obj.BindMessageInbox(id);      
            }

            PanelNewmessage.Visible = true;
            PanelInbox.Visible = false;
            PanelOutbox.Visible = false;


        }
        int i = 0;
        int l = 0;
        int rowindex = 0;

        protected void BtSend_Click(object sender, EventArgs e)
        {
            try
            {

                DataTable dt = new DataTable();
                dt = obj.MessageUserDisplay();
                string email = dt.Rows[0][2].ToString();
                string user = "chinna.yarram";
                string pass = dt.Rows[0][4].ToString();
                string msg = TextBox1.Text;
                i++;

                String number = GridView1.Rows[rowindex].Cells[4].Text;


                String mURL = "http://www.onl9class.com/smsapi/smsir.php?email=" + email + "&user=" + user + "&pass=" + pass + "&number=" + number + "&msg=" + HttpContext.Current.Server.UrlEncode(msg); ;

                HttpWebRequest req = (HttpWebRequest)WebRequest.Create(mURL);
                HttpWebResponse myResp = (HttpWebResponse)req.GetResponse();
                System.IO.StreamReader respStreamReader = new System.IO.StreamReader(myResp.GetResponseStream());
                string responseString = respStreamReader.ReadToEnd();
                respStreamReader.Close();
                myResp.Close();
            }
            catch
            { 
            
            Label1.Text="Please Check network Connection";
            }
        }


           // int i = 0;
            protected void sendmessagetomobile()
            {
                
                DataTable dt = new DataTable();
                dt = obj.MessageUserDisplay();
                string email = dt.Rows[0][2].ToString();
                string user = "chinna.yarram";
                string pass = dt.Rows[0][4].ToString();
                string msg = TextBox1.Text;
                i++;

                String number = GridView1.Rows[rowindex].Cells[4].Text;


                String mURL = "http://www.onl9class.com/smsapi/smsir.php?email=" + email + "&user=" + user + "&pass=" + pass + "&number=" + number + "&msg=" + HttpContext.Current.Server.UrlEncode(msg); ;

                HttpWebRequest req = (HttpWebRequest)WebRequest.Create(mURL);
                HttpWebResponse myResp = (HttpWebResponse)req.GetResponse();
                System.IO.StreamReader respStreamReader = new System.IO.StreamReader(myResp.GetResponseStream());
                string responseString = respStreamReader.ReadToEnd();
                respStreamReader.Close();
                myResp.Close();
            }
       


            protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
            {
                CheckBox cb = (CheckBox)sender;
                if (cb.Checked)
                {
                    rowindex = ((GridViewRow)cb.Parent.Parent).RowIndex;
                    sendmessagetomobile();
                    if (l == 0)
                    {
                        Bindmessage();
                        l++;
                    }
                    BindMessageRecepients();
                    Label1.Text = "The Message has been sent ";


                } 
            }

            public void Bindmessage()
            {
                obj.AddMessages(TextBox1.Text, Convert.ToInt32(Session["UserId"]));

            }


            public void BindMessageRecepients()
            {
                obj.AddMessagesrecipients(Convert.ToInt32(Session["UserId"]), Convert.ToInt32(GridView1.Rows[rowindex].Cells[1].Text));

            }








            protected void GridView1_RowCreated(object sender, GridViewRowEventArgs e)
            {
                if (e.Row.RowType == DataControlRowType.Header)
                {
                    e.Row.Cells[3].Visible = false;
                    e.Row.Cells[5].Visible = false;

                }
                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    e.Row.Cells[3].Visible = false;
                    e.Row.Cells[5].Visible = false;

                }
            }
            protected void Btninbox_Click(object sender, EventArgs e)
            {
                PanelInbox.Visible = true;
            }
}

