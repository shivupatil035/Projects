﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using BPABusinessLayer;
public partial class DisplayDashboardDetails : System.Web.UI.Page
{
    BPABLData obj = new BPABLData();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.QueryString["Meetingid"] != null)
        {
            int id = Convert.ToInt16(Request.QueryString["Meetingid"]);
            GridView1.DataSource = obj.MeetingDashboardDisplay(id);
            GridView1.DataBind();
             
        }
        if (Request.QueryString["EventId1"] != null)
        {
            int id = Convert.ToInt16(Request.QueryString["EventId1"]);
            GridView1.DataSource = obj.EventDashboardDisplay(id);
            GridView1.DataBind();
        }
        if (Request.QueryString["Mailid"] != null)
        {
            int id = Convert.ToInt32(Request.QueryString["Mailid"]);
            GridView1.DataSource=obj.MailDashboardDisplay(id);
            GridView1.DataBind();
        }
        if (Request.QueryString["Userid"] != null)
        {
            int id = Convert.ToInt32(Request.QueryString["Userid"]);
            GridView1.DataSource = obj.TeamleadDashboardDisplay(id);
            GridView1.DataBind();

        }


    }
}