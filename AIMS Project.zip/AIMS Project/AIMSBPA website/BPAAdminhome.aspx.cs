﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BPABusinessLayer;
using System.Data;

public partial class BPAAdminhome : System.Web.UI.Page
{
    BPABLData obj = new BPABLData();
    protected void Page_Load(object sender, EventArgs e)
    {
        DataTable dt = new DataTable();
        dt = obj.EventDashboard();
        GridEvent.DataSource = dt;
        GridEvent.DataBind();
       // ListView1.DataSource = dt;
        //ListView1.DataBind();
        dt = obj.MeetingDashboard();
        GridMeeting.DataSource = dt;
        GridMeeting.DataBind();
        int userid = Convert.ToInt32(Session["user"]);
        dt = obj.MailDashboard(userid);
        GridMail.DataSource = dt;
        GridMail.DataBind();
        dt = obj.TeamDashboard();
        GridTeamlead.DataSource = dt;
        GridTeamlead.DataBind();
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {

        LinkButton lb = (LinkButton)sender;
        ListViewItem li = (ListViewItem)lb.Parent;

        Label lbldelete = (Label)li.FindControl("Label1");
        int id = Convert.ToInt32(lbldelete.Text);


        Response.Redirect("DisplayDashboardDetails.aspx?EventId1=" + id);
    }

    protected void LBMail_Click(object sender, EventArgs e)
    {


        LinkButton lb = (LinkButton)sender;
        ListViewItem li = (ListViewItem)lb.Parent;

        Label lbldelete = (Label)li.FindControl("Label1");
        int id = Convert.ToInt32(lbldelete.Text);


        Response.Redirect("DisplayDashboardDetails.aspx?Mailid=" + id);

    }
    protected void LBMeeting_Click(object sender, EventArgs e)
    {
        LinkButton lb = (LinkButton)sender;
        ListViewItem li = (ListViewItem)lb.Parent;

        Label lbldelete = (Label)li.FindControl("Label1");
        int id = Convert.ToInt32(lbldelete.Text);

        Response.Redirect("DisplayDashboardDetails.aspx?Meetingid=" + id);

    }
    protected void LBTeamlead_Click(object sender, EventArgs e)
    {
        LinkButton lb = (LinkButton)sender;
        ListViewItem li = (ListViewItem)lb.Parent;

        Label lbldelete = (Label)li.FindControl("Label1");
        int id = Convert.ToInt32(lbldelete.Text);

        Response.Redirect("DisplayDashboardDetails.aspx?Userid=" + id);

    }
    protected void GridEvent_Init(object sender, EventArgs e)
    {

    }
    protected void GridEvent_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}