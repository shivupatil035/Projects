﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BPABusinessLayer;
using System.Data;

public partial class BPADatabaseView : System.Web.UI.Page
{
    BPABLData obj = new BPABLData();
    static int previous;
    static int present;
    private int index;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            GridView1.DataSource = obj.DatabaseView();
            GridView1.DataBind();
        }
    }
    protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
    {
        CheckBox cb = (CheckBox)sender;
        if (cb.Checked)
        {
            present = ((GridViewRow)cb.Parent.Parent).RowIndex;

            if (previous != -1)
            {
                CheckBox preCb = (CheckBox)GridView1.Rows[previous].Cells[0].FindControl("CheckBox1");
                preCb.Checked = false;
                previous = present;
                present = -1;
            }
            else if (previous == -1)
            {
                previous = present;
                present = -1;
            }


        }

    }
    protected void btnassign_Click(object sender, EventArgs e)
    {
        foreach (GridViewRow r in GridView1.Rows)
        {
            CheckBox cb = (CheckBox)r.FindControl("CheckBox1");
            if (cb.Checked)
            {
                GridViewRow row = (GridViewRow)cb.Parent.Parent;
                index = row.RowIndex;

                var id = (GridView1.Rows[index].Cells[2].Text);
                Response.Redirect("BPADatabaseAssign.aspx?id=" + id);
            }
        }
        GridView1.DataSource = obj.DatabaseView();
        GridView1.DataBind();
    
    }
    protected void btndelete_Click(object sender, EventArgs e)
    {
        foreach (GridViewRow r in GridView1.Rows)
        {
            CheckBox cb = (CheckBox)r.FindControl("CheckBox1");
            if (cb.Checked)
            {
                GridViewRow row = (GridViewRow)cb.Parent.Parent;
                index = row.RowIndex;

            lblmessage.Text = obj.DeleteDB(Convert.ToInt32(GridView1.Rows[index].Cells[2].Text));
            }
        }
        GridView1.DataSource = obj.DatabaseView();
        GridView1.DataBind();
    }


    protected void GridView1_RowCreated(object sender, GridViewRowEventArgs e)
    {



        if (e.Row.RowType == DataControlRowType.Header)
        {
            e.Row.Cells[0].Text = "Select";
            e.Row.Cells[1].Text = "Admin ID";
            e.Row.Cells[2].Visible = false;
            e.Row.Cells[3].Text = "Database Name";
            e.Row.Cells[4].Text = "Created Date";
            e.Row.Cells[5].Text = "Team lead ID";
            e.Row.Cells[6].Text = "Assigned Date";
            e.Row.Cells[7].Text = "Description";
            e.Row.Cells[8].Text = "Status";
            

            e.Row.Cells[0].CssClass = "select";
            e.Row.Cells[1].CssClass = "adminid";
            e.Row.Cells[3].CssClass = "DBname";
            e.Row.Cells[4].CssClass = "cdate";
            e.Row.Cells[5].CssClass = "tlid";
            e.Row.Cells[6].CssClass = "adate";
            e.Row.Cells[7].CssClass = "desc";
            e.Row.Cells[8].CssClass = "Status";
            

        }

        else if (e.Row.RowType == DataControlRowType.DataRow)
        {
            e.Row.Cells[0].CssClass = "select";
            e.Row.Cells[1].CssClass = "adminid";
            e.Row.Cells[2].Visible = false;
            e.Row.Cells[3].CssClass = "DBname";
            e.Row.Cells[4].CssClass = "cdate";
            e.Row.Cells[5].CssClass = "tlid";
            e.Row.Cells[6].CssClass = "adate";
            e.Row.Cells[7].CssClass = "desc";
            e.Row.Cells[8].CssClass = "Status";
            


        }
        

    }
    protected void btnsearch_Click(object sender, EventArgs e)
    {
        DataTable dt = obj.SearchDB(txtsearch.Text);
        if (dt.Rows.Count > 0)
        {
            GridView1.DataSource = dt;
            GridView1.DataBind();
            lblmessage.Text = "No of record(s) found " + dt.Rows.Count.ToString();
        }
        else
        {
            GridView1.DataSource = null;
            GridView1.DataBind();
            lblmessage.Text = "No Records found matching your criteria";
        }
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.DataSource = obj.DatabaseView();
        GridView1.DataBind();
        GridView1.PageIndex = e.NewPageIndex;

    }
}
