﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BPABusinessLayer;
using System.Data;

public partial class BPAPerformanceReport : System.Web.UI.Page
{
    BPABLData obj = new BPABLData();
    int index = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {

            GridPerformance.DataSource = obj.PerfomanceReport();
            GridPerformance.DataBind();
        }
    }

    protected void GridPerformance_RowCreated(object sender, GridViewRowEventArgs e)
    {


        if (e.Row.RowType == DataControlRowType.Header)
        {
            e.Row.Cells[0].Visible = false;
            e.Row.Cells[1].Text = "Sales Representatives";
            e.Row.Cells[2].Text = "No. of Enqueries ";
            e.Row.Cells[3].Text = "No. of Followups";
            e.Row.Cells[4].Text = "No. of Admissions";
            e.Row.Cells[5].Text = "Revenue";

            e.Row.Cells[0].Visible = false;
            e.Row.Cells[1].CssClass = "cdesc";
            e.Row.Cells[2].CssClass = "cadminid";
            e.Row.Cells[3].CssClass = "cDBname";
            e.Row.Cells[4].CssClass = "cDBname";
            e.Row.Cells[5].CssClass = "cDBname";


        }

        else if (e.Row.RowType == DataControlRowType.DataRow)
        {
            e.Row.Cells[0].Visible = false;
            e.Row.Cells[1].CssClass = "desc";
            e.Row.Cells[2].CssClass = "DBname";
            e.Row.Cells[3].CssClass = "DBname";
            e.Row.Cells[4].CssClass = "DBname";
            e.Row.Cells[5].CssClass = "select";



        }
        

    }
    

    protected void Link2_Click(object sender, EventArgs e)
    {
        LinkButton lb = (LinkButton)sender;
        GridViewRow row = (GridViewRow)lb.Parent.Parent;
      int r=  row.RowIndex;

      string id = GridPerformance.Rows[r].Cells[0].Text;
      Response.Redirect("~/BPATLEnquiryList.aspx?stid=" + id);
    }

    protected void Link3_Click(object sender, EventArgs e)
    {
        LinkButton lb = (LinkButton)sender;
        GridViewRow row = (GridViewRow)lb.Parent.Parent;
        int r = row.RowIndex;

        string id1 = GridPerformance.Rows[r].Cells[0].Text;
        Response.Redirect("~/BPATLEnquiryList.aspx?stid1=" + id1);
    }
    protected void Link4_Click(object sender, EventArgs e)
    {
        LinkButton lb = (LinkButton)sender;
        GridViewRow row = (GridViewRow)lb.Parent.Parent;
        int r = row.RowIndex;

        string id2 = GridPerformance.Rows[r].Cells[0].Text;
        Response.Redirect("~/BPATLEnquiryList.aspx?stid2=" + id2);

    }
}
