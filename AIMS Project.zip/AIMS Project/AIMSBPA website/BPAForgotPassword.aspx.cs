﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Net.Mail;
using BPABusinessLayer;

public partial class BPAForgotPassword : System.Web.UI.Page
{
    BPABLData obj = new BPABLData();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void txtPassword_TextChanged(object sender, EventArgs e)
    {

    }
    protected void btnclass_Click(object sender, EventArgs e)
    {
 MailMessage mail=new MailMessage();
        int i = 0;
        DataTable dt = new DataTable();
        dt = obj.Forgot(txtEmail.Text);
        if (dt.Rows.Count > 0)
        {
            while (i < dt.Rows.Count)
            {
                DataRow dr = dt.Rows[0];
                if (txtEmail.Text == dr[1].ToString())
                { 
                    mail.To.Add(dr[1].ToString());
                    DataTable dt1 = new DataTable();
                    dt1 = obj.selectRole();
                    DataRow dr1 = dt1.Rows[0];
                    if (Convert.ToInt16(dr1[2])== 111)
                    {
                       
                            mail.From = new MailAddress(dr1[0].ToString());
                            mail.Subject = "Test mail & a wish......";
                            mail.Body = "this is your password=" + dr[0].ToString() + "Do you want to change your password click here http://localhost:64625/AIMSBPA%20website/BPAChangePassword.aspx ";
                            SmtpClient client = new SmtpClient("smtp.gmail.com");
                            client.Credentials = new System.Net.NetworkCredential(dr1[0].ToString(), dr1[1].ToString());


                            client.Port = 587;
                            client.EnableSsl = true;
                            client.Send(mail);
                            lblpass.Text = "The password has sent to your mail";
                       
                  }
                      
                }
                else
                {
                    lblpass.Text = "invalid Email";
                }
                i++;
            }
        }
        else
        {
            lblpass.Text = "invalid Email";
        }

    }
    }
