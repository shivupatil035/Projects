﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BPABusinessLayer;

public partial class BPATeamLeadReport : System.Web.UI.Page
{
    BPABLData obj = new BPABLData();
    protected void Page_Load(object sender, EventArgs e)
    {
        DropDownList1.DataSource = obj.TeamLeadList();
        DropDownList1.DataTextField = "FirstName";
        DropDownList1.DataValueField = "UserId";
        DropDownList1.DataBind();

    }

    protected void Button1_Click1(object sender, EventArgs e)
    {
        Response.Redirect("TeamleadReportViewer.aspx?ReportingTo=" + DropDownList1.SelectedValue.ToString());
    }
    protected void BtDuration_Click1(object sender, EventArgs e)
    {
        try
        {
            //if (DropDownList2.SelectedIndex == 0)
            //{ 

            //}
            string dl1 = DropDownList2.SelectedValue;
            string dl2 = DropDownList3.SelectedValue;
            Response.Redirect("TeamleadReportViewer.aspx?From=" + dl1 + "&To=" + dl2);
        }
        catch
        {
            Label1.Text = "Something went wrong";
        }
    }

    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {  
           int s = Convert.ToInt32(DropDownList2.SelectedValue);
            s = s - 1;
            while (s > 2009)
            {

                DropDownList3.Items.Remove(s.ToString());
                s = s - 1;

            }

        }
    protected void  DropDownList3_SelectedIndexChanged(object sender, EventArgs e)
{

}
}


