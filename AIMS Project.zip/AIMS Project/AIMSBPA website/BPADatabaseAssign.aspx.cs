﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BPABusinessLayer;
using System.Data;

public partial class BPADatabaseAssign : System.Web.UI.Page
{
     int dbid = 0;
    string status = null;
    BPABLData obj = new BPABLData();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            ddlassign.DataSource = obj.ListUser();
            ddlassign.DataTextField = "FirstName";
            ddlassign.DataValueField = "UserId";
            ddlassign.DataBind();
            ddlassign.Items.Insert(0, "--Select--");

            ddldbname.DataSource = obj.GetBDId();
            ddldbname.DataTextField = "DatabaseName";
            ddldbname.DataValueField = "DatabseId";
            ddldbname.DataBind();
            ddldbname.Items.Insert(0, "--Select--");


             if (Request.QueryString["id"] != null)
            {
                DataTable dt = obj.FetchDB(Convert.ToInt16(Request.QueryString["id"]));
                //dbid = Convert.ToInt16(dt.Rows[0][0]);
                ddldbname.SelectedValue = dt.Rows[0][0].ToString();
               // ddlassign.SelectedValue = dt.Rows[0][2].ToString();
                txtdescription.Text = dt.Rows[0][1].ToString();
                Button1.Text = "Update";

            }
        }
        }

    
    protected void Button1_Click(object sender, EventArgs e)
    { 
        if(Button1.Text=="Assign now")
        {
          lblmessage.Text = obj.AssignDatabase(Convert.ToInt32(ddldbname.SelectedValue), Convert.ToInt32(ddlassign.SelectedValue), txtdescription.Text);
        }
         else
        {                int dbid = Convert.ToInt32(Request.QueryString["id"]);

        lblmessage.Text = obj.UpdateDB(Convert.ToInt32(ddldbname.SelectedValue), Convert.ToInt32(ddlassign.SelectedValue), txtdescription.Text);
            }
    }
}