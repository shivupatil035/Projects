﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using BPABusinessLayer;

public partial class BPAMeetingView : System.Web.UI.Page
{
    BPABLData obj = new BPABLData();
    static int previous;
    static int present;
    private int index;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            GridView1.DataSource = obj.DisplayMeeting();
            GridView1.DataBind();
        }

    }
    protected void BtnEdit_Click(object sender, EventArgs e)
    {
        foreach (GridViewRow r in GridView1.Rows)
        {
            CheckBox cb = (CheckBox)r.FindControl("CheckBox1");
            if (cb.Checked)
            {
                GridViewRow row = (GridViewRow)cb.Parent.Parent;
                index = row.RowIndex;

                var meetingId = (GridView1.Rows[index].Cells[1].Text);
                Response.Redirect("BPAMeetingAdd.aspx?meetingId=" + meetingId);
            }
        }
        GridView1.DataSource = obj.DisplayMeeting();
        GridView1.DataBind();
    }
    protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
    {

    }
    protected void btSearchid_Click(object sender, EventArgs e)
    {
        DataTable dt = obj.SearchMeeting(txtname.Text,txtmeetingid.Text);
         if (dt.Rows.Count > 0)
        {
        GridView1.DataSource = dt;
        GridView1.DataBind();
             Label1.Text="No of record(s) found " + dt.Rows.Count.ToString();
         }
         else
         {
             GridView1.DataSource=null;
              GridView1.DataBind();
             Label1.Text = "No Records found matching your criteria";
         }
    }
   
    protected void btSearchname_Click(object sender, EventArgs e)
    {
        DataTable dt = obj.SearchMeeting(txtname.Text,txtmeetingid.Text);
        if (dt.Rows.Count > 0)
        {
            GridView1.DataSource = dt;
            GridView1.DataBind();
            Label1.Text = "No of record(s) found " + dt.Rows.Count.ToString();
        }
        else
        {
            GridView1.DataSource = null;
            GridView1.DataBind();
            Label1.Text = "No Records found matching your criteria";
        }
    }
    protected void BtnDelete_Click(object sender, EventArgs e)
    {
        foreach (GridViewRow r in GridView1.Rows)
        {
            CheckBox cb = (CheckBox)r.FindControl("CheckBox1");
            if (cb.Checked)
            {
                GridViewRow row = (GridViewRow)cb.Parent.Parent;
                index = row.RowIndex;

                Label1.Text = obj.MeetingDeactive(Convert.ToInt32(GridView1.Rows[index].Cells[1].Text));
            }
        }
        GridView1.DataSource = obj.DisplayMeeting();
        GridView1.DataBind();
    }
    protected void GridView1_RowCreated(object sender, GridViewRowEventArgs e)
    {

        if (e.Row.RowType == DataControlRowType.Header)
        {
            e.Row.Cells[0].Text = "Select";
            e.Row.Cells[1].Text = "Meeting ID";
            e.Row.Cells[2].Text = "Meeting Name";
            e.Row.Cells[3].Text = "Message";
            e.Row.Cells[4].Text = "Created Date";
            e.Row.Cells[5].Text = "From";
            e.Row.Cells[6].Text = "To";
            e.Row.Cells[7].Text = "Description";
           // e.Row.Cells[8].Visible = false;
          


            e.Row.Cells[0].CssClass = "select";
            e.Row.Cells[1].CssClass = "adminid";
            e.Row.Cells[2].CssClass = "DBname";
            e.Row.Cells[3].CssClass = "cdate";
            e.Row.Cells[4].CssClass = "tlid";
            e.Row.Cells[5].CssClass = "adate";
            e.Row.Cells[6].CssClass = "desc";
            e.Row.Cells[7].CssClass = "Status";
            
            
        }

        else if (e.Row.RowType == DataControlRowType.DataRow)
        {
            e.Row.Cells[0].CssClass = "select";
            e.Row.Cells[1].CssClass = "adminid";
            e.Row.Cells[2].CssClass = "DBname";
            e.Row.Cells[3].CssClass = "cdate";
            e.Row.Cells[4].CssClass = "tlid";
            e.Row.Cells[5].CssClass = "adate";
            e.Row.Cells[6].CssClass = "desc";
            e.Row.Cells[7].CssClass = "Status";
          //  e.Row.Cells[8].Visible=false;



        }
        
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.DataSource = obj.DisplayMeeting();
        GridView1.DataBind();
        GridView1.PageIndex = e.NewPageIndex;
    }
}