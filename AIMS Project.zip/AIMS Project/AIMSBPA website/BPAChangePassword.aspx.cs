﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using BPABusinessLayer;

public partial class BPAChangePassword : System.Web.UI.Page
{
    BPABLData obj = new BPABLData();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnclass_Click(object sender, EventArgs e)
    {
        DataTable dt = new DataTable();
        dt = obj.SelectPassword();
        if (dt.Rows.Count > 0)
        {
            DataRow dr = dt.Rows[0];
            if (txtoldpass.Text == dr[0].ToString())
            {
                obj.ChangePass(txtnewpass.Text, txtoldpass.Text);
                lblValid.Text = "password has been changed";
            }
        }
    }
}