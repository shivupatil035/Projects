﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BPABusinessLayer;
using System.Data;
using System.Data.SqlClient;

public partial class BPAMeetingAdd : System.Web.UI.Page
{
    BPABLData obj = new BPABLData();
    int meetingId = 0;
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            if (Request.QueryString["meetingId"] != null)
            {
                DataTable dt = obj.SelectMeetingId(Convert.ToInt16(Request.QueryString["meetingId"]));
                meetingId = Convert.ToInt16(dt.Rows[0][0]);
                TxtSub.Text = dt.Rows[0][1].ToString();

                TxtMessage.Text = dt.Rows[0][2].ToString();
                datepicker.Text = dt.Rows[0][3].ToString();
                TxtStartTime.Text = dt.Rows[0][4].ToString();
                TxtEndTime.Text = dt.Rows[0][5].ToString();
                TxtLocation.Text = dt.Rows[0][6].ToString();
                Button1.Text = "Update";

            }
        }
    }

    public void clear()
    {
        TxtSub.Text = "";
        TxtMessage.Text = "";
        TxtStartTime.Text = "";
        TxtEndTime.Text = "";
        TxtLocation.Text = "";
        datepicker.Text = "";
    }
    
    
    
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (Button1.Text == "Add")
        {
           

                Label1.Text = obj.Addmeeting(TxtSub.Text, TxtMessage.Text, Convert.ToDateTime(datepicker.Text), TxtStartTime.Text, TxtEndTime.Text, TxtLocation.Text);
                clear();
        }
        else
        {
            int meetingid = Convert.ToInt32(Request.QueryString["meetingId"]);
            Label1.Text = obj.updateNeeting(meetingid, TxtSub.Text, TxtMessage.Text, Convert.ToDateTime(datepicker.Text), TxtStartTime.Text, TxtEndTime.Text, TxtLocation.Text);
            clear();
        }
    }
}
