﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BPABusinessLayer;
using System.Data;
public partial class BPACourseMasterEdit : System.Web.UI.Page
{
     static int previous = -1;
    static int present = -1;
    BPABLData obj = new BPABLData();
    protected void Page_Load(object sender, EventArgs e)
    {
         if (!IsPostBack)
        {

           GridCourse.DataSource = obj.SelectCourse();
            GridCourse.DataBind();
        
        }
    }
    protected void btnedit_Click(object sender, EventArgs e)
    {
        foreach (GridViewRow grd in GridCourse.Rows)
        {
            CheckBox cb = (CheckBox)grd.FindControl("CheckBox1");
            if (cb.Checked)
            {
                int index = -1;
                GridViewRow row = (GridViewRow)cb.Parent.Parent;
                index = row.RowIndex;
                int id = Convert.ToInt32(GridCourse.Rows[index].Cells[1].Text);
                Response.Redirect("~/BPACourseMasterAdd.aspx?stid=" + id);
            }
        }
  
    
    }
    protected void btndelete_Click(object sender, EventArgs e)
    {
          int index = -1;
        foreach (GridViewRow r in GridCourse.Rows)
        {
            CheckBox cb = (CheckBox)r.FindControl("CheckBox1");
            if (cb.Checked)
            {
                GridViewRow row = (GridViewRow)cb.Parent.Parent;
                index = row.RowIndex;

                lbldeletemsg.Text = obj.DeleteCourse(Convert.ToInt32(GridCourse.Rows[index].Cells[1].Text));


            }
        }

        GridCourse.DataSource = obj.SelectCourse();
        GridCourse.DataBind();
    }



    protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
    {
        
        CheckBox cb = (CheckBox)sender;
        if (cb.Checked)
        {
            GridViewRow r = (GridViewRow)cb.Parent.Parent;
            present = r.RowIndex;

            if (previous == -1)
            {
                previous = present;
                present = -1;
            }
            else if (previous != -1)
            {
                CheckBox cbPre = (CheckBox)GridCourse.Rows[previous].FindControl("CheckBox1");
                cbPre.Checked = false;
                previous = present;
                present = -1;
            }
        }
    }
   
    protected void GridCourse_RowCreated(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType==DataControlRowType.Header)
        {
            e.Row.Cells[0].Text = "Select";
            e.Row.Cells[1].Text = "Course ID";
            e.Row.Cells[2].Text="Course Name";
            e.Row.Cells[3].Text = "Course Year";
            e.Row.Cells[4].Text = "Course Month";
            e.Row.Cells[5].Text = "Course Fees";
            e.Row.Cells[6].Text = "Date of Creation";
            e.Row.Cells[7].Text = "Remark";
            e.Row.Cells[8].Visible = false;
            e.Row.Cells[0].CssClass = "columnselect";
            e.Row.Cells[1].CssClass = "columnID";
            e.Row.Cells[2].CssClass = "columncourse";
            e.Row.Cells[3].CssClass = "columnyear";
            e.Row.Cells[4].CssClass = "columnmonth";
            e.Row.Cells[5].CssClass = "columnfees";
            e.Row.Cells[6].CssClass = "columndate";
            e.Row.Cells[7].CssClass = "columnremark";

        }

        else if (e.Row.RowType == DataControlRowType.DataRow)
        {
            e.Row.Cells[1].CssClass = "columnID";
            e.Row.Cells[2].CssClass = "columncourse";
            e.Row.Cells[3].CssClass = "columnyear";
            e.Row.Cells[4].CssClass = "columnmonth";
            e.Row.Cells[5].CssClass = "columnfees";
            e.Row.Cells[6].CssClass = "columndate";
            e.Row.Cells[7].CssClass = "columnremark";
            e.Row.Cells[8].Visible = false;
            

        }
    }



    protected void btnsearch_Click(object sender, EventArgs e)
    {
        DataTable dt = obj.SearchCourse(txtsearch.Text);
        if (dt.Rows.Count > 0)
        {
            GridCourse.DataSource = dt;
            GridCourse.DataBind();
            lbldeletemsg.Text = "No of record(s) found " + dt.Rows.Count.ToString();
        }
        else
        {
            GridCourse.DataSource = null;
            GridCourse.DataBind();
            lbldeletemsg.Text = "No Records found matching your criteria";
        }


    }
  
    protected void GridCourse_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridCourse.DataSource = obj.SelectCourse();
        GridCourse.DataBind();
        GridCourse.PageIndex = e.NewPageIndex;
    }
}

    