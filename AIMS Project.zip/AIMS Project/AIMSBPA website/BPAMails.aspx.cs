﻿using System;
using System.Collections;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Net.Mail;
using BPABusinessLayer;
using BPAMailLayer;

public partial class BPAMails : System.Web.UI.Page
{
    BPABLData obj = new BPABLData();
    Mail ml = new Mail(); 
    protected void Page_Load(object sender, EventArgs e)
    {
        PanelInbox.Visible = false;
        PanelOutbox.Visible = false;
        if (!IsPostBack)
        {
            
            GridView1.DataSource = obj.ListBoxBound();
            GridView1.DataBind();
            DropDownList1.DataSource = obj.ListBoxBound();
            DropDownList1.DataTextField = "FirstName";
            DropDownList1.DataValueField = "UserId";
            DropDownList1.DataBind();
            DropDownList1.Items.Insert(0, "--Select--");

            GridView2.DataSource = obj.BindInbox();
            GridView2.DataBind();

            GridOutbox.DataSource = obj.BindOutbox();
            GridOutbox.DataBind();

          //  GridView1.PageIndex = e.NewPageIndex;
        }
    }


    protected void BtSend_Click(object sender, EventArgs e)
    {

     //   lblMessage.Text = "Please check network connection";
       // Bind();  
    }
    int l = 0;
    int rowindex = 0;
    protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
    {
        
        if (l == 0)
        {
            Bind();
            l++;
        }
        try
        {

            CheckBox cb = (CheckBox)sender;
            if (cb.Checked)
            {

                rowindex = ((GridViewRow)cb.Parent.Parent).RowIndex;
                BindMailRecepients();
                byte[] f = FileUpload1.FileBytes;
                MemoryStream stream = new MemoryStream(f);
                // Attachment attachment=new Attachment(stream,
                ml.mail(GridView1.Rows[rowindex].Cells[3].Text, TxtSubject.Text, TxtBody.Text, FileUpload1.FileName);
                //MailMessage mail = new MailMessage();

                //mail.To.Add(GridView1.Rows[rowindex].Cells[3].Text);
                //mail.From = new MailAddress("shivupatil035@gmail.com");
                //mail.Subject = TxtSubject.Text;
                //mail.Body = TxtBody.Text;
                //mail.Attachments.Add(Attachment.CreateAttachmentFromString(FileUpload1.FileName,"attached"));
                //SmtpClient client = new SmtpClient("smtp.gmail.com");
                //client.Credentials = new System.Net.NetworkCredential("shivupatil035@gmail.com", "9686052545");


                //client.Port = 587;
                //client.EnableSsl = true;
                //client.Send(mail);

                lblMessage.Text = "The mail's has been sent ";
            }
        }
        catch
        {
            lblMessage.Text = "Please check network connection";        
        }
        
    }
    public void Bind()
    {
        obj.AddMails(TxtSubject.Text, TxtBody.Text, Convert.ToInt32(DropDownList1.SelectedValue), FileUpload1.FileName);
    }
    public void BindMailRecepients()
    {
        lblMessage.Text = obj.AddMailRecepients(Convert.ToInt32(DropDownList1.SelectedValue), Convert.ToInt32(GridView1.Rows[rowindex].Cells[1].Text));
    }

    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.DataSource = obj.ListBoxBound();
        GridView1.DataBind();
            
        GridView1.PageIndex = e.NewPageIndex;
        
    }
    protected void BtSend_Command(object sender, CommandEventArgs e)
    {

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Panel2.Visible = false;
        PanelInbox.Visible = true;
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Panel2.Visible = true;
        PanelInbox.Visible = false;
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        PanelOutbox.Visible = true;
        PanelInbox.Visible = false;
        Panel2.Visible = false;
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        LinkButton l = (LinkButton)sender;
        string email = l.Text;
        Response.Redirect("BPAMails.aspx?emailid=" + email);
    }
    protected void GridOutbox_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}

         

    
