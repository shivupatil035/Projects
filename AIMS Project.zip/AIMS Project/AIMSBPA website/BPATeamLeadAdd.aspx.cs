﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using BPABusinessLayer;

public partial class BPATeamLeadAdd : System.Web.UI.Page
{

    int userid = 0;
    string status = null;
    BPABLData obj = new BPABLData();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DropDownList2.DataSource = obj.GetRoles();
            DropDownList2.DataTextField = "Role";
            DropDownList2.DataValueField = "RoleId";
            DropDownList2.DataBind();
            DropDownList2.Items.Insert(0, "--Select--");

            DropDownList1.DataSource = obj.ReportTo();
            DropDownList1.DataTextField = "FirstName";
            DropDownList1.DataValueField = "UserId";
            DropDownList1.DataBind();
            DropDownList1.Items.Insert(0, "--Select--");

            if (Request.QueryString["id"] != null)
            {
                DataTable dt = obj.SelectUserDetails(Convert.ToInt16(Request.QueryString["id"]));
                userid = Convert.ToInt16(dt.Rows[0][0]);
                Txtfname.Text = dt.Rows[0][1].ToString();
                TxtLname.Text = dt.Rows[0][2].ToString();
                Txtemail.Text = dt.Rows[0][3].ToString();
                TxtMobile.Text = dt.Rows[0][4].ToString();
                TxtOffic.Text = dt.Rows[0][5].ToString();
                TxtAddress.Text = dt.Rows[0][6].ToString();
                Txtcite.Text = dt.Rows[0][7].ToString();
                Txtpin.Text = dt.Rows[0][8].ToString();
                Txtquali.Text = dt.Rows[0][9].ToString();
                status = dt.Rows[0][10].ToString();
                if (status == "Male")
                {
                    RadioButton1.Checked = true;

                }
                else if (status == "Female")
                {
                    RadioButton2.Checked = true;
                }
                datepicker.Text = dt.Rows[0][11].ToString();
                // FileUpload1.ToString() = dt.Rows[0][12].ToString();
                DropDownList1.SelectedValue = dt.Rows[0][13].ToString();
                Txtpass.Text = dt.Rows[0][14].ToString();
                DropDownList2.SelectedValue = dt.Rows[0][15].ToString();
                BtnAddCourse.Text = "Update";

            }
        }
    }
    public void Clear()
    {
        Txtfname.Text = "";
        TxtLname.Text = "";
        TxtAddress.Text = "";
        Txtcite.Text = "";
        Txtemail.Text = "";
        TxtMobile.Text = "";
        TxtOffic.Text = "";
        Txtpass.Text = "";
        Txtpin.Text = "";
        Txtquali.Text = "";
        datepicker.Text = "";
        Lblemail.Text = "";
        DropDownList1.SelectedIndex = 0;
        DropDownList2.SelectedIndex = 0;
        RadioButton2.Checked = false;
        RadioButton1.Checked = false;

        
    
    
    
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
       

            string status = null;
            if (RadioButton1.Checked)
            {
                status = RadioButton1.Text;

            }
            else if (RadioButton2.Checked)
            {
                status = RadioButton2.Text;

            }

            if (BtnAddCourse.Text == "Add")
            {
                int i = 0;
                DataTable dt = new DataTable();
                dt = obj.Forgot(Txtemail.Text);
                if (dt.Rows.Count > 0)
                {
                    while (i < dt.Rows.Count)
                    {
                        DataRow dr = dt.Rows[0];

                        if (Txtemail.Text == dr[1].ToString())
                        {
                            Lblemail.Text = "EmailId Already Present";
                            break;
                        }
                    }
                }
                else
                {
                    Label1.Text = obj.AddTeam(Txtfname.Text, TxtLname.Text, Txtemail.Text, Convert.ToInt64(TxtMobile.Text), Convert.ToInt64(TxtOffic.Text), TxtAddress.Text, Txtcite.Text, Convert.ToInt64(Txtpin.Text), Txtquali.Text, status, Convert.ToDateTime(datepicker.Text), FileUpload1.FileName, Convert.ToInt16(DropDownList1.SelectedValue), Txtpass.Text, Convert.ToInt16(DropDownList2.SelectedValue));
                    Clear();
                }
            }
            else
            {

                int userid = Convert.ToInt32(Request.QueryString["id"]);

                Label1.Text = obj.UpdateTeamLead(userid, Txtfname.Text, TxtLname.Text, Txtemail.Text, Convert.ToInt64(TxtMobile.Text), Convert.ToInt64(TxtOffic.Text), TxtAddress.Text, Txtcite.Text, Convert.ToInt64(Txtpin.Text), Txtquali.Text, status, Convert.ToDateTime(datepicker.Text), FileUpload1.FileName, Convert.ToInt16(DropDownList1.SelectedValue), Txtpass.Text, Convert.ToInt16(DropDownList2.SelectedValue));
                Clear();
            }

        
    }
}