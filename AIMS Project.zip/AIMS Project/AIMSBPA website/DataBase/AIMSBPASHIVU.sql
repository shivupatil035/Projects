CREATE DATABASE [AIMSBPA]
USE [AIMSBPA]
-------------------------------------- [BPARoleMaster]--------------------------------------------
CREATE TABLE [dbo]. [BPARoleMaster] 
(
	[RoleId] [int] IDENTITY(1,1) NOT NULL,
	[Role] [varchar] (25) NOT NULL,CONSTRAINT [PK_BPARoleMaster_RoleId] PRIMARY KEY CLUSTERED
(
	[RoleId] ASC
) WITH (PAD_INDEX=OFF,STATISTICS_NORECOMPUTE=OFF, IGNORE_DUP_KEY=OFF,ALLOW_ROW_LOCKS =ON,
ALLOW_PAGE_LOCKS=ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET IDENTITY_INSERT [dbo] .[BPARolemaster] 

 insert into BPARoleMaster(RoleId,Role) values(111,'Admin');
 insert into BPARoleMaster(RoleId,Role) values(222,'TeamLead');
 insert into BPARoleMaster(RoleId,Role) values(333,'SalesReprentative');
 
 select * from BPARoleMaster
-----------------------------------------[BPAUserMaster]--------------------------------------------------

drop table BPAUserMaster

CREATE TABLE [dbo] .[BPAUserMaster]
(
	[UserId] [int] IDENTITY(100,1) NOT NULL,
	[FirstName] [varchar](50) NOT NULL,
	[LastName] [varchar](50) NULL,
	[EmailId] [varchar] (30) NOT NULL,
	[Mobile_Number] [bigint] NOT NULL,
	[Official_Number] [bigint] NULL,
	[Address] [varchar] (150) NOT NULL,
	[City] [varchar] (50)NULL,
	[PinCode] [int] NULL,
	[Qualification] [varchar] (10) NOT NULL,
	[Gender][varchar] (10) NOT NULL,
	[DOB] [datetime] NULL,
	[Photo] [image] NULL,
	[ReportingTo] [int] NULL,
	[Password] [varchar] (30) NOT NULL,
	[RoleId] [int]CONSTRAINT [FK_BPAUserMaster_RoleId] References BPARoleMaster(RoleId) ON DELETE CASCADE ON UPDATE CASCADE NOT NULL,
	
CONSTRAINT [PK_BPAUserMaster_UserId] PRIMARY KEY CLUSTERED
(
	[UserId] ASC
)WITH (PAD_INDEX=OFF,STATISTICS_NORECOMPUTE=OFF,IGNORE_DUP_KEY=OFF,
ALLOW_ROW_LOCKS =ON, ALLOW_PAGE_LOCKS=ON) ON [PRIMARY]
)  ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET IDENTITY_INSERT[dbo]. [BPAUserMaster] ON

 insert into BPAUserMaster(FirstName,LastName,EmailId,Mobile_Number,Official_Number,Address,City,PinCode,Qualification,Gender,DOB,Photo,ReportingTo,Password,RoleId) values('Shivu','Patil','shivupatil035@gmail.com',9686052545,9886223405,'Kamatgi','Bagalkot',587102,'MCA','Male',16/08/1989,NULL,NULL,'Admin',111)
 insert into BPAUserMaster(FirstName,LastName,EmailId,Mobile_Number,Official_Number,Address,City,PinCode,Qualification,Gender,DOB,Photo,ReportingTo,Password,RoleId) values('Sreenivas','Reddy','chinna.yarram@gmail.com',9886858585,9886223405,'Bellary','Bellary',582451,'MCA','Male',11/09/1980,NULL,NULL,'Admin',222)

select * from BPAUserMaster
delete from BPAUserMaster where UserId= 117
------------------------------------------[BPACourseMaster]-----------------------------------------------
drop table BPACourseMaster
CREATE TABLE [dbo].[BPACourseMaster]
(
	[CourseId] [int] IDENTITY(10,1) NOT NULL,
	[Course] [varchar] (30) NOT NULL,
	[CourseDurationYear][int] NOT NULL,
	[CourseDurationMonth][int] NOT NULL,
	[CourseFees] [money] NOT NULL,
	[Date] [datetime] default(getdate()) NOT NULL,
	[Remarks] [varchar] (50) NULL,
CONSTRAINT [PK_BPACourseMaster_CourseId] PRIMARY KEY CLUSTERED
(
	[CourseId] ASC
)
WITH (PAD_INDEX=OFF,STATISTICS_NORECOMPUTE =OFF,IGNORE_DUP_KEY=OFF,
ALLOW_ROW_LOCKS=ON,ALLOW_PAGE_LOCKS=ON) ON  [PRIMARY]
)  ON [PRIMARY]
GO
SET ANSI_PADDING OFF

select * from BPACourseMaster
insert into BPACourseMaster (Course,CourseDurationYear,CourseDurationMonth,CourseFees,Remarks) values('ASP',1,6,5000,'which include materials')  
------------------------------------------------------------------------------------------------------
CREATE TABLE [dbo].[BPACourseMasterAssign]
(
	[CourseAssignId] [int] References BPACourseMaster(CourseId)  NOT NULL,
	[CourseAssgnTo] [int]  References BPAuserMaster(UserId)  NOT NULL,
	[CourseAssignedDate] [datetime] default(getdate()) NOT NULL,
	[Remarks] [varchar] (50) NULL
)
select * from [BPACourseMasterAssign]
insert into [BPACourseMasterAssign] (CourseAssignId,CourseAssgnTo,Remarks) values(10,106,'which include materials')  
--------------------------------------ProCourseList---------------------------------------------------------------
create Procedure ProCourseList
as
select CourseId,course from BPACourseMaster  
exec ProCourseList
---------------------------------------ProCouseUserList----------------------------------------------------------------
alter procedure ProCouseUserList
as
select Userid,FirstName from BPAUserMaster where RoleId=222
exec ProCouseUserList
---------------------------------------------------------------------------------------------------------------
create procedure ProAssignCourse (@CourseAssignId int,@CourseAssgnTo int,@Remarks varchar(50))
as
insert into [BPACourseMasterAssign](CourseAssignId,CourseAssgnTo,Remarks )
values(@CourseAssignId,@CourseAssgnTo,@Remarks)

---------------------------------------------------------------------------------------------------------------
create procedure ProSearchCourse @Course varchar(50),@CourseId int
as
select CourseId, Course,CourseDurationYear,CourseDurationMonth,CourseFees,Remarks from 
BPACourseMaster where Course like @Course or CourseId like @CourseId
exec ProSearchCourse ASP ,10
-------------------------------ProAddCourse--------------------------------------------------------
 
create procedure ProAddCourse (@Course varchar(30),@CourseDurationYear int,@CourseDurationMonth int,@CourseFees money ,@Remarks varchar(50))
as
insert into BPACourseMaster(Course,CourseDurationYear,CourseDurationMonth,CourseFees,Remarks)
values(@Course,@CourseDurationYear,@CourseDurationMonth,@CourseFees,@Remarks)

----------------------------------ProLoginList-----------------------------------------------------

create Procedure ProLoginList @EmailId varchar(50)
as
select * from BPAUserMaster where EmailId=@EmailId 
exec ProLoginList 'shivupatil035@gmail.com'

--------------------------------GetRoles-------------------------------------------------------------

create procedure GetRoles
as
select * from BPARoleMaster
exec GetRoles

--------------------------------------ProReportingTo-------------------------------------------------------

create procedure ProReportingTo
as
select * from BPAUserMaster
 
 exec ProReportingTo
-----------------------------------ProAddTeamlead ------------------------------------------------ 
create  procedure ProAddTeamlead @Fname varchar(20),@LName varchar(20),@Email varchar(50),@Mobile bigint,@Official bigint,@address varchar(100),@city varchar(20),@Pin bigint,@Qualification varchar(20),@Gender varchar(10),@DOB datetime,@photo varchar,@ReporTo bigint,@Pass varchar(20),@RoleId int
as
insert into BPAUserMaster(FirstName,LastName,EmailId,Mobile_Number,Official_Number,Address,City,PinCode,Qualification,Gender,DOB,Photo,ReportingTo,Password,RoleId) values(@Fname,@LName,@Email,@Mobile,@Official,@address,@city,@Pin,@Qualification,@Gender,@DOB,@photo,@ReporTo,@Pass,@RoleId)

exec ProAddTeamlead 'Shashi','Kumar','Ram@gmail.com',9980445027,9886002066,'Lakshminagar','Bellary',581223,'Ca','Male',01031989,'s',100,'RameLead',222

---------------------------------------ProUserList-------------------------------------------
create procedure ProUserList
as 
select * from BPAUserMaster where UserStatus='Active' 
exec ProUserList
--------------------------------------ProSelectUser---------------------------------------

create procedure ProSelectUser @UserId int
as 
select * from BPAUserMaster where @UserId=UserId

--------------------------------------ProUserDelete------------------------------------------------ 
create procedure ProUserDelete @UserId int
as
update BPAUserMaster set UserStatus='InActive' where UserId=@UserId

-------------------------------------- ProUpdateTeamLead------------------------------------------
create procedure ProUpdateTeamLead @Userid int,@Fname varchar(20),@LName varchar(20),@Email varchar(50),@Mobile bigint,@Official bigint,@address varchar(100),@city varchar(20),@Pin bigint,@Qualification varchar(20),@Gender varchar(10),@DOB datetime,@photo varchar,@ReporTo bigint,@Pass varchar(20),@RoleId int
as
update BPAUserMaster set FirstName=@Fname,LastName=@LName,EmailId=@Email,Mobile_Number=@Mobile,Official_Number=@Official,Address=@address,City=@city,PinCode=@Pin,Qualification=@Qualification,Gender=@Gender,DOB=@DOB,Photo=@photo,ReportingTo=@ReporTo,Password=@Pass,RoleId=@RoleId where UserId=@Userid

exec ProUpdateTeamLead 101,'rrr','dddd','cccc',99,00,'bly','ccc',583113,'ccc','ff','01/01/1991','ddd',100,'ddd',222
-------------------------------------------------------------------------------------------------------
alter procedure ProSearchTeamlead @id int
as
select * from  BPAUserMaster where UserId like @id 

exec ProSearchTeamlead 100
------------------------------------roForgotPassword-------------------------------------------
create procedure ProForgotPassword @email varchar(50)
as
select Password from BPAUserMaster where EmailId=@email

-----------------------------------------------------------------------------------------
alter procedure ProForgotPassword @email varchar(50)
as
select Password,EmailId from BPAUserMaster where EmailId=@email

exec ProForgotPassword 'shivupatil035@gmail.com'
-----------------------------------------------------------------------------------------

create procedure ProSelectroleForgot 
as
select EmailId,Password,RoleId from BPAUserMaster

exec  ProSelectroleForgot
------------------------------------------------changrpassword----------------
select * from BPAUserMaster
create procedure ProSelectPass
as
select Password from BPAUserMaster
exec ProSelectPass
----------------------------------------------------------------------
create  procedure ProChangepass @oldpassword varchar(50),@newpassword varchar(20)
as
update BPAUserMaster set Password=@newpassword where Password=@oldpassword
exec ProChangepass 'Seenu123','Admin'
------------------------------------------------------------------------------

drop table [BPAAdminDatabaseCreate]

CREATE TABLE [dbo] .[BPAAdminDatabaseCreate]
(
    [DatabaseRoleId] int references BPARoleMaster(RoleId) NULL, 
	[DatabseId] [int] IDENTITY(7000,1)  primary key NOT NULL,
	[DatabaseName] varchar(50) null,
	[DatabaseBrower] [varchar] (max) NULL,
	[CreateDescription] [varchar] (max) NULL,
	[CreatedDate] Datetime default(getdate())  NOT NULL
)

drop table [BPAAdminDatabaseAssign]
CREATE TABLE [dbo] .[BPAAdminDatabaseAssign]
(
    [DatabseAssignId] [int]CONSTRAINT [FK_BPAAdminDatabaseCreate_DatabseId]foreign key References [BPAAdminDatabaseCreate](DatabseId) ON DELETE CASCADE ON UPDATE CASCADE NOT NULL,
	[TeamLeadId] int references BPAUserMaster(UserId) NULL,
	[AssignDescription] [varchar] (max) NULL,
	[AssignedDate] Datetime default(getdate())  NOT NULL
	
)
drop procedure BPADatabaseView


alter procedure BPADatabaseView
as

select DatabaseRoleId[created By],DatabaseName[Database Name],CreatedDATE[Created date],TeamLeadId[Assigned To],AssignedDate[Assigned Date],AssignDescription[Description] from BPAAdminDatabaseCreate,[BPAAdminDatabaseAssign] 

insert into BPAAdminDatabaseCreate (DatabaseRoleId,[DatabaseName],DatabaseBrower,CreateDescription) values(111,'RIIT internies list','c:interny.doc','contain 70 student information')
insert into [BPAAdminDatabaseAssign] (DatabseAssignId,TeamLeadId,AssignDescription) values(7008,100,'assigned information')

select * from [BPAAdminDatabaseAssign]
select * from BPAAdminDatabaseCreate
exec BPADatabaseView 

create procedure ProDatabaseAssign @UserId int
as
update BPAUserMaster set UserStatus='InActive' where UserId=@UserId



create procedure ProAddDatabase @DatabaseRoleId int,@DatabaseName varchar(50),@DatabaseBrower varchar(max),@CreateDescription varchar(50)
as
insert into BPAAdminDatabaseCreate( DatabaseRoleId,DatabaseName,DatabaseBrower,CreateDescription) 
values(@DatabaseRoleId,@DatabaseName,@DatabaseBrower,@CreateDescription)
 
exec ProAddDatabase 111,'sads','asdasdad','adsadasd'

ALTER procedure GetDatabaseId
as
select DatabseId,DatabaseName from BPAAdminDatabaseCreate
exec GetDatabaseId

alter procedure ProAssignDatabase @DatabseAssignId int,@TeamLeadId int ,@AssignDescription varchar(50)
as
insert into [BPAAdminDatabaseAssign](DatabseAssignId,TeamLeadId,AssignDescription) 
values(@DatabseAssignId,@TeamLeadId,@AssignDescription)
exec ProAssignDatabase 7005,100,'dsasa'
 
Create procedure ProFetchDB @DatabseId int
as 
select DatabseId,CreateDescription from BPAAdminDatabaseCreate where @DatabseId=DatabseId
exec ProFetchDB 7009
-----------------------------------------------------------------------------------------------------------
alter procedure ProSeachDB @id int
as
select * from  BPAAdminDatabaseCreate where DatabseId like @id

exec ProSeachDB 7008
---------------------------------------------------------------------------------------------------------------

alter procedure ProUpdateDB @DatabseId int,@TeamLeadId int ,@AssignDescription varchar(50)
as
update [BPAAdminDatabaseAssign] set DatabseAssignId=@DatabseId,TeamLeadId=@TeamLeadId,AssignDescription=@AssignDescription
where @DatabseId=DatabseAssignId
exec ProUpdateDB 7009,100,'sadsdas'


alter procedure ProDeleteDB @DatabseId int
as
delete from BPAAdminDatabaseCreate where @DatabseId=DatabseId
exec ProDeleteDB 7001
---------------------------------------------------------------------------------------------------------

alter procedure BPASearchDB @name varchar(30)
as
declare temp cursor  for select * from [BPAAdminDatabaseAssign]
declare temp1 cursor for select DatabaseRoleId,DatabseId,DatabaseName,CreatedDate from BPAAdminDatabaseCreate
open temp1
open temp
declare @did int
declare @TLID int
declare @Adate date;
declare @Adesc varchar(max)
declare @Rid int
declare @Cdate date
declare @dbname varchar(20)
declare @dbid int
declare @res varchar(30)
declare @tab table(DatabaseRoleId int,DatabseId int,DatabaseName varchar(50),CreatedDATE date,TeamLeadI int,AssignedDate date,AssignDescription varchar(max), Assign varchar(20)) 

fetch from temp1 into @Rid,@dbid,@dbname,@Cdate
 while @@FETCH_STATUS<>-1
 begin
   fetch from temp into @did,@TLID ,@Adesc,@Adate
   set @res='Not Assigned'
   while @@FETCH_STATUS<>-1
   begin     
     if(@did=@dbid)
     begin
        set @res='Assigned'
        break
     end
     fetch from temp into @did,@TLID ,@Adesc,@Adate
   end
   
   if(@res!='Assigned')
    begin
       set @TLID=null;
       set @Adate=null;
       set @Adesc=null;
       
    end
   
   insert into @tab values(@Rid,@dbid,@dbname,@Cdate,@TLID,@Adate,@Adesc,@res)
   fetch from temp1 into @Rid,@dbid,@dbname,@Cdate 
   
 end
 select * from @tab where DatabaseName like @name
deallocate temp
deallocate temp1

select * from BPAAdminDatabaseCreate
select * from BPAAdminDatabaseAssign
exec BPASearchDB 'amar info.'

-----------------------------------------------------------------


alter procedure BPADatabaseView1
as

declare temp cursor  for select * from [BPAAdminDatabaseAssign]
declare temp1 cursor for select DatabaseRoleId,DatabseId,DatabaseName,CreatedDate from BPAAdminDatabaseCreate
open temp1
open temp
declare @did int
declare @TLID int
declare @Adate date;
declare @Adesc varchar(max)
declare @Rid int
declare @Cdate date
declare @dbname varchar(20)
declare @dbid int
declare @res varchar(30)
declare @tab table(DatabaseRoleId int,DatabseId int,DatabaseName varchar(50),CreatedDATE date,TeamLeadI int,AssignedDate date,AssignDescription varchar(max), Assign varchar(20)) 

fetch from temp1 into @Rid,@dbid,@dbname,@Cdate
 while @@FETCH_STATUS<>-1
 begin
   fetch from temp into @did,@TLID ,@Adesc,@Adate
   set @res='Not Assigned'
   while @@FETCH_STATUS<>-1
   begin     
     if(@did=@dbid)
     begin
        set @res='Assigned'
        break
     end
     fetch from temp into @did,@TLID ,@Adesc,@Adate
   end
   
   if(@res!='Assigned')
    begin
       set @TLID=null;
       set @Adate=null;
       set @Adesc=null;
       
    end
   
   insert into @tab values(@Rid,@dbid,@dbname,@Cdate,@TLID,@Adate,@Adesc,@res)
   fetch from temp1 into @Rid,@dbid,@dbname,@Cdate
   
 end
 select * from @tab
deallocate temp
deallocate temp1

select * from BPAAdminDatabaseCreate
select * from BPAAdminDatabaseAssign
exec 
BPADatabaseView1
exec ProFetchDB 7002
delete procedure BPADatabaseView1
delete BPAAdminDatabaseCreate
select DatabaseRoleId[created By],DatabaseName[Database Name],CreatedDATE[Created date],TeamLeadId[Assigned To],AssignedDate[Assigned Date],AssignDescription[Description] from BPAAdminDatabaseCreate,[BPAAdminDatabaseAssign] 

------------------------------------------------------------------
CREATE TABLE [dbo] .[BPAPromotionalActivityMaster]
(
	[PromotionalActivityId] [int] IDENTITY(3000,1) NOT NULL,
    [PromotionalType] [varchar](50) NULL,
	[Subject] [varchar] (150) NULL,
	[Amount] int NULL,
	[DurationStart] date NULL,
	[DurationEnd] date NULL,
	[Attachment] [varchar](max) NULL,
	[Remark] [varchar] (max) NULL,
	CONSTRAINT [PK_BPAPromotionalActivityMaster_PromotionalActivityId] PRIMARY KEY CLUSTERED
(
	[PromotionalActivityId] ASC
)WITH (PAD_INDEX =OFF,STATISTICS_NORECOMPUTE =OFF,IGNORE_DUP_KEY =OFF,ALLOW_ROW_LOCKS=ON,ALLOW_PAGE_LOCKS=ON)ON [PRIMARY])
GO
SET ANSI_PADDING OFF

-------------------------------------------------------------------------------------

CREATE TABLE  [dbo]  .[BPAPromotionalActivityAssign]  (
[SlNo]  [int]  IDENTITY (3600,1)  NOT  NULL,
[PromotionalActivityId]  [int]  CONSTRAINT [FK_BPAPromotionalActivityDetails_PromotionalActivityId] References BPAPromotionalActivityMaster(PromotionalActivityId) ON DELETE CASCADE ON UPDATE CASCADE NOT NULL,
[TeamLeadId]  [int]  CONSTRAINT [FK_BPAPromotionalActivityDetails1_UserId] References BPAUserMaster(UserId)  NOT NULL,
[date1]  [date] default(getdate()) NULL,
[Remark] [varchar](50) Null,
CONSTRAINT  [PK_ BPAPromotionalActivityDetails_SlNo]  PRIMARY  KEY  CLUSTERED
(
[SlNo]  ASC
)WITH  (PAD_INDEX  =  OFF, STATISTICS_NORECOMPUTE  =  OFF, IGNORE_DUP_KEY  =  OFF,
ALLOW_ROW_LOCKS  =  ON, ALLOW_PAGE_LOCKS  =  ON)  ON  [PRIMARY ]
)  ON  [PRIMARY]
GO
drop table [BPAPromotionalActivityAssign]
select * from [BPAPromotionalActivityAssign]
delete [BPAPromotionalActivityAssign]
alter table [BPAPromotionalActivityAssign]alter column date1 datetime

alter table BPAuserMaster  add constraint uk unique(emailid)

insert into [BPAPromotionalActivityAssign](PromotionalActivityId,TeamLeadId,Remark)values(3000,106,'inform me daily')
----------------------------------
insert into [BPAPromotionalActivityMaster]
(PromotionalType,Subject,Amount,DurationStart,DurationEnd,Attachment,Remark) values
('News','BBC news india',2000,'1-1-2011','1-1-2014','c:ad.doc','2times per day') 

create table simple11(id int)
alter table simple11  add constraint uk1 unique(id)
select * from simple11
insert into simple11 values(2);
alter table simple11 alter column id varchar(10) 
drop table simple11

select * from [BPAPromotionalActivityMaster]
select * from [BPAPromotionalActivityAssign]
------------------------------------------------------------------
insert into [BPAPromotionalActivityAssign]
(PromotionalActivityId,UserId,ReceivedId) values
(3000,111,101) 
create procedure ProAssignPromotionalActivity @PromotionalActivityId int,@TeamLeadId int,@Remark varchar(50)
as
insert into BPAPromotionalActivityAssign(PromotionalActivityId,TeamLeadId,Remark) 
values(@PromotionalActivityId,@TeamLeadId,@Remark)
-----------------------------------------------------------------
create procedure ProPromotionalList
as
select PromotionalActivityId,subject from BPAPromotionalActivityMaster
exec ProPromotionalList

alter procedure ProAddPromotionalActivity @PromotionalType varchar(50),@Subject varchar(80),@Amount int,@DurationStart varchar(15),@DurationEnd varchar(15),@Attachment varchar(max),@Remark varchar(50)
as
insert into BPAPromotionalActivityMaster( PromotionalType,Subject,Amount,DurationStart,DurationEnd,Attachment,Remark) 
values(@PromotionalType,@Subject,@Amount,convert(date,@DurationStart),convert(date,@DurationEnd),@Attachment,@Remark)
-------------------- 
 
create procedure ProFetchPromotionalActivity
as 
select * from BPAPromotionalActivityMaster where ProStatus='Active' 
exec ProFetchPromotionalActivity
------------------------------------------------------------------------------------------------------
create procedure ProSearchPromotionalActivity @id int
as
select * from  BPAPromotionalActivityMaster where PromotionalActivityId like @id 

exec ProSearchPromotionalActivity 3000
--------------------------------------ProSelectUser---------------------------------------

create procedure ProSelectPromotionalActivity @PromotionalActivityId int
as 
select * from BPAPromotionalActivityMaster where @PromotionalActivityId=PromotionalActivityId

--------------------------------------ProUserDelete------------------------------------------------ 
create procedure ProDeletPromotionalActivity @PromotionalActivityId int
as
update BPAPromotionalActivityMaster set ProStatus='InActive' where PromotionalActivityId=@PromotionalActivityId

-------------------------------------- ProUpdateTeamLead------------------------------------------
alter procedure ProUpdatePromotionalActivity @PromotionalActivityId int,@PromotionalType varchar(50),@Subject varchar(80),@Amount int,@DurationStart date,@DurationEnd date,@Attachment varchar(max),@Remark varchar(50)
as
update BPAPromotionalActivityMaster set PromotionalType=@PromotionalType,Subject=@Subject,Amount=@Amount,DurationStart=@DurationStart,DurationEnd=@DurationEnd,Attachment=@Attachment,Remark=@Remark
where PromotionalActivityId=@PromotionalActivityId
exec ProUpdatePromotionalActivity 3001,'csc','csa',25000,'1-1-2011','1-1-2014','c:ss.dco','wwww'

 -----------------------------------------[BPAMeeting]---------------------------------------------------------

CREATE TABLE [dbo] .[BPAMeeting]
(
	[MeetingId] [int] IDENTITY(2000,1) NOT NULL,
	[MeetingName] [varchar] (150) NOT NULL,
	[Description] [varchar] (max) NOT NULL,
	[Date] [datetime]   NULL,
    [StartTime] [varchar] (10) NULL,
    [EndTime] [varchar] (10)  NULL,
    [Location] [varchar] (50) NULL, 
                
	
CONSTRAINT [PK_BPAMeeting_MeetingId] PRIMARY KEY CLUSTERED
(
	[MeetingId] ASC
)WITH (PAD_INDEX=OFF,STATISTICS_NORECOMPUTE =OFF, IGNORE_DUP_KEY=OFF ,
ALLOW_ROW_LOCKS=ON,ALLOW_PAGE_LOCKS=ON)ON [PRIMARY]
)
ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
-------------------------------------------------------------------------------------------------------
CREATE TABLE [dbo] .[BPAMeetingAssign]
(
	[MeetingId] [int]CONSTRAINT [FK_BPAMeeting_MeetingId] References [BPAMeeting](MeetingId) NOT NULL,
	[UserId] [int] CONSTRAINT [FK_BPAmeeting_UserId] References BPAUserMaster(UserId)  NOT NULL,
    [Remark] [varchar] (50) NULL, 
)

-----------------------------------------------------------------------------------------------------
insert into BPAMeeting(MeetingName,Description,Date,StartTime,EndTime,Location) values('new course introduction','welcome','01/05/2014','10AM','11AM','Mysore')
-----------------------------------------ProAddMeeting-----------------------------------------------------------------

create procedure ProAddMeeting @MeetingName varchar(20),@Description varchar(max),@Date datetime,@StartTime varchar(10),@EndTime varchar(10),@Location varchar(20)
as
insert into BPAMeeting(MeetingName,Description,Date,StartTime,EndTime,Location) values(@MeetingName,@Description,@Date,@StartTime,@EndTime,@Location)

exec ProAddMeeting 'new course introduction','welcome','01/05/2014','10AM','11AM','Mysore'
  
 ---------------------------------------------------------ProMeetingDelete------------------------------------
create procedure ProMeetingDelete @MeetingId int
as
update BPAMeeting set MeetingStatus='InActive' where Meetingid=@MeetingId
exec ProMeetingDelete 2001
------------------------------------------------------------------------------------------------------------------
create table BPAMeetingAsign(Meetingid int )
------------------------------------------------------ProSelectMeeting--------------------------------------------

create procedure ProSelectMeeting
as
select * from BPAMeeting where MeetingStatus='Active'

exec ProSelectMeeting 
------------------------------------------------------------meetingsearch----------------------------
create procedure ProSearchMeetingDetails @MeetingName varchar(50),@MeetingId int
as
select MeetingId,MeetingName,Description,Date,StartTime,EndTime,Location from BPAMeeting where MeetingName like @MeetingName or MeetingId like @MeetingId
 
-----------------------------------------------ProMeetingId-------------------------------------------------
create procedure ProMeetingId @Meetingid  int
as
select * from BPAMeeting where MeetingId=@Meetingid
--------------------------------------------------------ProUpdateMeeting-------------------------------------------------

create procedure ProUpdateMeeting @meetingid int,@MeetingName varchar(50),@description varchar(max),@date datetime,@starttime varchar(10),@endtime varchar(10),@location varchar(30)
as 
update BPAMeeting seT MeetingName=@MeetingName,Description=@description,date=@date,Starttime=@starttime,@endtime=@endtime,location=@location where meetingid=@meetingid 
-------------------------------------------------------------------------------------------------------------------
drop table [BPACalenderOfEvents]
CREATE TABLE [dbo] .[BPACalenderOfEvents]
(
	[Eventid] [int] IDENTITY(6000,1) NOT NULL,
	[EventCreator] [int] CONSTRAINT [FK_BPAEventApplicableTo_UserId] References BPAUserMaster(UserId)  NOT NULL,
	[EventName] [varchar](50) NUll,
	[EventDetails] [varchar] (max) NULL,
	[EventDate] date NULL,
CONSTRAINT [PK_BPAClenderOfEvents_EventId] PRIMARY KEY CLUSTERED
(
	[EventId]ASC
)
WITH(PAD_INDEX=OFF,STATISTICS_NORECOMPUTE =OFF ,IGNORE_DUP_KEY= OFF,
ALLOW_ROW_LOCKS=ON,ALLOW_PAGE_LOCKS=ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
--SET IDENTITY_INSERT [dbo] .[BPACalenderOfEvents] ON
select * from BPAUserMaster
 select * from BPACalenderOfEvents
 insert into BPACalenderOfEvents(EventCreator,eventname,EventDetails,EventDate) values(101,'Sports','Sports handle in our compus','01/02/2014')
 
 alter procedure ProCreateEvent @CreaterId int,@eventname varchar(50),@EventDescription varchar(max), @EventDate datetime
 as
 insert into BPACalenderOfEvents(EventCreator,eventname,EventDetails,EventDate) values(@CreaterId,@eventname,@EventDescription,@EventDate)
 
 exec ProCreateEvent 100,'annual Day','AIMS Annual day Celebration','10/09/2014'

-------------------------------------------------------------------------------------------------------
drop table [BPAEventApplicableTo]
CREATE  TABLE [dbo]  .  [BPAEventApplicableTo](
[EventId]  [int]   CONSTRAINT [FK_BPAEventApplicableTo_EventId] References BPACalenderOfEvents(EventId) ON DELETE CASCADE ON UPDATE CASCADE NOT NULL,
[UserId]  [int]   CONSTRAINT [FK_BPAEventApplicableTo1_UserId] References BPAUserMaster(UserId)  NOT NULL,
[DateOfAssign] date default(getdate()),
[Remarks]  [varchar]  (max)  NULL,
)  ON [PRIMARY]
GO 
SET  ANSI_PADDING  OFF
GO

select * from BPACalenderOfEvents
select * from BPAUserMaster
select * from BPAEventApplicableTo
insert into BPAEventApplicableTo(Eventid,UserId,Remarks) values(6001,101,'Annual day handle in Mall of Mysore')
--------------event Applicableto----------------------
create procedure ProSelectEventId
as
select * from BPACalenderOfEvents where EventStatus='Active'
exec ProSelectEventId 

create procedure ProEventApplicableTo @EventId int,@UserId int,@Remarks varchar(30)
as
insert into BPAEventApplicableTo(Eventid,UserId,Remarks) values(@EventId,@UserId,@Remarks)
-----------------------------------------------------------------------------------------------------

select * from BPACalenderOfEvents
select * from BpaEventApplicableTo

create procedure ProDisplayEvents
as
select a.Eventid,a.EventCreator,EventDetails,Date,b.UserId,b.DateOfAssign,b.Remarks from BPACalenderOfEvents a
inner join BpaEventApplicableTo b on a.Eventid=b.EventId where EventStatus='Active'
exec ProDisplayEvents 
------------------------------------------ 
 
alter procedure ProFetchEvents @Eventid int
as 
select Eventid,EventDetails from BPACalenderOfEvents where @Eventid=Eventid
exec ProFetchEvents 6002



-------------------------------------------------------------------------------------------------
drop procedure ProSearchEventDetails
create procedure ProSearchEventDetails @EventId int,@UserId int
as
select EventCreator int,Eventid int,eventname varchar(50),EventDetails varchar(max),EventDate date,UserId int,dateofassign date,Remarks from BPACalenderOfEvents a 
inner join BpaEventApplicableTo b on a.Eventid=b.EventId where (a.Eventid like @EventId or b.UserId like @UserId)
 and (EventStatus='Active')

select * from BPACalenderOfEvents
exec ProSearchEventDetails 6000,101
select * from BPACalenderOfEvents
-------------------deleteEvent---------------------
create procedure ProDeactiveEvent @EventId int
as
update BPACalenderOfEvents set EventStatus='DeActive' Where EventId=@EventId
-----------------------updateEvent-------------------------------
create procedure ProUpdateDB @DatabseId int,@TeamLeadId int ,@AssignDescription varchar(50)
as
update [BPAAdminDatabaseAssign] set DatabseAssignId=@DatabseId,TeamLeadId=@TeamLeadId,AssignDescription=@AssignDescription
where @DatabseId=DatabseAssignId
exec ProUpdateDB 7009,100,'sadsdas'


exec ProUpdateEvent 101,100,'Visit',101,109,'01/05/2014','conduct'
select * from BPACalenderOfEvents
select * from BPAEventApplicableTo

create procedure ProSelectEventId1 @EventId int
as
select * from BPACalenderOfEvents a inner join BPAEventApplicableTo b on a.Eventid=b.EventId where a.Eventid=@EventId

exec ProSelectEventId1 101
select * from BPACalenderOfEvents
select * from BPAEventApplicableTo

---------------------------------------------------------------- 

select * from BPAAdminDatabase;

alter procedure BPAEventView
as

declare temp cursor  for select Eventid,UserId,Remarks,dateofassign from BPAEventApplicableTo
declare temp1 cursor for select Eventid,EventCreator,eventname,EventDetails,EventDate from BPACalenderOfEvents
open temp1
open temp
declare @Aeid int
declare @Auserid int
declare @Adate date;
declare @Aremark varchar(max)
declare @Ecreater int
declare @Edate date
declare @EDetails varchar(max)
declare @Ename varchar(20)
declare @Eid int 
declare @res varchar(30)
declare @tab table(EventCreator int,Eventid int,eventname varchar(50),EventDetails varchar(max),EventDate date,UserId int,dateofassign date,Remarks varchar(max), Assign varchar(20)) 

fetch from temp1 into @Eid,@Ecreater,@Ename,@EDetails,@Edate
 while @@FETCH_STATUS<>-1
 begin
   fetch from temp into @Aeid,@Auserid ,@Aremark,@Adate
   set @res='Not Assigned'
   while @@FETCH_STATUS<>-1
   begin     
     if(@Aeid=@Eid)
     begin
        set @res='Assigned'
        break
     end
     fetch from temp into @Aeid,@Auserid ,@Aremark,@Adate
   end
   
   if(@res!='Assigned')
    begin
       set @Auserid=null;
       set @Adate=null;
       set @Aremark=null;
       
    end
   
   insert into @tab values(@Ecreater,@Eid,@Ename,@EDetails,@Edate,@Auserid,@Adate,@Aremark,@res)
   fetch from temp1 into @Eid,@Ecreater,@Ename,@EDetails,@Edate
   
 end
 select * from @tab
deallocate temp
deallocate temp1


exec BPAEventView
------------------------------------------------------------------------------------------------------------

create procedure ProSearchEvent @eventname varchar(30)
as

declare temp cursor  for select Eventid,UserId,Remarks,dateofassign from BPAEventApplicableTo
declare temp1 cursor for select Eventid,EventCreator,eventname,EventDetails,EventDate from BPACalenderOfEvents
open temp1
open temp
declare @Aeid int
declare @Auserid int
declare @Adate date;
declare @Aremark varchar(max)
declare @Ecreater int
declare @Edate date
declare @EDetails varchar(max)
declare @Ename varchar(20)
declare @Eid int 
declare @res varchar(30)
declare @tab table(EventCreator int,Eventid int,eventname varchar(50),EventDetails varchar(max),EventDate date,UserId int,dateofassign date,Remarks varchar(max), Assign varchar(20)) 

fetch from temp1 into @Eid,@Ecreater,@Ename,@EDetails,@Edate
 while @@FETCH_STATUS<>-1
 begin
   fetch from temp into @Aeid,@Auserid ,@Aremark,@Adate
   set @res='Not Assigned'
   while @@FETCH_STATUS<>-1
   begin     
     if(@Aeid=@Eid)
     begin
        set @res='Assigned'
        break
     end
     fetch from temp into @Aeid,@Auserid ,@Aremark,@Adate
   end
   
   if(@res!='Assigned')
    begin
       set @Auserid=null;
       set @Adate=null;
       set @Aremark=null;
       
    end
   
   insert into @tab values(@Ecreater,@Eid,@Ename,@EDetails,@Edate,@Auserid,@Adate,@Aremark,@res)
   fetch from temp1 into @Eid,@Ecreater,@Ename,@EDetails,@Edate
   
 end
 select * from @tab where eventname like @eventname
deallocate temp
deallocate temp1

exec ProSearchEvent 'annual Day'

------------------------------------------------------------------------------------------------------------
select * from BPACalenderOfEvents
select * from BPAEventApplicableTo

----------------------------------------------------------------------------------------------------------------------
alter procedure ProUpdateEvent @Eventid int,@UserId int ,@Remarks varchar(max)
as
update BPAEventApplicableTo set Eventid=@Eventid,UserId=@UserId,Remarks=@Remarks
where @Eventid=Eventid
exec ProUpdateEvent 6001,101,'Holiday'

----------------------------------------------------------------------------------------------------------------------
alter procedure ProDeleteEvent @Eventid int
as
delete from BPACalenderOfEvents where @Eventid=Eventid
exec ProDeleteEvent 6002
----------------------------------------------------------------------------------------
create procedure EventDatePro
as
select * from BPACalenderOfEvents where EventStatus='Active'
exec EventDatePro
-------------------------------------------------------------------------------------------------------
create procedure EventDetailsCallPro @EventDate date
as
select EventId,EventName,EventCreator,EventDetails,EventDate from BPACalenderOfEvents where EventStatus='Active' and EventDate=@EventDate
exec EventDetailsCallPro '2014-10-09' 
-------------------------------------------------------------------------------------------------------------
create procedure ViewEventDetails
as
select EventId,EventName,EventCreator,EventDetails,EventDate from BPACalenderOfEvents where EventStatus='Active'
exec ViewEventDetails

------------------------------------------------------------------------
alter procedure ProDeleteDB @DatabseId int
as
delete from BPAAdminDatabaseCreate where @DatabseId=DatabseId
exec ProDeleteDB 7001
------------------------------------------------------------------------------------------------------------
------------Message---------------------
CREATE TABLE [dbo] .[BPAMessages]
(
	[MessageId] [int] IDENTITY(1300,1) NOT NULL,
	[Message] [varchar] (max) NULL,
	[SenderId] [int] CONSTRAINT [FK_BPAMessages_UserId] References BPAUserMaster(UserId) ON DELETE CASCADE ON UPDATE CASCADE NOT NULL,
	[DateOfSend] [datetime] default(getdate()),
	 
CONSTRAINT [PK_BPMessages_MessageId] PRIMARY KEY CLUSTERED
(
	[MessageId] ASC
)WITH (PAD_INDEX=OFF,STATISTICS_NORECOMPUTE =OFF, IGNORE_DUP_KEY=OFF ,
ALLOW_ROW_LOCKS=ON,ALLOW_PAGE_LOCKS=ON)ON [PRIMARY]
)
ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
--SET IDENTITY_INSERT [dbo] .[BPAMails] ON

select * from BPAMessages


------------------------------------------------------------------------------------
CREATE  TABLE [dbo]  .  [BPAMessageRecepients]  (
[MessageId]  [int] CONSTRAINT [FK_BPAMessageRecepients_MessageId] References BPAMessages(MessageId) NOT NULL,
[SenderId]  [int] CONSTRAINT [FK_BPAMessageRecepients_UserId] References BPAUserMaster(UserId) ON DELETE CASCADE ON UPDATE CASCADE NOT NULL,
[ReceiverId]  [int]  CONSTRAINT [FK_BPAMessageRecepients1_UserId] References BPAUserMaster(UserId)  NOT NULL,
 
)  ON  [PRIMARY]
GO






select * from Bpamessages  
select * from BPAMessageRecepients
create procedure ProMessageSelectUsers 
as
select UserId,FirstName[Name],EmailId,Mobile_Number,Password from BPAUserMaster
exec ProMessageSelectUsers


Create procedure [dbo].[ProInsertToMessage] @Message varchar(max),@SenderId int
as
insert into BPAMessages(Message,SenderId) values(@Message,@senderId) 

exec ProInsertToMessage 'Tomorrow Holiday',100

create procedure [dbo].[ProInsertToMessageRecepients] @SenderId int,@ReceiverId int
as
declare @MessageId int
set @MessageId=(select MAX(MessageId) from BPAMEssages)
insert into BPAMessageRecepients(MessageId,SenderId,ReceiverId) values(@MessageId,@SenderId,@ReceiverId)

select * from BPAUserMaster

----------------------------------------------------[BPAMails]-----------------------------------------------------
insert into BPAMails values('interview','sir what you decide about my interview',100,'5/24/2014','file')
CREATE TABLE [dbo] .[BPAMails]
(
	[MailId] [int] IDENTITY(1300,1) NOT NULL,
	[Subject] [varchar] (150) NULL,
	[Message] [varchar] (max) NULL,
	[SenderId] [int] CONSTRAINT [FK_BPAMails_UserId] References BPAUserMaster(UserId) ON DELETE CASCADE ON UPDATE CASCADE NOT NULL,
	[DateOfSend] [datetime] default(getdate()),
	[Attachment] [varchar] (max) NULL,
CONSTRAINT [PK_BPMails_MailId] PRIMARY KEY CLUSTERED
(
	[MailId] ASC
)WITH (PAD_INDEX=OFF,STATISTICS_NORECOMPUTE =OFF, IGNORE_DUP_KEY=OFF ,
ALLOW_ROW_LOCKS=ON,ALLOW_PAGE_LOCKS=ON)ON [PRIMARY]
)
ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
--SET IDENTITY_INSERT [dbo] .[BPAMails] ON


-------------------------------------------------[BPAMailsRecepients]-----------------------------------
CREATE  TABLE [dbo]  .  [BPAMailsRecepients]  (
[MailId]  [int] CONSTRAINT [FK_BPAMailsRecepients_MailId] References BPAMails(MailId) NOT NULL,
[SenderId]  [int] CONSTRAINT [FK_BPAMailsRecepients_UserId] References BPAUserMaster(UserId) ON DELETE CASCADE ON UPDATE CASCADE NOT NULL,
[ReceiverId]  [int]  CONSTRAINT [FK_BPAMailsRecepients1_UserId] References BPAUserMaster(UserId)  NOT NULL,
 
)  ON  [PRIMARY]
GO
-----------------------------------try---------------------
 select * from BpauserMaster
 select FirstName,DATEPART(MONTH,dob)month from BPAUserMaster
  select * from BPAMails
select * from BPAMailsRecepients
dbcc checkident("BPAMails",reseed,1299)
------------------------------------------------ProInsertToMails---------------------------------
create procedure ProInsertToMails @Subject varchar(150),@Message varchar(max),@SenderId int,@Attachment varchar(max)
as
insert into BPAMails(Subject,Message,SenderId,Attachment) values(@Subject,@Message,@senderId,@attachment) 

exec ProInsertToMails 'Interview','Check attachment',100,'file'
---------------------------------------------------------------ProInsertToMailRecepients--------------------------------------------
create procedure ProInsertToMailRecepients @SenderId int,@ReceiverId int
as
declare @MailId int
set @MailId=(select MAX(mailid) from BPAMails)
insert into BPAMailsRecepients(MailId,SenderId,ReceiverId) values(@MailId,@SenderId,@ReceiverId)
 
 exec ProInsertToMailRecepients 100,108

---------------ToBoundDataGridView---------------------------------------------------------------------------------
alter Procedure ProBoundListBox
as
select UserId,FirstName,EmailId from BPAUserMaster where UserStatus='Active'

exec ProBoundListBox
update BPAUserMaster set UserStatus='Active' where UserStatus='InActive'
----------------------------------------outBoxGridViewBind-------------------------------------
create procedure ProBindOutbox
as
select ReceiverId,EmailId,Subject,Message from BPAMailsRecepients a inner join BPAUserMaster b on a.ReceiverId=b.UserId inner join BPAMails c on c.MailId=a.MailId
exec 
-------------------------------------------InboxGridViewbind-----------------------------------------------
alter procedure ProBindInbox
as
select mailid,a.SenderId,EmailId,Subject,Message, attachment from BPAMails a inner join BPAUserMaster b on a.SenderId=b.UserId 

exec ProBindInbox
----------------------------------------ProSelectUserReport--------------------------------
select* FROM BPAUserMaster
alter procedure ProSelectUserReport 
as 
select UserId,FirstName,LastName from BPAUserMaster where RoleId=222
exec ProSelectUserReport

 ----------------------------------------------[BPAStudentInfo]-------------------------------------------------------
 
CREATE TABLE [dbo].[BPAStudentInfo](
	[StudentId] [int] IDENTITY(1000,1) NOT NULL,
	[FirstName] [varchar](30) NOT NULL,
	[LastName] [varchar](30) NULL,
	[DateOfBirth] [datetime] NOT NULL,
	[Gender] [varchar](10) NOT NULL,
	[EmailId] [varchar](50) NOT NULL,
	[MobileNumber] [bigint] NULL,
	[Address] [varchar](100) NULL,
	[City] [varchar](50) NULL,
	[PinCode] [bigint] NULL,
	[Qualification] [varchar](20) NULL,
	[Branch] [varchar](30) NULL,
	[Percentage] [numeric](4, 2) NULL,
	[College] [varchar](50) NULL,
	[YearOfPassing] [int] NULL,
	[DateOfJoining] [datetime] NOT NULL,
	[Photo] [varchar](100) NULL,
	[Remarks] [varchar](150) NULL,
 CONSTRAINT [PK_BPAStudent_StudentIdInfo] PRIMARY KEY CLUSTERED 
(
	[StudentId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]


delete from BPAStudentInfo
select * from [BPAStudentInfo]
insert into [BPAStudentInfo] values('Ravi','Kumar','1-2-1991','Male','Kuamr@gmail.com',9652584752,'Bellary','Bellary',589526,'BE','CS',78.25,'RYMEC',2013,'01/01/2014','c:ravi.jpg','Good in communication')
insert into [BPAStudentInfo] values('Sagar','Reddy','1-2-1991','Male','sagar@gmail.com',9880130973,'Varur','Hubli',578123,'BSc','CS',55.25,'BVB',2012,'08/08/2014','d:cc.jpg','Best learner')
insert into [BPAStudentInfo] values('Shrusti','Patil','6-6-1990','Female','Shrusti@gmail.com',9686052545,'Bagalkot','Bagalkot',587103,'BE','EC',88.25,'BEC',2013,'09/05/2014','c:dd.jpg','Poor Knowledge')

-----------------------[BPAEnquirySource]----------------------------------------------------------------
drop Table [BPAEnquirySource]
CREATE TABLE [dbo] .[BPAEnquirySource]
(
	[SourceId] [int] IDENTITY(50,1) NOT NULL,
	[Source] [varchar] (50) NOT NULL,
CONSTRAINT [PK_BPAEnquirySource_SourceId] PRIMARY KEY CLUSTERED
(
[SourceId] ASC
)
WITH (PAD_INDEX=OFF,STATISTICS_NORECOMPUTE=OFF,IGNORE_DUP_KEY=OFF,ALLOW_ROW_LOCKS=ON,ALLOW_PAGE_LOCKS=ON)ON[PRIMARY]
) ON [PRIMARY]
GO
insert into BPAEnquirySource values('News')
insert into BPAEnquirySource values('Banner')
select * from BPAEnquirySource
------------------------------------------------[BPAEnquiryInfo]-----------------------------------
select * from [BPAEnquiryInfo]
CREATE TABLE [dbo] .[BPAEnquiryInfo]
(
	[EnquiryId] [int] IDENTITY(1200,1) NOT NULL,
	[UserId] [int] CONSTRAINT [FK_BPAEnquiryInfo_UserId] References BPAUserMaster(UserId) ON DELETE CASCADE ON UPDATE CASCADE NOT NULL,
	[StudentId] [int]CONSTRAINT [FK_BPAEnquiryInfo_StudentId] References BPAStudentInfo(StudentId) NOT NULL,
	[SourceId]  [int]  CONSTRAINT [FK_BPAEnquiryInfo_SourceId] References BPAEnquirySource(SourceId) ON DELETE CASCADE ON UPDATE CASCADE NOT NULL,
	[Date]  [datetime]  NULL,
	[CourseId] [int] CONSTRAINT [FK_BPAEnquiryInfo_CourceId] References BPACourseMaster(CourseId) ON DELETE CASCADE ON UPDATE CASCADE NOT NULL,
	[InterstedIn]  [int]  NULL,
	[DecisionMaker]  [varchar]  (30)  NULL,
	[Relationship]  [varchar]  (30)  NULL,
	[DecisionMakerContactNumber]  [bigint]  NULL,
CONSTRAINT  [PK_BPAEnquiryInfo_EnquiryId]  PRIMARY  KEY  CLUSTERED
(
       [EnquiryId] ASC
)WITH  (PAD_INDEX  =  OFF,  STATISTICS_NORECOMPUTE   =  OFF, IGNORE_DUP_KEY  =  OFF,
ALLOW_ROW_LOCKS   =   ON, ALLOW_PAGE_LOCKS  =  ON ) ON [PRIMARY]
)  ON [PRIMARY]
 select * from BPAUserMaster
SET  ANSI_PADDING  OFF
GO 
select * from BPAEnquirySource
select * from BPACourseMaster
insert into BPAEnquiryInfo values(107,1012,50,'2014/04/04',10,1,'Raghav','Cousin',9538371734)
insert into BPAEnquiryInfo values(107,1013,51,'2014/04/05',10,2,'Younish','Brother',8952635475)
insert into BPAEnquiryInfo values(108,1014,51,'2014/05/08',12,3,'Anitha','Sister',9900362547)
insert into BPAEnquiryInfo values(108,1002,51,'2014/05/08',13,3,'Savita','wife',9880130246)
select * from BPAEnquiryInfo
delete from BPAEnquiryInfo
------------------------------------------[BPAStudentAdmissionDetails]--------------------------------------------------------------------
delete from BPAStudentAdmissionDetails
drop table [BPAStudentAdmissionDetails]
CREATE  TABLE  [dbo]  .  [BPAStudentAdmissionDetails] (
[AdmissionId]  [int]  IDENTITY  (100,1)  NOT  NULL,
[UserId] [int] CONSTRAINT [FK_BPAStudentAdmissionDetails_UserId] References BPAUserMaster(Userid) NOT NULL,
[StudentId] [int] CONSTRAINT [FK_BPAStudentAdmissionDetails_StudentId] References BPAStudentInfo(StudentId) NOT NULL,
[Courseid][int] CONSTRAINT [FK_BPAStudentAdmissionDetails_courseid] References BPAcourseMaster(courseid) NOT NULL,
[EnquiryId]    [int]  CONSTRAINT [FK_BPAStudentAdmissionDetails_EnquiryId] References BPAEnquiryInfo(EnquiryId)  NOT NULL,
[AdmissionDate] [date] CONSTRAINT AdDate default (getdate()),
[Remarks]  [varchar]  (150)  NULL,
CONSTRAINT [PK_BPAStudentAdmissionDetails_AdmissionId]  PRIMARY  KEY  CLUSTERED
(
             [AdmissionId]  ASC
)WITH  (PAD_INDEX  =  OFF , STATISTICS_NORECOMPUTE  =  OFF ,  IGNORE_DUP_KEY  =  OFF,
ALLOW_ROW_LOCKS  =  ON,  ALLOW_PAGE_LOCKS  =  ON)  ON  [PRIMARY]
) ON  [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
select * from BPAStudentAdmissionDetails
insert into BPAStudentAdmissionDetails(userid,StudentId,Courseid,EnquiryId,Remarks) values(107,1012,10,1211,'Good')
insert into BPAStudentAdmissionDetails(userid,StudentId,Courseid,EnquiryId,Remarks) values(107,1016,11,1212,'Average')
insert into BPAStudentAdmissionDetails(userid,StudentId,Courseid,EnquiryId,Remarks) values(108,1012,10,1216,'Poor')
insert into BPAStudentAdmissionDetails(userid,StudentId,Courseid,EnquiryId,Remarks) values(108,1014,10,1213,'Poor')

------------------------------------------[BPAFollowUP]--------------------------------------------------------------------

CREATE TABLE [dbo].[BPAFollowUP](
	[StudentId] [int] FOREIGN KEY([StudentId])
REFERENCES [dbo].[BPAStudentInfo] ([StudentId])
ON UPDATE CASCADE
ON DELETE CASCADE NOT NULL,
	[UserId] [int]  FOREIGN KEY([UserId])
REFERENCES [dbo].[BPAUserMaster] ([UserId])
ON UPDATE CASCADE
ON DELETE CASCADE NOT NULL,
	[FOllowUpDate] [datetime] NULL,
	[FollowUpDescription] [varchar](100) NULL,
	
) ON [PRIMARY]

GO
---------------------------------viewwwwwwwwww-----------------------------------------------------
select * from BPAFollowUP
select * from BPAStudentInfo
select * from BPAStudentAdmissionDetails
select * from BPAEnquiryInfo
insert into BPAFollowUP values(1013,107,'6-6-2014','Told he will visite in next month')
insert into BPAFollowUP values(1014,108,'8-8-2014','do well')

-------------------------------------trgStudentAdmission-----------------------------------------
drop trigger trgStudentAdmission
create trigger trgStudentAdmission
on BPAStudentAdmissionDetails
for insert
as
declare @sid int
  select @sid=studentid from inserted
delete from BPAFollowUP where StudentId=@sid

-------------------------------------------ProTLreportSRlist------------------------------------------------------------------
alter Procedure ProTLreportSRlist  @ReportingTo int
as
select t1.FirstName[Sales Representative Name],t1.[No. of Enqueries],t2.[No. of Followups],(t1.[No. of Enqueries]-t2.[No. of Followups])[No.of Admissions],(t1.[No. of Enqueries]-t2.[No. of Followups])[Close],(t1.[No. of Enqueries])[Revenue] from
(Select b.UserId, b.FirstName,count(a.EnquiryId)[No. of Enqueries] From  BPAEnquiryInfo a  inner join 
BPAUserMaster b on a.UserId=b.UserId and b.ReportingTo=106 group by b.UserId,b.FirstName)t1
left outer join 
(select UserId, count(userid)[No. of Followups] from BPAFollowUP group by UserId)t2 on t1.UserId=t2.UserId


exec ProTLreportSRlist 106 

--------------------------------------------------try---------------------------------------------------

update  BPAStudentAdmissionDetails set EnquiryId=1200 where AdmissionId=101

delete from BPAStudentAdmissionDetails where AdmissionId=105

-----------------------------------------tryyyyyy---------------------------------------------------------------

alter procedure tab11 (@ReportingTo int)
as
declare temp2 cursor  for Select b.FirstName[Name],count(a.UserId)[Enqueries] From BPAEnquiryInfo a inner join BPAUserMaster b on a.UserId=b.UserId and b.ReportingTo=106 group by b.FirstName
declare temp3 cursor for select count(UserId)[FollowUps] from BPAFollowUP group by UserId 

open temp2
open temp3
declare @tab table(Name varchar(30),Enqueries int,FollowUps int)
declare @q varchar(30)
declare @w int
declare @e int
fetch from temp2 into @q,@w
fetch from temp3 into @e
insert into @tab values(@q,@w,@e)
select * from @tab

deallocate temp2
deallocate temp3


exec tab11 106
---------------------------------------------------try-----------------------------------------------------
declare temp cursor  for select * from [BPAAdminDatabaseAssign]
declare temp1 cursor for select DatabaseRoleId,DatabseId,DatabaseName,CreatedDate from BPAAdminDatabaseCreate
open temp1
open temp
declare @did int
declare @TLID int
declare @Adate date;
declare @Adesc varchar(max)
declare @Rid int
declare @Cdate date
declare @dbname varchar(20)
declare @dbid int
declare @res varchar(30)
declare @tab table(DatabaseRoleId int,DatabseId int,DatabaseName varchar(50),CreatedDATE date,TeamLeadI int,AssignedDate date,AssignDescription varchar(max), Assign varchar(20)) 

fetch from temp1 into @Rid,@dbid,@dbname,@Cdate
 while @@FETCH_STATUS<>-1
 begin
   fetch from temp into @did,@TLID ,@Adesc,@Adate
   set @res='Not Assigned'
   while @@FETCH_STATUS<>-1
   begin     
     if(@did=@dbid)
     begin
        set @res='Assigned'
        break
     end
     fetch from temp into @did,@TLID ,@Adesc,@Adate
   end
   
   if(@res!='Assigned')
    begin
       set @TLID=null;
       set @Adate=null;
       set @Adesc=null;
       
    end
   
   insert into @tab values(@Rid,@dbid,@dbname,@Cdate,@TLID,@Adate,@Adesc,@res)
   fetch from temp1 into @Rid,@dbid,@dbname,@Cdate
   
 end
 select * from @tab
deallocate temp
deallocate temp1
exec 
--------------------------------------------ProPerformanceReport----------try------------------------------------------------------------
alter Procedure ProPerformanceReport @Userid int
as
select t1.UserId, t1.FirstName[Name],t1.[Enqueries],t2.[Followups],(t1.[Enqueries])[Revenue] from
(Select b.UserId, b.FirstName,count(a.EnquiryId)[Enqueries] From  BPAEnquiryInfo a  inner join 
BPAUserMaster b on a.UserId=b.UserId group by b.UserId,b.FirstName )t1
left outer join 
(select UserId, count(userid)[Followups] from BPAFollowUP group by UserId)t2 on t1.UserId=t2.UserId

inner join 
(select StudentId,EnquiryId from BPAStudentAdmissionDetails group by StudentId,EnquiryId)t3 on t1.


exec ProPerformanceReport

-----------------------------------------ProEnquiryList-----------------------------------------------------------------
alter procedure ProEnquiryList @UserId int
as
select  s3.StudentName,s1.[Enquiry Date],s4.[Course Name],s1.[Decision Maker],s1.Relationship,s1.[DecisionMaker Contact Number] from  
(select StudentId[StudentName],UserId[SrName],CONVERT(varchar(12),Date,107)[Enquiry Date],CourseId,DecisionMaker[Decision Maker],Relationship[Relationship],DecisionMakerContactNumber[DecisionMaker Contact Number] from BPAEnquiryInfo where UserId=@UserId)s1

inner join ( select FirstName[StudentName], StudentId from BPAStudentInfo)s3 on s1.StudentName=s3.StudentId 
inner join ( select Course[Course Name],courseid from BPACourseMaster)s4 on s1.CourseId=s4.CourseId
exec ProEnquiryList 107


--------------------------------------------------try-------------------------------------------
select t2.UserId,t2.UserId,t1.Courseid,t1.CourseFees from
(select StudentId,a.Courseid,sum(b.CourseFees)[coursefee]  from BPAStudentAdmissionDetails a
inner join BPACourseMaster b on a.Courseid=b.CourseId)t1
inner join (select b.UserId,COUNT( a.StudentId)[no_addmission] from BPAStudentAdmissionDetails a inner join 
BPAUserMaster b on a.UserId=b.UserId group by b.UserId)t2 on t1.StudentId=t2.UserId

----------------------------------------------

delete from BPAStudentAdmissionDetails where AdmissionId=110 
---------------------------------------------ProPerformanceReport-------------------------------------------------------
alter Procedure ProPerformanceReport
as
select t1.UserId, t1.FirstName[Name],t1.[Enqueries],t2.[Followups] from
(Select b.UserId, b.FirstName,count(a.EnquiryId)[Enqueries] From  BPAEnquiryInfo a  inner join 
BPAUserMaster b on a.UserId=b.UserId group by b.UserId,b.FirstName)t1
left outer join 
(select UserId, count(userid)[Followups] from BPAFollowUP group by UserId)t2 on t1.UserId=t2.UserId
inner join 
(select s.StudentId,e.EnquiryId,s.Courseid from BPAStudentAdmissionDetails s inner join BPAEnquiryInfo e 
on s.EnquiryId=e.EnquiryId group by s.StudentId,e.EnquiryId,s.Courseid)t3 
left outer join 
(select c.CourseId,sum(c.CourseFees) from BPACourseMaster c inner join BPAEnquiryInfo e
on c.CourseId=e.CourseId group by c.CourseId,c.CourseFees)


exec ProPerformanceReport



------------------------------------------ProPerformanceReport-----------try-----------------------------------------------------------

alter Procedure ProPerformanceReport
as
select t1.UserId, t1.FirstName[Name],t1.[Enqueries],t2.[Followups],(t1.[Enqueries])[Revenue] from
(Select b.UserId, b.FirstName,count(a.EnquiryId)[Enqueries] From  BPAEnquiryInfo a  inner join 
BPAUserMaster b on a.UserId=b.UserId group by b.UserId,b.FirstName)t1
left outer join 
(select UserId, count(userid)[Followups] from BPAFollowUP group by UserId)t2 on t1.UserId=t2.UserId



alter Procedure ProPerformanceReport
as
select t1.UserId, t1.FirstName[Name],t1.[Enqueries],t2.[Followups],t3.Admissions,t4.Revenue from
(Select b.UserId, b.FirstName,count(a.EnquiryId)[Enqueries] From  BPAEnquiryInfo a  inner join 
BPAUserMaster b on a.UserId=b.UserId group by b.UserId,b.FirstName)t1
left outer join 
(select UserId, count(userid)[Followups] from BPAFollowUP group by UserId)t2 on t1.UserId=t2.UserId
left outer  join
(select UserId,Courseid, count(userid)[Admissions] from BPAStudentAdmissionDetails 
group by Userid,Courseid)t3 on t1.UserId=t3.UserId
left outer join
(select CourseId,sum(CourseFees)[Revenue] from BPACourseMaster group by CourseId,CourseFees)t4 on t3.Courseid=t4.CourseId
exec ProPerformanceReport 101
select * from BPAUserMaster

--------------------------------------ProFollowUp--------------------------------------------------------
alter procedure ProFollowUp @UserId int
as
select s2.SrName, s3.StudentName,s1.[ Followup Date],s1.Description from  
(select StudentId[StudentName],UserId[SrName],CONVERT(varchar(12),FollowUpDate,107)[ Followup Date],FollowUpDescription[Description] from BPAFollowUp where UserId=@UserId)s1
inner join (select FirstName[Srname],userid from BPAUserMaster)s2 on s1.SrName=s2.UserId 
inner join ( select FirstName[StudentName], StudentId from BPAStudentInfo)s3 on s1.StudentName=s3.StudentId 
exec ProFollowUp 107
-------------------------------------------try---------------------------------------------------------------------
select * from BPAUserMaster
select * from BPAStudentInfo
select * from BPACourseMaster
select * from BPAStudentAdmissionDetails
delete from BPAUserMaster where UserId=104
select * from BPAStudentInfo
-----------------------------------------------ProPerformanceReport-------------------------------------------------------------------
alter Procedure ProPerformanceReport
as
select t1.UserId, t1.FirstName[Name],t1.[Enqueries],t2.[Followups],t3.Admissions,t4.Revenue from
(Select b.UserId, b.FirstName,count(a.EnquiryId)[Enqueries] From  BPAEnquiryInfo a  inner join 
BPAUserMaster b on a.UserId=b.UserId group by b.UserId,b.FirstName)t1
left outer join 
(select UserId, count(userid)[Followups] from BPAFollowUP group by UserId)t2 on t1.UserId=t2.UserId
left outer  join
(select UserId,Courseid, count(userid)[Admissions] from BPAStudentAdmissionDetails 
group by Userid,Courseid)t3 on t1.UserId=t3.UserId
left outer join
(select CourseId,sum(CourseFees)[Revenue] from BPACourseMaster group by CourseId,CourseFees)t4 on t3.Courseid=t4.CourseId

exec ProPerformanceReport
-----------------------------------------------------ProAdmissions----------------------------------------------------------------
alter procedure ProAdmissions @UserId int
as
select s2.SrName,s4.[Student Name], s1.[Admission Date],s3.[Course Name],s4.City,s4.Qualification,s1.Remark from  
(select StudentId[StudentName],UserId[SrName],CONVERT(varchar(12),AdmissionDate,107)[Admission Date],courseid[Course],Remarks[Remark] from BPAStudentAdmissionDetails where UserId=@UserId)s1
inner join (select FirstName[Srname],userid from BPAUserMaster)s2 on s1.SrName=s2.UserId 
inner join ( select course[Course Name],courseid from BPACourseMaster)s3 on s1.Course=s3.CourseId
inner join ( select StudentId,FirstName[Student Name],City[City],Qualification[Qualification] from BPAStudentInfo)s4 on s1.StudentName=s4.StudentId
exec ProAdmissions 107
-----------------------------------------------TeamleadReportDuration1----------------------------------------------------------------------
select * from BPAUserMaster
update BPAUserMaster set dateofjoin=null where UserId=109
alter procedure TeamleadReportDuration @From int,@to int
as
select t1.UserName,t1.RoleName,t2.ReportingTo,t1.DateOfJoin from 
(select Firstname[UserName],role[RoleName],reportingto,convert(varchar(12),dateofjoin,107)[Dateofjoin] from Bpausermaster a 
inner join BPARoleMaster b on a.RoleId=b.RoleId where datename(yyyy,dateofjoin)  between @From and @to)t1  inner join
(select Firstname[ReportingTo] ,userid from BPAUserMaster)t2 on t1.ReportingTo=t2.UserId

exec TeamleadReportDuration 1990,2014
create table sss(da date null)
insert into sss values ('1-1-2011')
select * from sss
delete from sss
alter table sss alter column da datetime 

alter table BPAusermaster  drop column dateofjoin add constraint Dateofjoin date default(getdate()) null
alter table BPAusermaster add Dateofjoin date default(getdate()) null

-----------------------------------------------------------------------------------------------------------------
------------------------------------------------Dashboard----------------------------------------------------------------------
------------------------------------------

select * from BPAUserMaster
create procedure [dbo].[TeamleadReportDuration1] @From int,@to int
as
select t1.UserName,t1.RoleName,t2.ReportingTo,t1.DateOfJoin from 
(select Firstname[UserName],role[RoleName],reportingto,convert(varchar(12),dateofjoin,107)[Dateofjoin] from Bpausermaster a inner join BPARoleMaster b on a.RoleId=b.RoleId where datename(yyyy,DateOfJoin)  between @From and @to)t1  inner join
(select Firstname[ReportingTo] ,userid from BPAUserMaster)t2 on t1.ReportingTo=t2.UserId

exec TeamleadReportDuration1 2013,2014
--------------------------------------------
select * from BPAEventApplicableTo
delete from BPACalenderOfEvents where [EventId]=6006
select * from BPACalenderOfEvents

alter procedure ProEventDashboard
as
select  top 3 eventid[EventId], EventName
[EventName],CONVERT(varchar(12),EventDate,107)[DateOfEvent] from BPACalenderOfEvents order by DATEPART(DAYOFYEAR,EventDate) 

exec ProEventDashboard
--------------------------Display event Details-------------------------------
create procedure [dbo].[ProSearchEventDetails] @EventId int,@UserId int
as
select t1.Eventid,t3.EventCreatorName,t1.EventDetails,t1.DateOfEvent,t2.EventApplicableTo,t1.DateOfAssign,t1.Remarks from
(select a.Eventid,EventDetails,convert(varchar(12),EventDate,107)[DateOfEvent],b.UserId,EventCreator,convert(varchar(12),b.DateOfAssign,107)[DateOfAssign],b.Remarks from BPACalenderOfEvents a inner join BpaEventApplicableTo b on a.Eventid=b.EventId where (a.Eventid like @EventId or b.UserId like @UserId) and (EventStatus='Active'))t1
inner join
(select Firstname[EventApplicableTo],userid from BPAUserMaster)t2 on t1.UserId=t2.UserId inner join (select FirstName[EventCreatorName],userid from BPAUserMaster)t3 on t1.EventCreator=t3.UserId

exec ProSearchEventDetails 108,106 
--------------------------------------mails-----------------
select Subject,CONVERT(varchar(12),DateOfSend,107)[dateOfsend] from BPAMails where DateOfSend=Convert(varchar(12),GETDATE(),107) or datepart(DAYOFYEAR,DateOfSend)=(datepart(DAYOFYEAR,GETDATE())-1)
 -------------------------------------------------------
 update BPAMeeting set Date='05/17/2014' where MeetingId=2000
 -----------------------------------------Meeting--------------
 
 select * from BPAMeeting
 create procedure ProMeetingDashboard
 as
 select top 3 meetingid,MeetingName,convert(varchar(12),date,107)[DateOfMeeting] from BPAMeeting order by DATEPART(DAYOFYEAR,Date)
 
 exec ProMeetingDashboard
 
 create procedure ProMeetingDashboardDetailsDisplay @MeetingId int
 as
 select MeetingId,MeetingName,Description,CONVERT(varchar(12),date,107)[DateOfMeeting],StartTime,EndTime,Location from bpameeting where MeetingId=@MeetingId
 
 exec ProMeetingDashboardDetailsDisplay 2001
 
 
 ----------------------Mails------------------------
 select * from BPAMails
 insert into BPAMails values('hi','Check attachment',100,'5-26-2014','c:hhih.doc')
 select * from BPAMailsRecepients
 insert into BPAMailsRecepients values (1299,100,108)
Create procedure ProMailDashBoard(@UserId int)
as
select a.MailId, b.FirstName[Sender Name],Subject,a.DateOfSend from BPAMails a inner join BPAUserMaster b on a.SenderId=b.UserId inner join BPAMailsRecepients c on a.MailId=c.MailId and c.ReceiverId=@UserId and convert(varchar(12),DateOfSend,106)=convert(varchar(12),GETDATE(),106)-- and datediff(dd,a.date,getdate())=2 
  exec ProMailDashBoard 100

alter procedure ProMailDashBoard(@UserId int)
as
select a.MailId, b.FirstName[SenderName],Subject,convert(varchar(12),a.DateOfSend,107)[DateOfSend] from BPAMails a 
inner join BPAUserMaster b on a.SenderId=b.UserId inner join BPAMailsRecepients c on a.MailId=c.MailId and c.ReceiverId=@UserId 
where DateOfSend=Convert(varchar(12),GETDATE(),107) or datepart(DAYOFYEAR,DateOfSend)=(datepart(DAYOFYEAR,GETDATE())-1)
order by  dateofsend desc

exec ProMailDashBoard 100
 --------------------------------------------------
 
 create procedure ProMailDashBoardDisplay @MailId int
 as
 select a.MailId, b.FirstName[SenderName],b.EmailId[SenderMailId],Subject,Message,Attachment,convert(varchar(12),a.DateOfSend,107)[DateOfSend] from BPAMails a inner join BPAUserMaster b on a.SenderId=b.UserId where a.MailId=@MailId  
exec ProMailDashBoardDisplay 1302
  -------------------------------------------
---------------------------------------------------
alter procedure ProTeamleadDashboard
as
select w2.UserId,w2.FirstName[Teamlead],w1.NofoSR[NoofSR],w1.[No. of Enqueries][NoofEnqueries],w1.[No. of Followups][NoofFollowups],w1.[No.of Admissions][NoofAdmissions] from
(select s1.ReportingTo,COUNT(isnull(s1.SalesRepresentativeName,0))[NofoSR],SUM(isnull(s1.[No. of Enqueries],0))[No. of Enqueries],SUM(isnull(s1.[No. of Followups],0))[No. of Followups],SUM(isnull(s1.[No.of Admissions],0))[No.of Admissions] from 
(select t1.ReportingTo,t1.FirstName[SalesRepresentativeName],t1.[No. of Enqueries],t2.[No. of Followups],(t1.[No. of Enqueries]-t2.[No. of Followups])[No.of Admissions]  from
(Select b.UserId, b.RoleId,b.FirstName,b.ReportingTo,count(a.EnquiryId)[No. of Enqueries] From  BPAEnquiryInfo a  left outer join 
BPAUserMaster b on a.UserId=b.UserId and b.RoleId=333 group by b.UserId,b.FirstName,b.ReportingTo,b.RoleId)t1
left outer join 
(select UserId,COUNT(userid) [No. of Followups] from BPAFollowUP   
group by UserId)t2
on t1.UserId=t2.UserId  )s1 group by s1.ReportingTo)w1 inner join (select FirstName,UserId from BPAUserMaster)w2 on w1.ReportingTo=w2.userid order by w1.[No.of Admissions] desc

exec ProTeamleadDashboard

-------------------Display Link------------------------
create Procedure [dbo].[ProTeamleadDisplay]  @ReportingTo int
as
 
select t1.FirstName[Sales Representative Name],t1.[No. of Enqueries],t2.[No. of Followups],(t1.[No. of Enqueries]-t2.[No. of Followups])[No.of Admissions]  from
(Select b.UserId, b.FirstName,count(a.EnquiryId)[No. of Enqueries] From  BPAEnquiryInfo a  inner join 
BPAUserMaster b on a.UserId=b.UserId and b.ReportingTo=@ReportingTo group by b.UserId,b.FirstName)t1
left outer join 
(select UserId,COUNT(userid) [No. of Followups] from BPAFollowUP   
group by UserId)t2
on t1.UserId=t2.UserId
 exec ProTeamleadDisplay 106

alter procedure [dbo].[ProEventDashboardDetails] @EventId int
as
select t1.Eventid,t3.EventCreatorName,t1.EventName,t1.EventDetails,t1.DateOfEvent,t2.EventApplicableTo,t1.DateOfAssign,t1.Remarks from
(select a.Eventid,a.EventName,EventDetails,convert(varchar(12),EventDate,107)[DateOfEvent],b.UserId,EventCreator,convert(varchar(12),b.DateOfAssign,107)[DateOfAssign],b.Remarks from BPACalenderOfEvents a inner join BpaEventApplicableTo b on a.Eventid=b.EventId where (a.Eventid like @EventId) and (EventStatus='Active'))t1
inner join
(select Firstname[EventApplicableTo],userid from BPAUserMaster)t2 on t1.UserId=t2.UserId inner join (select FirstName[EventCreatorName],userid from BPAUserMaster)t3 on t1.EventCreator=t3.UserId

exec ProEventDashboardDetails 6001


select * from BPAMeeting

delete From BPAMeeting
select * from BPAUserMaster