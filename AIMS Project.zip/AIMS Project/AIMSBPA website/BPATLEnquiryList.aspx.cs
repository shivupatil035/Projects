﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BPABusinessLayer;
using System.Data;

public partial class BPATLEnquiryList : System.Web.UI.Page
{
    static int id;
    static int id1;
    static int id2;
    BPABLData obj = new BPABLData();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.QueryString["stid"] != null)
        {
            id = Convert.ToInt32(Request.QueryString["stid"]);
            
            DataTable dt = obj.EnquiryInfo(id);
           
            GridEnquiries.DataSource = dt;
            GridEnquiries.DataBind();
            
        }
        else if (Request.QueryString["stid1"] != null)
        {

            id1 = Convert.ToInt32(Request.QueryString["stid1"]);
            DataTable dt1 = obj.FollowUpInfo(id1);
            GridEnquiries.DataSource = dt1;
            GridEnquiries.DataBind();
        }
        else
        {

            id2 = Convert.ToInt32(Request.QueryString["stid2"]);
            DataTable dt2 = obj.AdmissionInfo(id2);
            GridEnquiries.DataSource = dt2;
            GridEnquiries.DataBind();
        }

    }

    protected void GridEnquiries_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void GridEnquiries_RowCreated(object sender, GridViewRowEventArgs e)
    {
        if (Request.QueryString["stid"] != null)
        {
            if (e.Row.RowType == DataControlRowType.Header)
            {
                e.Row.Cells[0].Text = "Students Name";
                //e.Row.Cells[1].Text = "Sales Representatives";
                //e.Row.Cells[2].Text = "No. of Enqueries ";
                //e.Row.Cells[3].Text = "No. of Followups";
                //e.Row.Cells[4].Text = "Closed Revenue";

                e.Row.Cells[0].CssClass = "cDBname";
                e.Row.Cells[1].CssClass = "cdesc";
                e.Row.Cells[2].CssClass = "cadminid";
                e.Row.Cells[3].CssClass = "cDBname";
                e.Row.Cells[4].CssClass = "cDBname";


            }

            else if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Cells[0].CssClass = "DBname";
                e.Row.Cells[1].CssClass = "desc";
                e.Row.Cells[2].CssClass = "adminid";
                e.Row.Cells[3].CssClass = "DBname";
                e.Row.Cells[4].CssClass = "DBname";
                e.Row.Cells[5].CssClass = "DBname";


            }
            else 
            {
                if (e.Row.RowType == DataControlRowType.Header)
                {
                    e.Row.Cells[0].Text = "Students Name";
                    //e.Row.Cells[1].Text = "Sales Representatives";
                    //e.Row.Cells[2].Text = "No. of Enqueries ";
                    //e.Row.Cells[3].Text = "No. of Followups";
                    //e.Row.Cells[4].Text = "Closed Revenue";

                    e.Row.Cells[0].CssClass = "cDBname";
                    e.Row.Cells[1].CssClass = "cdesc";
                    e.Row.Cells[2].CssClass = "cadminid";
                    e.Row.Cells[3].CssClass = "cDBname";
                


                }

               else if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    e.Row.Cells[0].CssClass = "DBname";
                    e.Row.Cells[1].CssClass = "desc";
                    e.Row.Cells[2].CssClass = "adminid";
                    e.Row.Cells[3].CssClass = "DBname";
                    


                }
            
            
            }
        }
    }
}