﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BPABusinessLayer;
using System.Data;

public partial class BPAPromotionalActivityditaspx : System.Web.UI.Page
{
    BPABLData obj = new BPABLData();
    static int previous;
    static int present;
    private int index;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            GridView1.DataSource = obj.SelectPromotionalActivity();
            GridView1.DataBind();
        }
    }


    protected void BtnEdit_Click(object sender, EventArgs e)
    {
        foreach (GridViewRow r in GridView1.Rows)
        {
            CheckBox cb = (CheckBox)r.FindControl("CheckBox1");
            if (cb.Checked)
            {
                GridViewRow row = (GridViewRow)cb.Parent.Parent;
                index = row.RowIndex;

                var id = (GridView1.Rows[index].Cells[1].Text);
                Response.Redirect("BPAPromotionalAdd.aspx?id=" + id);
            }
        }
        GridView1.DataSource = obj.SelectPromotionalActivity();
        GridView1.DataBind();
    
    }
    protected void BtnDelete_Click(object sender, EventArgs e)
    {
        foreach (GridViewRow r in GridView1.Rows)
        {
            CheckBox cb = (CheckBox)r.FindControl("CheckBox1");
            if (cb.Checked)
            {
                GridViewRow row = (GridViewRow)cb.Parent.Parent;
                index = row.RowIndex;

                Label1.Text = obj.DeletePromotionalActivity(Convert.ToInt32(GridView1.Rows[index].Cells[1].Text));
            }
        }
        GridView1.DataSource = obj.SelectPromotionalActivity();
        GridView1.DataBind();

    }
    protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
    {
        CheckBox cb = (CheckBox)sender;
        if (cb.Checked)
        {
            present = ((GridViewRow)cb.Parent.Parent).RowIndex;

            if (previous != -1)
            {
                CheckBox preCb = (CheckBox)GridView1.Rows[previous].Cells[0].FindControl("CheckBox1");
                preCb.Checked = false;
                previous = present;
                present = -1;
            }
            else if (previous == -1)
            {
                previous = present;
                present = -1;
            }


        }
       
    }

       
    protected void GridView1_RowCreated1(object sender, GridViewRowEventArgs e)
    {
         if (e.Row.RowType == DataControlRowType.Header)
        {
            e.Row.Cells[0].Text = "Select";
            e.Row.Cells[1].Text = "Promotinal ID";
            e.Row.Cells[2].Text = "Promotional Type";
            e.Row.Cells[3].Text = "Subject";
            e.Row.Cells[4].Text = "Amount";
            e.Row.Cells[5].Text = " From";
            e.Row.Cells[6].Text = "To";
            e.Row.Cells[7].Text = "Attachments";
            e.Row.Cells[8].Text = "Remark";
            e.Row.Cells[9].Visible = false; ;

            e.Row.Cells[0].CssClass = "select";
            e.Row.Cells[1].CssClass = "pid";
            e.Row.Cells[2].CssClass = "ptype";
            e.Row.Cells[3].CssClass = "subject";
            e.Row.Cells[4].CssClass = "amt";
            e.Row.Cells[5].CssClass = "dstart";
            e.Row.Cells[6].CssClass = "dend";
            e.Row.Cells[7].CssClass = "attach";
            e.Row.Cells[8].CssClass = "remark";
        }

        else if (e.Row.RowType == DataControlRowType.DataRow)
        {

            e.Row.Cells[0].CssClass = "select";
            e.Row.Cells[1].CssClass = "pid";
            e.Row.Cells[2].CssClass = "ptype";
            e.Row.Cells[3].CssClass = "subject";
            e.Row.Cells[4].CssClass = "amt";
            e.Row.Cells[5].CssClass = "dstart";
            e.Row.Cells[6].CssClass = "dend";
            e.Row.Cells[7].CssClass = "attach";
            e.Row.Cells[8].CssClass = "remark";
            e.Row.Cells[9].Visible = false; ;


        }
    }
    protected void btnsearch_Click(object sender, EventArgs e)
    {
        DataTable dt = obj.SearchPromotionalActivity(Convert.ToInt32(txtsearch.Text));
        if (dt.Rows.Count > 0)
        {
            GridView1.DataSource = dt;
            GridView1.DataBind();
            Label1.Text = "No of record(s) found " + dt.Rows.Count.ToString();
        }
        else
        {
            GridView1.DataSource = null;
            GridView1.DataBind();
            Label1.Text = "No Records found matching your criteria";
        }
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.DataSource = obj.SelectPromotionalActivity();
        GridView1.DataBind();
        GridView1.PageIndex = e.NewPageIndex;
    }
}
