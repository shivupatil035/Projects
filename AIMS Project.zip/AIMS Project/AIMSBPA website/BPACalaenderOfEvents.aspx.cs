﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BPABusinessLayer;
using System.Data;

public partial class BPACalaenderOfEvents : System.Web.UI.Page
{
    BPABLData obj = new BPABLData();
    int EventId = 0;
    static int previous;
    static int present;
    private int index;
    public List<DateTime> EvenDate = new List<DateTime>();
    public List<string> EventName = new List<string>();
   
    protected void Page_Load(object sender, EventArgs e)
    {
        PanelInbox.Visible = false;
        PanelOutbox.Visible = false;
        Panel2.Visible = false;
       // calander.Visible = false;

        GetEvenDate();


        if (!IsPostBack)
        {
           
            ddlCreate.DataSource = obj.ReportTo();
            ddlCreate.DataTextField = "FirstName";
            ddlCreate.DataValueField = "UserId";
            ddlCreate.DataBind();
            ddlCreate.Items.Insert(0, "--Select--");


            DLUserId.DataSource = obj.ReportTo();
            DLUserId.DataTextField = "FirstName";
            DLUserId.DataValueField = "UserId";
            DLUserId.DataBind();
            DLEventId.Items.Insert(0, "--Select--");


            DLUserId.Items.Insert(0, "--select--");
            DLEventId.DataSource = obj.SelectEventId();
            DLEventId.DataTextField = "EventId";
            DLEventId.DataValueField = "EventId";
            DLEventId.DataBind();

            GridView1.DataSource = obj.DisplayEvents();
            GridView1.DataBind();




            if (Request.QueryString["id"] != null)
            {
                PanelInbox.Visible = true;
                calander.Visible = false;
                DataTable dt = obj.FetchEvent(Convert.ToInt16(Request.QueryString["id"]));
                DLEventId.SelectedValue = dt.Rows[0][0].ToString();
              //  txtremarks.Text = dt.Rows[0][1].ToString();
         

            }
        }
       
    }


    protected void btnView_Click1(object sender, EventArgs e)
    {
        calander.Visible = true;
        CalendarEvents.Visible = false;
        CallEventDetails.Visible = true;
        llCallEventDetails.DataSource = obj.ViewEventDetails();
        llCallEventDetails.DataBind();
    }
    public void GetEvenDate()
    {
        DataTable dt = obj.GetEventDate();
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            EvenDate.Add((DateTime)dt.Rows[i][4]);
            EventName.Add(dt.Rows[i][1].ToString());

        }
    }
    protected void CalendarEvents_DayRender(object sender, DayRenderEventArgs e)
    {
        string tooltip = string.Empty;
        if (isevent(e.Day.Date, out tooltip))
        {
            e.Cell.BackColor = System.Drawing.Color.LightBlue;
            e.Day.IsSelectable = true;
            e.Cell.ToolTip = tooltip;
        }
        else
        {
            e.Day.IsSelectable = false;
        }
    }
    public bool isevent(DateTime day, out string tooltipvalue)
    {
        tooltipvalue = string.Empty;
        for (int i = 0; i < EvenDate.Count; i++)
        {
            if (EvenDate[i] == day)
            {
                tooltipvalue = EventName[i];
                return true;
            }

        }
        return false;

    }
    protected void CalendarEvents_VisibleMonthChanged(object sender, MonthChangedEventArgs e)
    {
        GetEvenDate();
    }
    protected void CalendarEvents_SelectionChanged(object sender, EventArgs e)
    {
        llCallEventDetails.Visible = true;
        CallEventDetails.Visible = true;
        CalendarEvents.Visible =true;
        CallEventDetails.Visible = true;
        calander.Visible = true;
        DateTime dat = CalendarEvents.SelectedDate;
        DataTable dt = obj.CallEventDetails(dat);
        llCallEventDetails.DataSource = dt;
        llCallEventDetails.DataBind();
        //    gdCallEvents.DataSource = obj.CallEventDetails(dat);
        //    gdCallEvents.DataBind();
    }



    protected void GridView2_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
       
    }
    protected void Button2_Click1(object sender, EventArgs e)
    {
        llCallEventDetails.Visible = false;
        PanelInbox.Visible = true;
        Panel2.Visible = false;
        calander.Visible = false;
        PanelOutbox.Visible = false;
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        llCallEventDetails.Visible = false;
        Panel2.Visible = true;
        PanelInbox.Visible = false;
        PanelOutbox.Visible = false;
        calander.Visible = false;
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        llCallEventDetails.Visible = false;
        PanelOutbox.Visible = true;
        PanelInbox.Visible = false;
        Panel2.Visible = false;
        calander.Visible = false;
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        Panel2.Visible = true;
        try
        {

            Label1.Text = obj.Addevent(Convert.ToInt32(ddlCreate.SelectedValue), txtname.Text, TxtDescription.Text, Convert.ToDateTime(datepicker.Text));
        }
        catch
        {
            Label1.Text = "Please fill all fields";
        }
    }
    protected void BtAssign_Click(object sender, EventArgs e)
    {
        PanelInbox.Visible = true;
        try
        {
            Label2.Text = obj.EventApplicableIns(Convert.ToInt16(DLEventId.SelectedValue), Convert.ToInt32(DLUserId.SelectedValue), txtremarks.Text);
        }
        catch
        {
            Label2.Text = "Please fill all fields";
        }
    }
    protected void BtnEdit_Click(object sender, EventArgs e)
    {
        calander.Visible = false;
        PanelInbox.Visible = true;
        try
        {
            foreach (GridViewRow r in GridView1.Rows)
            {
                CheckBox cb = (CheckBox)r.FindControl("CheckBox1");
                if (cb.Checked)
                {
                    GridViewRow row = (GridViewRow)cb.Parent.Parent;
                    index = row.RowIndex;

                    var id = (GridView1.Rows[index].Cells[2].Text);
                    Response.Redirect("BPACalaenderOfEvents.aspx?id=" + id);
                }
            }
            GridView1.DataSource = obj.DisplayEvents();
            GridView1.DataBind();
        }
        catch
        {
            Label3.Text = "Something went wrong";
        }



    }






        //int EventId = Convert.ToInt32(Request.QueryString["Event"]);

//        Label1.Text = obj.UpdateEvents(Convert.ToInt32(EventId), Convert.ToInt32(ddlCreate.SelectedValue), TxtDescription.Text, Convert.ToDateTime(datepicker.Text), Convert.ToInt32(DLEventId.SelectedValue), Convert.ToInt32(DLUserId.SelectedValue), txtremarks.Text);
      //  int index = -1;
        //foreach (GridViewRow r in GridView1.Rows)
        //{
        //    CheckBox cb = (CheckBox)r.FindControl("CheckBox1");
        //    if (cb.Checked)
        //    {
        //        GridViewRow row = (GridViewRow)cb.Parent.Parent;
        //        index = row.RowIndex;

        //        ListItem selItem = DLEventId.Items.FindByValue(GridView1.Rows[index].Cells[1].Text);
        //        int ddlIndex = DLEventId.Items.IndexOf(selItem);
        //        DLEventId.SelectedIndex = ddlIndex;
        //        //Session["update"] = 1;
        //        ListItem DLUserId = DLEventId.Items.FindByValue(GridView1.Rows[index].Cells[2].Text);
        //        int ddlIndex1 = DLUserId.items.IndexOf(selItem);
        //        DLEventId.SelectedIndex = ddlIndex1;
        //        //Session["update"] = 1;
        //       // DLEventId.Text = GridView1.Rows[index].Cells[1].Text;
        //       // DLUserId.Text = GridView1.Rows[index].Cells[2].Text;
        //        txtremarks.Text = GridView1.Rows[index].Cells[3].Text;
               
        //       // Session["update"] = 1;
        //        //to populated the selected Account type in dropdownlist1
                
              



        //    }
        //}




    
    protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
    {
        PanelOutbox.Visible = true;
        CheckBox cb = (CheckBox)sender;
        if (cb.Checked)
        {
            present = ((GridViewRow)cb.Parent.Parent).RowIndex;
            previous = 0;
            if (previous != -1)
            {
                CheckBox preCb = (CheckBox)GridView1.Rows[previous].Cells[0].FindControl("CheckBox1");
                preCb.Checked = false;
                previous = present;
                present = -1;
            }
            else if (previous == -1)
            {
                previous = present;
                present = -1;
            }


        }

    }




    protected void BtnDelete_Click(object sender, EventArgs e)
    {
        calander.Visible = false;
        PanelOutbox.Visible = true;
        foreach (GridViewRow r in GridView1.Rows)
        {
            CheckBox cb = (CheckBox)r.FindControl("CheckBox1");
            if (cb.Checked)
            {
                GridViewRow row = (GridViewRow)cb.Parent.Parent;
                index = row.RowIndex;

                Label3.Text = obj.EventDeactive(Convert.ToInt32(GridView1.Rows[index].Cells[2].Text));
            }
        }
        GridView1.DataSource = obj.DisplayEvents();
        GridView1.DataBind();
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void llCallEventDetails_RowCreated(object sender, GridViewRowEventArgs e)
    {
        //if (e.Row.RowType == DataControlRowType.Header)
        //{
        //    e.Row.Cells[0].Visible = false;
        //    e.Row.Cells[1].Text = "Admin ID";
        //    e.Row.Cells[2].Text = "Select";
        //    e.Row.Cells[3].Text = "Database Name";



        //    e.Row.Cells[0].Visible = false;
        //    e.Row.Cells[1].CssClass = "adminid";
        //    e.Row.Cells[2].CssClass = "DBname";
        //    e.Row.Cells[3].CssClass = "cdate";
           


        //}

        //else if (e.Row.RowType == DataControlRowType.DataRow)
        //{
        //    e.Row.Cells[0].Visible = false;
        //    e.Row.Cells[1].CssClass = "adminid";
        //    e.Row.Cells[2].Text = "select";
        //    e.Row.Cells[3].CssClass = "DBname";
            



      //  }
        
    }
    protected void BtSearchId_Click(object sender, EventArgs e)
    {
        PanelOutbox.Visible = true;
        DataTable dt = obj.SearchEvent(txtid.Text);
        if (dt.Rows.Count > 0)
        {
            GridView1.DataSource = dt;
            GridView1.DataBind();
            Label3.Text = "No of record(s) found " + dt.Rows.Count.ToString();
        }
        else
        {
            GridView1.DataSource = null;
            GridView1.DataBind();
            Label3.Text = "No Records found matching your criteria";
        }
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.DataSource = obj.DisplayEvents();
        GridView1.DataBind();
        GridView1.PageIndex = e.NewPageIndex;
    }
}
