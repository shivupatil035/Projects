﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BPABusinessLayer;
using System.Data;

public partial class BPADatabaseCreate : System.Web.UI.Page
{
    BPABLData CourseInfo = new BPABLData();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            ddldbcreate.DataSource = CourseInfo.GetRoles();
            ddldbcreate.DataTextField = "Role";
            ddldbcreate.DataValueField = "RoleId";
            ddldbcreate.DataBind();
            ddldbcreate.Items.Insert(0, "--Select--");
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        
    }
    protected void Button1_Click1(object sender, EventArgs e)
    {
      
       lblmessage.Text = CourseInfo.AddDatabase(Convert.ToInt32(ddldbcreate.SelectedValue), txtdbname.Text, fudbdoc.FileName, txtdesc.Text);
      
    }
}