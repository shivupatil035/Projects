﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BPABusinessLayer;
using System.Data;

public partial class BPAPromotionalAdd : System.Web.UI.Page
{
    BPABLData obj = new BPABLData();
    int proid = 0;
  
    protected void Page_Load(object sender, EventArgs e)
    {
         if (Request.QueryString["id"] != null)
            {
                DataTable dt = obj.FetchPromotionalActivity(Convert.ToInt16(Request.QueryString["id"]));
                proid = Convert.ToInt16(dt.Rows[0][0]);
                ddlPAtyp.SelectedValue=dt.Rows[0][1].ToString();
                txtsubject.Text = dt.Rows[0][2].ToString();
                txtamt.Text = dt.Rows[0][3].ToString();
                datepicker.Text = dt.Rows[0][4].ToString();
                datepicker1.Text = dt.Rows[0][5].ToString();
              //  fuattach.FileName = dt.Rows[0][6].ToString();
                txtaremark.Text = dt.Rows[0][7].ToString();
                Button1.Text = "Update";

            }
        }
    

    
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (Button1.Text == "Add")
        {
            
                Label1.Text = obj.AddPromotionalActivity(ddlPAtyp.SelectedValue, txtsubject.Text, Convert.ToInt32(txtamt.Text), datepicker.Text, datepicker1.Text, fuattach.FileName, txtaremark.Text);

          
        }
        else
        {

            int proid = Convert.ToInt32(Request.QueryString["id"]);

            Label1.Text = obj.UpdatePromotionalActivity(proid, ddlPAtyp.SelectedValue, txtsubject.Text, Convert.ToInt32(txtamt.Text), Convert.ToDateTime(datepicker.Text), Convert.ToDateTime(datepicker1.Text), fuattach.FileName, txtaremark.Text);
        }
        
    }
}