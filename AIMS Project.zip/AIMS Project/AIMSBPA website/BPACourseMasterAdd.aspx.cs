﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BPABusinessLayer;
using System.Data;

public partial class BPACourseMasterAdd : System.Web.UI.Page
{
    static int id;
    BPABLData CourseInfo = new BPABLData();
    protected void Page_Load(object sender, EventArgs e)
    {
        
        btnupdate.Visible = false;

        if (!IsPostBack)
        {
            
            Page previouspage = this.PreviousPage;
            if (previouspage != null)
            {
                string grd = previouspage.FindControl("GridView1").ToString();
                Console.Write(grd);
            }

            id = Convert.ToInt32(Request.QueryString["stid"]);
            //txtcoursename.Text = id.ToString();
            if (id != null)
            {
                
                DataTable dt = CourseInfo.FetchCourse(id);

                foreach (DataRow r in dt.Rows)
                {
                    foreach (DataColumn c in dt.Columns)
                    {
                        txtcoursename.Text = r[1].ToString();

                        ddlyear.SelectedValue = r[2].ToString();
                        ddlyear.DataBind();

                        ddlmonth.SelectedValue = r[3].ToString();
                        ddlmonth.DataBind();

                        txtcoursefees.Text = r[4].ToString();
                       // datepicker.Text = r[5].ToString();
                        txtaremark.Text = r[5].ToString();
                        Button1.Visible = false;
                        btnupdate.Visible = true;

                    }
                }
            }
        }
    }
      public void clear()
     {
        txtcoursename.Text = "";
        
        txtaremark.Text = "";
        txtcoursefees.Text = "";
    
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        //try
        //{

            lblmessage.Text = CourseInfo.AddCourse(txtcoursename.Text, Convert.ToInt32(ddlyear.SelectedValue), Convert.ToInt32(ddlmonth.SelectedValue), Convert.ToInt32(txtcoursefees.Text), txtaremark.Text);
            clear();

     //   }
        //catch
        //{
        //    lblmessage.Text = "please fill all fields";
        //}

    }
    protected void btnupdate_Click(object sender, EventArgs e)
    {
        id = Convert.ToInt32(Request.QueryString["stid"]);


        lblmessage.Text = CourseInfo.UpdateCourse(id, txtcoursename.Text, Convert.ToInt32(ddlyear.SelectedValue), Convert.ToInt32(ddlmonth.SelectedValue), Convert.ToDouble(txtcoursefees.Text), txtaremark.Text);
    
    }
    protected void ddlmonth_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}