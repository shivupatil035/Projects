﻿
function validateCourse()
 {
    var cname = document.getElementById("txtcoursename").value;
    var fees = document.getElementById("txtcoursefees").value;
    var remark = document.getElementById("txtaremark").value;
     // var dob = document.getElementById("datepicker").value;
    var patcname = new RegExp("^[a-z#++ A-Z]{3,}$");
    var patNumber = new RegExp("^[0-9]{3,}$");
    var patremark = new RegExp("^[a-z A-Z]{3,}$");
    

    var ret = true;
    if (cname.length == 0) {
        
        document.getElementById("lblErrorName").innerHTML = "Enter the Course Name";
        ret = false;
        
    }

    else if (!patcname.test(cname)) {
        document.getElementById("lblErrorName").innerHTML = "Enter the valid Course Name";
        ret = false;}
    else {
        document.getElementById("lblErrorName").innerHTML = "";
    }

    


  if (fees.length == 0) {
      document.getElementById("lblErrorfeees").innerHTML = "fees can't be empty";

        ret = false;
    }
    else if (!patNumber.test(fees)) {
        document.getElementById("lblErrorfeees").innerHTML = "Enter valid fees";
        ret = false;
    }
    else {
        document.getElementById("lblErrorfeees").innerHTML = "";
    }


    if (remark.length == 0) {
        document.getElementById("lblErrorremark").innerHTML = "Enter the remark";
        ret = false;
    }

    else if (!patremark.test(remark)) {
        document.getElementById("lblErrorremark").innerHTML = "Enter valid remark";
        ret = false;
    }

    else {
        document.getElementById("lblErrorremark").innerHTML = "";
    }


    if (document.getElementById("ddlyear").selectedIndex == 0) {
        document.getElementById("lblErrorDuration").innerHTML = "Select Duration";
        ret = false;
    }
    else {
        document.getElementById("lblErrorDuration").innerHTML = "";
    }

    if (document.getElementById("ddlmonth").selectedIndex == 0) {

        document.getElementById("lblErrorDuration").innerHTML = "Select Duration";
        ret = false;
    }
    else {
        document.getElementById("lblErrorDuration").innerHTML = "";
    }















    return ret;

}



