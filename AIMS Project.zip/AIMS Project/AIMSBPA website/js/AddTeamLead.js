﻿function validateTeamlead() {
     
    var fname = document.getElementById("Txtfname").value;
    var email = document.getElementById("Txtemail").value;
    var phone = document.getElementById("TxtMobile").value;
    var offic = document.getElementById("TxtOffic").value;
    var address = document.getElementById("TxtAddress").value;
    var city = document.getElementById("Txtcite").value;
    var pin = document.getElementById("Txtpin").value;
    var qualification = document.getElementById("Txtquali").value;
    var genderm = document.getElementById("RadioButton1").checked;
    var genderf = document.getElementById("RadioButton2").checked;
    var password = document.getElementById("Txtpass").value;
    var dob = document.getElementById("datepicker").value;

    var patfname = new RegExp("^[a-zA-Z]{3,}$");
    var patNumber = new RegExp("^[7-9]{1}[0-9]{9}$");
    var patoffice = new RegExp("^[0-9]{10,}$");
    var patcity = new RegExp("^[a-zA-Z]{3,}$");
    var patpin = new RegExp("^[0-9]{6}$");
    var patqualification = new RegExp("^[a-zA-Z]{1,}$");
   //  var patemail = /^[a-z]+[a-zA-Z0-9\.\_]*@[a-z]+\.[a-z]{2,3}$/;
    

     var ret = true;
     if (fname.length == 0) {
         document.getElementById("lblfname").innerHTML = "Enter the FirstName";
         ret = false;
       }
     else if (!patfname.test(fname)) {
     document.getElementById("lblfname").innerHTML = "Enter the valid FirstName";
     ret = false;
     }
     else {
     document.getElementById("lblfname").innerHTML = "";
     }

     if (email.length == 0) {

        document.getElementById("Lblemail").innerHTML = "EmailId can't be empty";
        
        ret = false;
    }
    
//    else if (!patemail.test(email)) {
//        alert("welcome");
//        document.getElementById("Lblemail").innerHTML = "Enter the valid EmailId";
//        ret = false;
//    }
    else {
        document.getElementById("Lblemail").innerHTML = "";
    }
    if (phone.length == 0) {
        document.getElementById("Lblph").innerHTML = "Phone can't be empty";
       
        ret = false;
    }
    else if (!patNumber.test(phone)) {
    document.getElementById("Lblph").innerHTML = "Enter valid phone number";
        ret = false;
    }
    else {
        document.getElementById("Lblph").innerHTML = "";
    }
    if (offic.length == 0) {
        document.getElementById("lbloffic").innerHTML = "Official number is empty";

        ret = false;
    }
    else if (!patoffice.test(offic)) {
    document.getElementById("lbloffic").innerHTML = "Enter valid phone number";
        ret = false;
    }
    else {
        document.getElementById("lbloffic").innerHTML = "";
    } 
    
    if (address.length == 0) {
        document.getElementById("lbladdress").innerHTML = "Enter the Address";
        ret = false;
    }

    else {
        document.getElementById("lbladdress").innerHTML = "";
    }
    if (city.length == 0) {
        document.getElementById("lblcity").innerHTML = "Enter the City";
        ret = false;
    }

    else if (!patcity.test(city)) {
    document.getElementById("lblcity").innerHTML = "Enter valid City";
        ret = false;
    }

    else {
        document.getElementById("lblcity").innerHTML = "";
    }

    if (pin.length == 0) {
        document.getElementById("lblpin").innerHTML = "Enter PinCode";

        ret = false;
    }
    else if (!patpin.test(pin)) {
    document.getElementById("lblpin").innerHTML = "Enter valid Pincode";
        ret = false;
    }
    else {
        document.getElementById("lblpin").innerHTML = "";
    }
   
    if (qualification.length == 0) {
     
        document.getElementById("lblqualification").innerHTML = "Enter the Qualification";
        ret = false;
    }
    else if (!patqualification.test(qualification)) {
    document.getElementById("lblqualification").innerHTML = "Enter the valid Qualification";
        ret = false;
    }

    else {
        document.getElementById("lblqualification").innerHTML = "";
    }

    
    if (!genderm && !genderf)
     {
         
        document.getElementById("lblgender").innerHTML = "Select the gender";
        ret = false;
    }

    else {
        document.getElementById("lblgender").innerHTML = "";
    }

    if (password.length == 0) {

        document.getElementById("lblpass").innerHTML = "Enter the Password";
        ret = false;
    } 

    else {
        document.getElementById("lblpass").innerHTML = "";
    }

    var id = new Date();
    var id1 = new Date(dob);
    var dist = ((id.getYear()) -(id1.getYear()));
    if (dob.length == 0) {

        document.getElementById("lbldob").innerHTML = "Enter the DateOfBirth";
        ret = false;
    }

    else if (dist < 18) {
              document.getElementById("lbldob").innerHTML = "Please enter valid date";
            ret = false;

        }

        else {
        document.getElementById("lbldob").innerHTML = "";
    }

    if (document.getElementById("DropDownList1").selectedIndex == 0) {
        document.getElementById("lblreport").innerHTML = "Select Reporting to";
        ret = false;
    }
    else {
        document.getElementById("lblreport").innerHTML = "";
    }

    if (document.getElementById("DropDownList2").selectedIndex == 0) {
        document.getElementById("lblrole").innerHTML = "Select Role ";
        ret = false;
    }
    else {
        document.getElementById("lblrole").innerHTML = "";
    }
    




    return ret;
}



