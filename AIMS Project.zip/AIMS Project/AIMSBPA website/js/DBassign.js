﻿
function validateDBAssign() {
    var remark = document.getElementById("txtdescription").value;
    var patremark = new RegExp("^[a-z A-Z]{3,}$");
    
    var ret = true;

    if (document.getElementById("ddldbname").selectedIndex == 0) {
        document.getElementById("lblErrorName").innerHTML = "Select Database";
        ret = false;
    }
    else {
        document.getElementById("lblErrorName").innerHTML = "";
    }


    if (document.getElementById("ddlassign").selectedIndex == 0) {

        document.getElementById("lblErrorassign").innerHTML = "Select Team Lead";
        ret = false;
    }
    else {
        document.getElementById("lblErrorassign").innerHTML = "";
    }

    if (remark.length == 0) {
        document.getElementById("lblErrordesc").innerHTML = "Enter the description";
        ret = false;
    }

    else if (!patremark.test(remark)) {
        document.getElementById("lblErrordesc").innerHTML = "Enter valid description";
        ret = false;
    }

    else {
        document.getElementById("lblErrordesc").innerHTML = "";
    }

    return ret;

}



