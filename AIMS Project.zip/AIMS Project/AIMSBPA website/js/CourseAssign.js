﻿
function validateCourseAssign() {
    
    var remark = document.getElementById("txtaremark").value;
    var patremark = new RegExp("^[a-z A-Z]{3,}$");
    var ret = true;

    
    
    if (document.getElementById("ddlcourseid").selectedIndex == 0) {
        document.getElementById("lblErrorcid").innerHTML = "Select Course";
        ret = false;
    }
    else {
        document.getElementById("lblErrorcid").innerHTML = "";
    }
    


    if (document.getElementById("ddlteamleadid").selectedIndex == 0) {

        document.getElementById("lblErrortlname").innerHTML = "Select Team Lead";
        ret = false;
    }
    else {
        document.getElementById("lblErrortlname").innerHTML = "";
    }

    
    if (remark.length == 0) {
        document.getElementById("lblErrorremark").innerHTML = "Enter the remark";
        ret = false;
    }

    else if (!patremark.test(remark)) {
        document.getElementById("lblErrorremark").innerHTML = "Enter valid remark";
        ret = false;
    }

    else {
        document.getElementById("lblErrorremark").innerHTML = "";
    }














    return ret;

}



