﻿function validateLogin() {
    var email = document.getElementById("txtUserName").value;
    var password= document.getElementById("txtPassword").value;
    var ret = true;

    if (email.length == 0) {
        document.getElementById("lblemail").innerHTML = "Enter the EmailId";
        ret = false
    }
    else {
        document.getElementById("lblemail").innerHTML = "";
    }
    if (password.length == 0) {
        document.getElementById("lblValid").innerHTML = "Enter the Password ";
        ret = false;
    }
    else {
        document.getElementById("lblValid").innerHTML = "";
    }
    return ret;
   
}