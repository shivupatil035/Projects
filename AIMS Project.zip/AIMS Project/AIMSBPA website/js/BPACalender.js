﻿
function Validation() {

    if (EventName()) {
        if (EventTime()) {
            if (EventDesc()) {
                return true;
            }
        }
    }
    return false;
}
var _Mandatory = "All Fields are mandatory";

function EventName() {

    var _eventName = document.getElementById('addText').value;


    if (!_eventName.length > 0) {

        document.getElementById("ErrorMsg").innerHTML = _Mandatory;
        return false;
    }

    else if (_eventName.length > 50) {
        document.getElementById("ErrorMsg").innerHTML = "Maximum 50 characters";
        return false;
    }
    else {

        document.getElementById("ErrorMsg").innerHTML = "";

    }
    return true;
}

function EventTime() {

    var _eventTime = document.getElementById('addTime').value;
    var _time = new RegExp("^((0?[1-9])|(1[0-2]))\:[0-5][0-9](AM|PM|am|pm)$", "gi");

    if (!_eventTime.length > 0) {
        document.getElementById("ErrorMsg").innerHTML = _Mandatory;
        return false;
    }
    else if (!_time.test(_eventTime)) {
        document.getElementById("lblErrTime").innerHTML = "Insert time in Correct Format";
        return false;
    }
    else {
        document.getElementById("lblErrTime").innerHTML = "";
    }
    return true;
}

function EventDesc() {

    var _eventDesc = document.getElementById('addDescription').value;


    if (!_eventDesc.length > 0) {

        document.getElementById("ErrorMsg").innerHTML = _Mandatory;
        return false;
    }

    else if (_eventDesc.length > 150) {
        document.getElementById("ErrorMsg").innerHTML = "Maximum 150 characters";
        return false;
    }
    else {
        document.getElementById("ErrorMsg").innerHTML = "";

    }
    return true;
}
function DisplayDiv() {
    document.getElementById('Panel1')
}