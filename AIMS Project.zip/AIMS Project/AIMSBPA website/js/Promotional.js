﻿
function validatePA() {
    var cname = document.getElementById("txtsubject").value;
    var fees = document.getElementById("txtamt").value;
    var remark = document.getElementById("txtaremark").value;
    var dob = document.getElementById("datepicker").value;
    var dob1 = document.getElementById("datepicker1").value;
    var patcname = new RegExp("^[a-z A-Z]{3,}$");
    var patNumber = new RegExp("^[0-9]{3,}$");
    var patremark = new RegExp("^[a-z A-Z]{3,}$");


    var ret = true;
    if (cname.length == 0) {

        document.getElementById("lblErrorsubject").innerHTML = "Enter the Subject";
        ret = false;

    }

    else if (!patcname.test(cname)) {
        document.getElementById("lblErrorsubject").innerHTML = "Enter the valid Subject";
        ret = false;
    }
    else {
        document.getElementById("lblErrorsubject").innerHTML = "";
    }




    if (fees.length == 0) {
        document.getElementById("lblErroramount").innerHTML = "Amount can't be empty";

        ret = false;
    }
    else if (!patNumber.test(fees)) {
        document.getElementById("lblErroramount").innerHTML = "Enter valid Amount";
        ret = false;
    }
    else {
        document.getElementById("lblErroramount").innerHTML = "";
    }


    var id = new Date();
    var id1 = new Date(dob);
    var dist = ((id.getYear()) - (id1.getYear()));
    if (dob.length == 0) {

        document.getElementById("lbldob").innerHTML = "Enter the DateOfBirth";
        ret = false;
    }

    else if (id1<id) {
        document.getElementById("lbldob").innerHTML = "Please enter valid date";
        ret = false;

    }

    else {
        document.getElementById("lbldob").innerHTML = "";
    }

    var id2 = new Date(dob1);
    if (dob1.length == 0) {

        document.getElementById("lblErrorend").innerHTML = "Enter the Date of birth";
        ret = false;
    }

    else if (id2 < id) {
        document.getElementById("lblErrorend").innerHTML = "Please enter valid date";
        ret = false;

    }

    else {
        document.getElementById("lblErrorend").innerHTML = "";
    }



    if (remark.length == 0) {
        document.getElementById("lblErrorremark").innerHTML = "Enter the remark";
        ret = false;
    }

    else if (!patremark.test(remark)) {
        document.getElementById("lblErrorremark").innerHTML = "Enter valid remark";
        ret = false;
    }

    else {
        document.getElementById("lblErrorremark").innerHTML = "";
    }

    if (document.getElementById("ddlPAtyp").selectedIndex == 0) {

        document.getElementById("lblErrorName").innerHTML = "Select Promotional Activity";
        ret = false;
    }
    else {
        document.getElementById("lblErrorName").innerHTML = "";
    }


    return ret;

}



