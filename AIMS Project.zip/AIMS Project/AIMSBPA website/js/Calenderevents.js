﻿
function RetainPopUp() {
    var loginBox = '#login-box';
    //Fade in the Popup and add close button
    //        $(loginBox).fadeIn(300);
    //        NFFix();

    //Set the center alignment padding + border
    var popMargTop = ($(loginBox).height() + 24) / 2;
    var popMargLeft = ($(loginBox).width() + 24) / 2;
    var popheight = 10;
    $(loginBox).css({
        'margin-top': -popMargTop,
        'margin-left': -popMargLeft,
        'height': popheight
    });
    $(loginBox).fadeIn(300);
    NFFix();
    // Add the mask to body
    $('body').append('<div id="mask"></div>');
    $('#mask').fadeIn(300);
}
function PaymentServices() {

    $(document).ready(function () {
        $('#serve').click(function () {

            // Getting the variable's value from a link 
            //            var loginBox = $(this).attr('href');

            var loginBox = '#login-box';
            //Fade in the Popup and add close button
            $(loginBox).fadeIn(300);
            NFFix();

            //Set the center alignment padding + border
            var popMargTop = ($(loginBox).height() + 24) / 2;
            var popMargLeft = ($(loginBox).width() + 24) / 2;
            var popheight = 10;
            $(loginBox).css({
                'margin-top': -popMargTop,
                'margin-left': -popMargLeft,
                'height': popheight
            });

            // Add the mask to body
            $('body').append('<div id="mask"></div>');
            $('#mask').fadeIn(300);
            return true;
            //return false;

        });
        var poph = 10;
        $('.payment_popup_wrapper').css({

            'height': poph
        });

        // When clicking on the button close or the mask layer the popup closed
        $('a.close, #mask').live('click', function () {
            $('#mask , .login-popup').fadeOut(300, function () {
                $('#mask').remove();
            });
            return false;
        });

    });
}
    