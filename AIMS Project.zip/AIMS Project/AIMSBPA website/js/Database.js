﻿
function validateDatabase() {
    var cname = document.getElementById("txtdbname").value;
    var remark = document.getElementById("txtdesc").value;
    
    var patcname = new RegExp("^[a-z A-Z]{3,}$");
    var patremark = new RegExp("^[a-z A-Z]{3,}$");


    var ret = true;
    if (cname.length == 0) {

        document.getElementById("lblErrordbname").innerHTML = "Enter the Database name";
        ret = false;

    }

    else if (!patcname.test(cname)) {
        document.getElementById("lblErrordbname").innerHTML = "Enter the valid Database name";
        ret = false;
    }
    else {
        document.getElementById("lblErrordbname").innerHTML = "";
    }

    if (remark.length == 0) {
        document.getElementById("lblErrordescription").innerHTML = "Enter the Description";
        ret = false;
    }

    else if (!patremark.test(remark)) {
        document.getElementById("lblErrordescription").innerHTML = "Enter valid Description";
        ret = false;
    }

    else {
        document.getElementById("lblErrordescription").innerHTML = "";
    }

    if (document.getElementById("ddldbcreate").selectedIndex == 0) {
        document.getElementById("lblErrorCreate").innerHTML = "Select Role ";
        ret = false;
    }
    else {
        document.getElementById("lblErrorCreate").innerHTML = "";
    }
    

    return ret;

}



