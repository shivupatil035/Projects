﻿
function validateEvent() {
    var cname = document.getElementById("txtname").value;
    var date = document.getElementById("datepicker").value;
    var remark = document.getElementById("TxtDescription").value;

    var patcname = new RegExp("^[a-z A-Z]{3,}$");
    var patremark = new RegExp("^[a-z A-Z]{3,}$");


    var ret = true;
    if (cname.length == 0) {

        document.getElementById("lblEventname").innerHTML = "Enter the Database name";
        ret = false;

    }

    else if (!patcname.test(cname)) {
        document.getElementById("lblEventname").innerHTML = "Enter the valid Database name";
        ret = false;
    }
    else {
        document.getElementById("lblEventname").innerHTML = "";
    }

    if (remark.length == 0) {
        document.getElementById("lblMessage").innerHTML = "Enter the Description";
        ret = false;
    }

    else if (!patremark.test(remark)) {
        document.getElementById("lblMessage").innerHTML = "Enter valid Description";
        ret = false;
    }

    else {
        document.getElementById("lblMessage").innerHTML = "";
    }


    var id = new Date();
    var id1 = new Date(date);
    if (date.length == 0) {

        document.getElementById("lbldate").innerHTML = "Enter the date of event";
        ret = false;
    }

    else if (id1 < id) {
        document.getElementById("lbldate").innerHTML = "Please enter valid date";
        ret = false;

    }

    else {
        document.getElementById("lbldate").innerHTML = "";
    }



    if (document.getElementById("ddlCreate").selectedIndex == 0) {
        document.getElementById("lblEventcreate").innerHTML = "Select Role ";
        ret = false;
    }
    else {
        document.getElementById("lblEventcreate").innerHTML = "";
    }


    return ret;


}




function validateEventAssign() {

    var remark = document.getElementById("txtremarks").value;
    var patremark = new RegExp("^[a-z A-Z]{3,}$");
    var ret = true;



    if (document.getElementById("DLEventId").selectedIndex == 0) {
        document.getElementById("lblname").innerHTML = "Select Course";
        ret = false;
    }
    else {
        document.getElementById("lblname").innerHTML = "";
    }



    if (document.getElementById("DLUserId").selectedIndex == 0) {

        document.getElementById("lblassign").innerHTML = "Select Team Lead";
        ret = false;
    }
    else {
        document.getElementById("lblassign").innerHTML = "";
    }


    if (remark.length == 0) {
        document.getElementById("lblErrorremark").innerHTML = "Enter the remark";
        ret = false;
    }

    else if (!patremark.test(remark)) {
        document.getElementById("lblErrorremark").innerHTML = "Enter valid remark";
        ret = false;
    }

    else {
        document.getElementById("lblErrorremark").innerHTML = "";
    }




    return ret;

}





