﻿
function ValidateSearch() {

    var name = document.getElementById("TxtMname").value;
    var id = document.getElementById("txtid").value;
    var patfname = new RegExp("^[a-zA-Z]{0,}$");
    var patid = new RegExp("^[0-9]{0,}$");
    var ret = true;
    if (!patfname.test(name)) {
        document.getElementById("lblname").innerHTML = "Enter the valid name";
        ret = false;
    }

    else {
        document.getElementById("lblname").innerHTML = "";
    }
    if (!patid.test(id)) {
        document.getElementById("lblid").innerHTML = "Enter numbers only";
        ret = false;
    }

    else {
        document.getElementById("lblid").innerHTML = "";
    }
    return ret;
}


function validateMeetings() {
    var subject = document.getElementById("TxtSub").value;
    var message = document.getElementById("TxtMessage").value;
    var date = document.getElementById("datepicker").value;
    var starttime = document.getElementById("TxtStartTime").value;
    var endtime = document.getElementById("TxtEndTime").value;
    var location = document.getElementById("TxtLocation").value;

    var patremark = new RegExp("^[a-z A-Z]{3,}$");
    var patcname = new RegExp("^[a-z A-Z]{3,}$");

    var ret = true;
    if (subject.length == 0) {
        document.getElementById("lblSubject").innerHTML = "Enter the Meeting name";
        ret = false;
    }
    else if (!patcname.test(subject)) {
        document.getElementById("lblSubject").innerHTML = "Enter the valid Meeting subject";
        ret = false;
    }
    else {
        document.getElementById("lblSubject").innerHTML = "";
    }
    if (message.length == 0) {
        document.getElementById("lblMessage").innerHTML = "Enter the Message";

        ret = false;
        }
         else if (!patcname.test(message)) {
        document.getElementById("lblMessage").innerHTML = "Enter the valid Meeting message";
        ret = false;
    
    } 
    else {
        document.getElementById("lblMessage").innerHTML = "";
    }

    var id = new Date();
    var id1 = new Date(date);
    if (date.length == 0) {

        document.getElementById("lbldate").innerHTML = "Enter the date of meeting";
        ret = false;
    }

    else if (id1 < id) {
        document.getElementById("lbldate").innerHTML = "Please enter valid date";
        ret = false;

    }

    else {
        document.getElementById("lbldate").innerHTML = "";
    }


    if (starttime.length == 0) {
        document.getElementById("lblStartTime").innerHTML = "Enter the StartTime";

        ret = false;
    } 
    else {
        document.getElementById("lblStartTime").innerHTML = "";
    }

    if (endtime.length == 0) {
        document.getElementById("lblEndTime").innerHTML = "Enter the EndTime";
        ret = false;
    }

    else {
        document.getElementById("lblEndTime").innerHTML = "";
    }

    if (location.length == 0) {
        document.getElementById("lblLocation").innerHTML = "Enter the Location";
        ret = false;
    }

    else if (!patremark.test(location)) {
        document.getElementById("lblLocation").innerHTML = "Enter valid location";
        ret = false;
    }

    else {
        document.getElementById("lblLocation").innerHTML = "";
    } 
     
    return ret;
} 
