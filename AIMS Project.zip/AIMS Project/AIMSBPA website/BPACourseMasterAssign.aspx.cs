﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BPABusinessLayer;
using System.Data;

public partial class BPACourseMasterAssign : System.Web.UI.Page
{
    BPABLData obj=new BPABLData();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            ddlcourseid.DataSource = obj.CourseList();
            ddlcourseid.DataTextField = "Course";
            ddlcourseid.DataValueField = "CourseId";
            ddlcourseid.DataBind();
            ddlcourseid.Items.Insert(0, "--Select--");
        
            ddlteamleadid.DataSource = obj.CourseTeamLeadList();
            ddlteamleadid.DataTextField = "FirstName";
            ddlteamleadid.DataValueField = "UserId";
            ddlteamleadid.DataBind();
            ddlteamleadid.Items.Insert(0, "--Select--");

           
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        lblmessage.Text = obj.AssignCourse(Convert.ToInt32(ddlcourseid.SelectedValue), Convert.ToInt32(ddlteamleadid.SelectedValue), txtaremark.Text);
    }
}