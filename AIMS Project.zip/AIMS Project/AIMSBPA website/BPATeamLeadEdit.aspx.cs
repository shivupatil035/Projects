﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BPABusinessLayer;
using System.Data;

public partial class BPATeamLeadEdit : System.Web.UI.Page
{

    BPABLData obj = new BPABLData();
    static int previous;
    static int present;
    private int index;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            GridView1.DataSource = obj.ListUser();
            GridView1.DataBind();
        }
    }

    protected void BtnEdit_Click(object sender, EventArgs e)
    {
     foreach (GridViewRow r in GridView1.Rows)
        {
            CheckBox cb = (CheckBox)r.FindControl("CheckBox1");
            if (cb.Checked)
            {
                GridViewRow row = (GridViewRow)cb.Parent.Parent;
                index = row.RowIndex;
              
                var id = (GridView1.Rows[index].Cells[1].Text);
                Response.Redirect("BPATeamLeadAdd.aspx?id=" + id);
            }
        }
        GridView1.DataSource = obj.ListUser();
        GridView1.DataBind();
    
    }
    protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
    {
        CheckBox cb = (CheckBox)sender;
        if (cb.Checked)
        {
            present = ((GridViewRow)cb.Parent.Parent).RowIndex;

            if (previous != -1)
            {
                CheckBox preCb = (CheckBox)GridView1.Rows[previous].Cells[0].FindControl("CheckBox1");
                preCb.Checked = false;
                previous = present;
                present = -1;
            }
            else if (previous == -1)
            {
                previous = present;
                present = -1;
            }


        }
       
    }
    protected void BtnSearch_Click(object sender, EventArgs e)
    {
        
    }
   
    protected void GridView1_RowCreated(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.Header)
        {
            e.Row.Cells[0].Text = "Select";
            e.Row.Cells[1].Text = "UserID";
            e.Row.Cells[2].Text = "Name";
            e.Row.Cells[3].Text = "Surname";
            e.Row.Cells[4].Text = "EmailID";
            e.Row.Cells[5].Text = "Phone Number";
            e.Row.Cells[6].Text = "Mobile Number";
            e.Row.Cells[7].Text = "Address";
            e.Row.Cells[8].Text = "City";
            e.Row.Cells[9].Text = "Pin Code";
            e.Row.Cells[10].Text = "Qualification";
            e.Row.Cells[11].Text = "Gender";
            e.Row.Cells[12].Text = "Date of Birth";
            e.Row.Cells[13].Text = "Photo";
            e.Row.Cells[14].Text = "ReportingTo";
            e.Row.Cells[15].Text = "Role ID";
          //  e.Row.Cells[16].Visible = false;
           // e.Row.Cells[17].Visible = false; 

            e.Row.Cells[0].CssClass = "columnselect";
            e.Row.Cells[1].CssClass = "columnuser";
            e.Row.Cells[2].CssClass = "columnname";
            e.Row.Cells[3].CssClass = "columnsurname";
            e.Row.Cells[4].CssClass = "columnemail";
            e.Row.Cells[5].CssClass = "columnphone";
            e.Row.Cells[6].CssClass = "columnmobile";
            e.Row.Cells[7].CssClass = "columnaddress";
            e.Row.Cells[8].CssClass = "columncity";
            e.Row.Cells[9].CssClass = "columnpin";
            e.Row.Cells[10].CssClass = "columnquali";
            e.Row.Cells[11].CssClass = "columngender";
            e.Row.Cells[12].CssClass = "columnudob";
            e.Row.Cells[13].CssClass = "columnphoto";
            e.Row.Cells[14].CssClass = "columnreport";
            e.Row.Cells[15].CssClass = "columnrole";
           
            
        }

        else if (e.Row.RowType == DataControlRowType.DataRow)
        {
            e.Row.Cells[0].CssClass = "columnselect";
            e.Row.Cells[1].CssClass = "columnuser";
            e.Row.Cells[2].CssClass = "columnname";
            e.Row.Cells[3].CssClass = "columnsurname";
            e.Row.Cells[4].CssClass = "columnemail";
            e.Row.Cells[5].CssClass = "columnphone";
            e.Row.Cells[6].CssClass = "columnmobile";
            e.Row.Cells[7].CssClass = "columnaddress";
            e.Row.Cells[8].CssClass = "columncity";
            e.Row.Cells[9].CssClass = "columnpin";
            e.Row.Cells[10].CssClass = "columnquali";
            e.Row.Cells[11].CssClass = "columngender";
            e.Row.Cells[12].CssClass = "columnudob";
            e.Row.Cells[13].CssClass = "columnphoto";
            e.Row.Cells[14].CssClass = "columnreport";
            e.Row.Cells[15].CssClass = "columnrole";
            //e.Row.Cells[16].Visible = false; 
//            e.Row.Cells[17].Visible = false;

          



        }
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void Button2_Click(object sender, EventArgs e)
    {

        DataTable dt = obj.SearchTeamLead(Convert.ToInt32(txtsearch.Text));
        if (dt.Rows.Count > 0)
        {
            GridView1.DataSource = dt;
            GridView1.DataBind();
            Label1.Text = "No of record(s) found " + dt.Rows.Count.ToString();
        }
        else
        {
            GridView1.DataSource = null;
            GridView1.DataBind();
            Label1.Text = "No Records found matching your criteria";
        }

    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.DataSource = obj.ListUser();
        GridView1.DataBind();
        GridView1.PageIndex = e.NewPageIndex;
    }
}