﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using CrystalDecisions.Shared;
using CrystalDecisions.CrystalReports.Engine;
using BPABusinessLayer;
public partial class TeamleadReportViewer : System.Web.UI.Page
{
    BPABLData obj = new BPABLData();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.QueryString["ReportingTo"] != null)
        {
            int ReportTo = Convert.ToInt32(Request.QueryString["ReportingTo"]);
            DataTable dt = obj.TeamleadReport(ReportTo);
            dt.TableName = "TLReport";
            DataSet dtSet = new DataSet();
            dtSet.Tables.Add(dt);
            ReportDocument rpDoc = new ReportDocument();
            rpDoc.Load(Server.MapPath("Reports") + "/TeamleadReport.rpt");
            rpDoc.SetDataSource(dtSet);
            CrystalReportViewer1.ReportSource = rpDoc;
            CrystalReportViewer1.DataBind();
        }
        else
        {
            String From = Request.QueryString["From"];
            string To = Request.QueryString["To"];
            DataTable dt = obj.TeamleadReportDuration(From, To);
            dt.TableName = "TLReportDuration";
            DataSet dtSet = new DataSet();
            dtSet.Tables.Add(dt);
            ReportDocument rpDoc = new ReportDocument();
            rpDoc.Load(Server.MapPath("Reports") + "/TeamleadReportDuration.rpt");
            rpDoc.SetDataSource(dtSet);
            CrystalReportViewer1.ReportSource = rpDoc;
            CrystalReportViewer1.DataBind();

        }
    }
    protected void CrystalReportViewer1_Init(object sender, EventArgs e)
    {

    }
}