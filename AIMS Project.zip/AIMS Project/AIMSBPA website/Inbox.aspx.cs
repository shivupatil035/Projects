﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using BPABusinessLayer;

public partial class Inbox : System.Web.UI.Page
{
    BPABLData obj = new BPABLData();
    DataTable dt = new DataTable();
    protected void Page_Load(object sender, EventArgs e)
    {
        dt = obj.BindInbox();
        ListView1.DataSource = dt;
        ListView1.DataBind();
    }
    protected void btn_delete_Click(object sender, ImageClickEventArgs e)
    {
        //ImageButton ig =(ImageButton)sender;
        //ListViewItem li = (ListViewItem)ig.Parent;
        //CheckBox _chkArchive = (CheckBox)li.FindControl("CheckBox1");
        //Label lbldelete = (Label)li.FindControl("lbldelete");
        for (int i = 0; i < ListView1.Items.Count; i++)
        {
            CheckBox _chkArchive = (CheckBox)ListView1.Controls[i].FindControl("CheckBox1");
            Label _lblmsgname = (Label)ListView1.Controls[i].FindControl("lbl_msgname");
            Label lbldelete = (Label)ListView1.Controls[i].FindControl("lbldelete");

            Label _lblmsgdiscription = (Label)ListView1.Controls[i].FindControl("lbl_msgDeatis");
            string strname = _lblmsgname.Text;
            string strdisc = _lblmsgdiscription.Text;
            //long _id = Convert.ToInt64(_lblArchive.Text);
            if (_chkArchive.Checked)
            {
                //obj.DeleteInbox(Convert.ToInt32(lbldelete));

                //inb.ListBLStatusViewDelet(strname, strdisc);
            }
        }

          Response.Redirect("Inbox.aspx");
    }
    protected void ListView1_SelectedIndexChanged1(object sender, EventArgs e)
    {
        
    }
    protected void ListView1_PagePropertiesChanged(object sender, EventArgs e)
    {
        //DataTable dt = inb.BLInboxSenderName();
        //ListView1.DataSource = dt;
        //ListView1.DataBind();
    }
    protected void ListView1_PagePropertiesChanged1(object sender, EventArgs e)
    {
        //DataTable dt = new DataTable();

        //dt = inb.BLInboxSenderName();
        //ListView1.DataSource = dt;
        //ListView1.DataBind();
    }
    protected void ListView1_ItemDataBound1(object sender, ListViewItemEventArgs e)
    {
        //DataTable dt = inb.BLInboxSenderName();
        //if (dt.Rows.Count > 0)
        //{
        //    foreach (DataRow dr in dt.Rows)
        //    {
        //        ListViewItem liItem = (ListViewItem)e.Item;
        //        ImageButton _imgbtn = (ImageButton)liItem.FindControl("ImgBtn_DownloadAttachmentS");
        //        // LinkButton lnk = (LinkButton)liItem.FindControl("LnkBtn_DownloadAttachmnt");
        //        if (string.IsNullOrEmpty(_imgbtn.CommandName.ToString()))
        //        {
        //            //lnk.Visible = false;
        //            _imgbtn.Visible = false;
        //        }

        //    }
        //}
    }
    protected void DownloadFile_click(object sender, EventArgs e)
    {

        LinkButton _linkFileName = (LinkButton)(sender);
        string _filename = _linkFileName.Text;
        ClientScript.RegisterStartupScript(typeof(string), "message", "<script language='javascript'>alert('welcome')</script>");
        Response.ContentType = "application/txt";
        Response.AppendHeader("Content-Disposition", "attachment; filename=" + _filename);
        Response.TransmitFile(Server.MapPath(@"~/Download Files/" + _filename));
        Response.End();
    }
}