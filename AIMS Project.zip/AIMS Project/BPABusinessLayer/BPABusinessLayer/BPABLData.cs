﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using BPADataLayer;
using System.Data.SqlClient;
namespace BPABusinessLayer
{
    public class BPABLData
    {

        BPAData obj = new BPAData();
        public DataTable ListUser(string email, string pass)
        {
            DataTable dt = new DataTable();
            dt = obj.ListLogin(email);
            return dt;
        }
        public DataTable Forgot(string email)
        {
            DataTable dt = new DataTable();
            dt = obj.ForgotPssword(email);
            return dt;
        }

        public DataTable selectRole()
        {
            DataTable dt = new DataTable();
            dt = obj.ForgotRole();
            return dt;
        }
        public DataTable ChangePass(string newpassword, string oldpassword)
        {
            DataTable dt = new DataTable();
            dt = obj.ChangePssword(newpassword, oldpassword);
            return dt;
        }
        public DataTable SelectPassword()
        {
            DataTable dt = obj.SelectPass();
            return dt;
        }

        public DataTable ReportTo()
        {
            DataTable dt = obj.ReportTo();
            return dt;
        }


        public DataTable GetRoles()
        {
            DataTable dt = obj.GetRoleInfo();
            return dt;
        }

        public DataTable GetBDId()
        {
            DataTable dt = obj.GetDBId();
            return dt;
        }

        public string UserDeactive(int Userid)
        {
            try
            {
                obj.UserDeactive(Userid);
                return "The user Deleted" + Userid;
            }
            catch
            {
                return "Faild to Delete User";
            }
        }
        public DataTable ListUser()
        {
            DataTable dt = obj.UserList();
            return dt;
        }

        //Team lead
        public string AddTeam(string FName, String LName, string Email, Int64 MobileNo, Int64 OfficialNo, string Address, string City, Int64 Pin, string Qualification, string Gender, DateTime DOB, string Photo, int ReportTo, string pass, int RoleId)
        {
            obj.AddTeamLead(FName, LName, Email, MobileNo, OfficialNo, Address, City, Pin, Qualification, Gender, DOB, Photo, ReportTo, pass, RoleId);
            return "New Record has been  sucessfully created for:" + FName;

        }


        public DataTable SelectUserDetails(int userid)
        {
            return obj.SelectUser(userid);
        }


        public string UpdateTeamLead(int Userid, string FName, String LName, string Email, Int64 MobileNo, Int64 OfficialNo, string Address, string City, Int64 Pin, string Qualification, string Gender, DateTime DOB, string Photo, int ReportTo, string pass, int RoleId)
        {
            int res = obj.UpdateTeamLead(Userid, FName, LName, Email, MobileNo, OfficialNo, Address, City, Pin, Qualification, Gender, DOB, Photo, ReportTo, pass, RoleId);
            if (res > 0)
            {
                return " User Details successfully updated" + Userid;
            }
            else
            {
                return "updation failed";
            }

        }

        public DataTable SearchTeamLead(int id)
        {
            DataTable dt = new DataTable();
            dt = obj.SearchTeamLead(id);
            return dt;
        }



        //CourseMaster
        public string AddCourse(string Course, int CourseDurationYear, int CourseDurationMonth, int CourseFees, string Remarks)
        {
            try
            {
                obj.AddCourse(Course, CourseDurationYear, CourseDurationMonth, CourseFees, Remarks);

                return "The Course is Added:\t\t " + Course;

            }
            catch
            {
                return "Failed to Add the Course";
            }

        }


        public DataTable SelectCourse()
        {
            DataTable dt = obj.EditCourse();
            return dt;
        }


        public DataTable FetchCourse(int CourseId)
        {
            DataTable dt = obj.FetchCourse(CourseId);
            return dt;
        }


        public string UpdateCourse(int CourseId, string Course, int CourseDurationYear, int CourseDurationMonth, Double CourseFees, string Remarks)
        {
            try
            {
                obj.UpdateCourse(CourseId, Course, CourseDurationYear, CourseDurationMonth, CourseFees, Remarks);

                return "The Course information Updated: " + Course;

            }
            catch
            {
                return "Failed to Update the  Course information";
            }

        }

        public string DeleteCourse(int CourseId)
        {
            try
            {
                obj.DeleteCourse(CourseId);

                return "The course is deleted: " + CourseId;

            }
            catch
            {
                return "Failed to Delete the course";
            }

        }

        public string AssignCourse(int CourseAssignId, int CourseAssgnTo, string Remarks)
        {
            try
            {
                obj.AssignCourse(CourseAssignId, CourseAssgnTo, Remarks);

                return "The Course Assign To: " + CourseAssgnTo;

            }
            catch
            {
                return "Failed to Assign the Course";
            }

        }

        public DataTable CourseList()
        {
            DataTable dt = obj.Courselist();
            return dt;
        }


        public DataTable CourseTeamLeadList()
        {
            DataTable dt = obj.CourseTeamLeadList();
            return dt;
        }

        public DataTable SearchCourse(string name)
        {
            DataTable dt = new DataTable();
            dt = obj.SearchCourse(name);
            return dt;
        }


        //Promotional Activity

        public string AddPromotionalActivity(string PromotionalType, string Subject, int Amount, string DurationStart, string DurationEnd, string Attachment, string Remark)
        {
            try
            {
                obj.AddPromotionalActivity(PromotionalType, Subject, Amount, DurationStart, DurationEnd, Attachment, Remark);

                return "The Promotional is Added: " + PromotionalType;

            }
            catch
            {
                return "Failed to Add the Promotional";
            }

        }

        public string AssignPromotionalActivity(int PromotionalActivityId, int TeamLeadId, string Remark)
        {
            try
            {
                obj.AssignPromotionalActivity(PromotionalActivityId, TeamLeadId, Remark);

                return "The Promotional is Assigned To: " + TeamLeadId;

            }
            catch
            {
                return "Failed to Assign Promotional Activity";
            }

        }

        public DataTable SelectPromotionalActivity()
        {
            DataTable dt = obj.PromotionalActivityView();
            return dt;
        }


        public DataTable FetchPromotionalActivity(int PromotionalActivityId)
        {
            DataTable dt = obj.FetchPromotionalActivity(PromotionalActivityId);
            return dt;
        }

        public DataTable PromotionalList()
        {
            DataTable dt = obj.Promotionallist();
            return dt;

        }
        public string UpdatePromotionalActivity(int PromotionalActivityId, string PromotionalType, string Subject, int Amount, DateTime DurationStart, DateTime DurationEnd, string Attachment, string Remark)
        {
            try
            {
                obj.UpdatePromotionalActivity(PromotionalActivityId, PromotionalType, Subject, Amount, DurationStart, DurationEnd, Attachment, Remark);

                return "The PromotionalActivity information Updated: " + PromotionalType;

            }
            catch
            {
                return "Failed to Update the  PromotionalActivity information";
            }

        }

        public DataTable SearchPromotionalActivity(int id)
        {
            DataTable dt = new DataTable();
            dt = obj.SearchPromotionalActivity(id);
            return dt;
        }

        public string DeletePromotionalActivity(int PromotionalActivityId)
        {
            try
            {
                obj.DeletePromotionalActivity(PromotionalActivityId);

                return "The PromotionalActivity is deleted: " + PromotionalActivityId;

            }
            catch
            {
                return "Failed to Delete the PromotionalActivity";
            }

        }







        //Meetings
        public DataTable DisplayMeeting()
        {
            DataTable dt = obj.DisplayMeetings();
            return dt;
        }



        //Meetings
        public string MeetingDeactive(int meetingid)
        {
            try
            {
                obj.MeetingDeactive(meetingid);
                return "The Meetink Deleted" + meetingid;
            }
            catch
            {
                return "Faild to Delete Meeting";
            }
        }


        public string Addmeeting(string MName, string Description, DateTime date, string Stime, string ETime, string Location)
        {
            obj.Addmeeting(MName, Description, date, Stime, ETime, Location);
            return " New Meeting Created";
        }
        public string updateNeeting(int meetingid, string MName, string Description, DateTime date, string Stime, string ETime, string Location)
        {
            obj.Updatemeeting(meetingid, MName, Description, date, Stime, ETime, Location);
            return "Updated sucessfully";
        }

        public DataTable SelectMeetingId(int meetingid)
        {
            return obj.SelectMeetingId(meetingid);
        }

        public DataTable SearchMeeting(string name, string id)
        {
            DataTable dt = new DataTable();
            dt = obj.MeetingSearch(name, id);
            return dt;
        }





        //Database
        public string AddDatabase(int DatabseAssignId, string DatabaseName, string DatabaseBrower, string AssignDescription)
        {
            try
            {
                obj.AddDatabase(DatabseAssignId, DatabaseName, DatabaseBrower, AssignDescription);

                return "The Database is Created: " + DatabseAssignId;

            }
            catch
            {
                return "Failed to Add the Database";
            }

        }


        public string AssignDatabase(int DatabseAssignId, int TeamLeadId, string AssignDescriptionn)
        {
            try
            {
                obj.AssignDatabase(DatabseAssignId, TeamLeadId, AssignDescriptionn);

                return "The Database is Assigned:\t " + DatabseAssignId;

            }
            catch
            {
                return "Failed to Assign the Database";
            }

        }

        public DataTable DatabaseView()
        {
            DataTable dt = obj.DatabaseView();
            return dt;
        }


        public DataTable FetchDB(int DatabseId)
        {
            DataTable dt = obj.FetchDB(DatabseId);
            return dt;
        }

        public string DeleteDB(int DatabseId)
        {
            try
            {
                obj.DeleteDB(DatabseId);

                return "The Database is deleted: " + DatabseId;

            }
            catch
            {
                return "Failed to Delete the database";
            }

        }


        public string UpdateDB(int DatabseAssignId, int TeamLeadId, string AssignDescription)
        {
            try
            {
                obj.UpdateDatabase(DatabseAssignId, TeamLeadId, AssignDescription);

                return "The Database Assigned To: " + TeamLeadId;

            }
            catch
            {
                return "Failed to Upadate the Information";
            }

        }

        public DataTable SearchDB(string name)
        {
            DataTable dt = new DataTable();
            dt = obj.SearchDB(name);
            return dt;
        }




       // Events

            public string Addevent(int createrid,string eventname, string description, DateTime date)
        {
            obj.AddEvent(createrid,eventname, description, date);
            return "New Event Sucessfully Created";
        }
        public String EventApplicableIns(int EventId, int UserId, string Remarks)
        {
            obj.EventApplicableIns(EventId, UserId, Remarks);
            return "Event Has Been Assigned To=" + UserId;
        }

        public DataTable SelectEventId()
        {
            DataTable dt = obj.SelectEventId();

            return dt;
        }
        public DataTable DisplayEvents()
        {
            DataTable dt = obj.DisplayEvents();
            return dt;
        }
        public DataTable EventSearch(int EventId, int UserId)
        {
            DataTable dt = new DataTable();
            dt = obj.EventSearch(EventId,UserId);
            return dt;
        }
        public DataTable SelectEventsToEdit(int EventId)
        {
            DataTable dt = obj.SelectEventsToEdit(EventId);
            return dt;
        }


        public string EventDeactive(int EventId)
        {
            try
            {
                obj.EventDeactive(EventId);
                return "The Event Deleted" +EventId;
            }
            catch
            {
                return "Faild to Delete Event";
            }
        }

        public DataTable ViewEventDetails()
        {
            DataTable dt = obj.ViewEventDetails();
            return dt;
        }

        public DataTable GetEventDate()
        {
            DataTable dt = obj.GetEventDate();
            return dt;
        }
        public DataTable CallEventDetails(DateTime EventDate)
        {
            DataTable dt = new DataTable();
            dt = obj.CallEventDetails(EventDate);
            return dt;
        }

        public DataTable FetchEvent(int EventId)
        {
            DataTable dt = obj.FetchEvent(EventId);
            return dt;
        }
        public string UpdateEvents(int EventId,int Createrid, String EventDescription, DateTime dateOfCreation,int EventId1, int UserId, string Remarks)
        {
            obj.UpdateEvent(EventId,Createrid, EventDescription,dateOfCreation,EventId1, UserId, Remarks);

            return "Updated sucessfully";
        }

        public DataTable SearchEvent(string name)
        {
            DataTable dt = new DataTable();
            dt = obj.SearchEvent(name);
            return dt;
        }

        //Mail

        public DataTable ListBoxBound()
        {
            DataTable dt = new DataTable();
            dt = obj.ListBoxBound();
            return dt;
        }

        public DataTable BindOutbox()
        {
            DataTable dt = new DataTable();
            dt = obj.BindOutbox();
            return dt;
        }
        public DataTable BindInbox()
        {
            DataTable dt = new DataTable();
            dt = obj.BindInbox();
            return dt;
        }
        public string AddMails(string Subject, string Message, int SenderId, string Attachment)
        {
            obj.AddMails(Subject, Message, SenderId, Attachment);
            return "Mail Has Been Added";
        }
        public string AddMailRecepients(int SenderId, int ReceiverId)
        {
            obj.AddMailRecepient(SenderId, ReceiverId);
            return "Mail Has Been Added";
        }

        //Message

        public DataTable MessageUserDisplay()
        {
            DataTable dt = new DataTable();
            dt = obj.MessageUserDisplay();
            return dt;
        }

        public string AddMessages(string Message, int SenderId)
        {
            obj.AddMEssages(Message, SenderId);
            return "Message is saved";
        }
        public string AddMessagesrecipients(int SenderId, int ReceiverId)
        {
            obj.AddMessageRecepient(SenderId, ReceiverId);
            return "Message is saved";
        }

        public DataTable BindMessageInbox(int RecevierId)
        {
            DataTable dt = new DataTable();
            dt = obj.BindMessageInbox(RecevierId);
            return dt;
        }





        //Report  

        public DataTable TeamLeadList()
        {
            DataTable dt = obj.UserListReport();
            return dt;
        }

        public DataTable PerfomanceReport()
        {
            DataTable dt = obj.PerformaceReport();
            return dt;

        }

        public DataTable EnquiryInfo(int UserId)
        {
            DataTable dt = obj.EnquiryList(UserId);
            return dt;

        }

        public DataTable FollowUpInfo(int UserId)
        {
            DataTable dt = obj.FollowUPList(UserId);
            return dt;

        }

        public DataTable AdmissionInfo(int UserId)
        {
            DataTable dt = obj.AdmissionList(UserId);
            return dt;

        }

        //teamlead report
        public DataTable SelectTeamleadInReport()
        {
            DataTable dt = new DataTable();
            dt = obj.SelectTeamleadInReport();
            return dt;
        }
        public DataTable TeamleadReport(int ReporintgTo)
        {
            DataTable dt = new DataTable();
            dt = obj.TeamleadReport(ReporintgTo);
            return dt;
        }
        public DataTable TeamleadReportDuration(string From, string To)
        {
            DataTable dt = new DataTable();
            dt = obj.TeamleadReportDuration(From, To);
            return dt;

        }

        public DataTable EventDashboard()
        {
            DataTable dt = new DataTable();
            dt = obj.EventDashboard();
            return dt;
        }

        public DataTable MeetingDashboard()
        {
            DataTable dt = new DataTable();
            dt = obj.MeetingDashboard();
            return dt;
        }
        public DataTable MeetingDashboardDisplay(int MeetingId)
        {
            DataTable dt = new DataTable();
            dt = obj.MeetingDashboardDisplay(MeetingId);
            return dt;
        }
        public DataTable MailDashboard(int UserId)
        {
            DataTable dt = new DataTable();
            dt = obj.MailDashboard(UserId);
            return dt;
        }
        public DataTable MailDashboardDisplay(int MailId)
        {
            DataTable dt = new DataTable();
            dt = obj.MailDashboardDisplay(MailId);
            return dt;
        }
        public DataTable TeamDashboard()
        {
            DataTable dt = new DataTable();
            dt = obj.TeamleadDashboard();
            return dt;
        }
        public DataTable TeamleadDashboardDisplay(int ReportingTo)
        {
            DataTable dt = new DataTable();
            dt = obj.TeamleadDashboardDisplay(ReportingTo);
            return dt;
        }

        public DataTable EventDashboardDisplay(int id)
        {
            DataTable dt = new DataTable();
            dt = obj.EventDashboardDisplay(id);
            return dt;
        }



    }
}
