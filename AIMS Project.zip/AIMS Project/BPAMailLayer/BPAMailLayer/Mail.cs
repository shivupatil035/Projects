﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Mail;

namespace BPAMailLayer
{
    public class Mail
    {
        public void mail(string toaddress, string subject, string Bodycontent, string filecontent)
        {
           
                MailMessage mail = new MailMessage();

                mail.To.Add(toaddress);
                mail.From = new MailAddress("shivupatil035@gmail.com");
                mail.Subject = subject;
                mail.Body = Bodycontent;
                mail.Attachments.Add(Attachment.CreateAttachmentFromString("~/filecontent", "attached"));
                SmtpClient client = new SmtpClient("smtp.gmail.com");
                client.Credentials = new System.Net.NetworkCredential("shivupatil035@gmail.com", "9686052545");


                client.Port = 587;
                client.EnableSsl = true;
                client.Send(mail);
           



        }
    }
}
